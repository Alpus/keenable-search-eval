# Developer Search Eval

Compare CodeRabbit review quality on Martian, then Keenable versus Exa documentation retrieval with the same DevDex agent. Complete [setup](docs/experiment.md), fill `.env`, run `docker compose up -d --build search-mcp`, then `docker compose run --rm runner run --config configs/martian.yaml` or `configs/devdex_docs.yaml`. Progress and evidence persist in `runs/`; the same command resumes without replaying completed attempts.

Method: preserve each pinned benchmark's original scorer. Martian reports Core F2, precision and recall; DevDex reports documentation recall@10 and MRR@10. Show completion and duration separately. These are controlled public-subset pilots, not official leaderboard submissions. A benchmark gain does not establish a customer purchase or revenue gain.

**Main pilots pending.** Live DevDex development passed; see [validation](validation/devdex-live.md). Its native score difference comes from URL matching and does not establish better answers. Main-result charts will be added after verified pilots.
