# Martian provenance and live prerequisites

Pinned source: `e616e849755441da38f18bf3adba2c9583b03803`. Original gold is retained inside `vendor/martian/offline/golden_comments`:50 PRs,173 total comments,158 Core,139 Strict. `validation/martian-source-hashes.json` hashes gold and all transformation/scoring sources. Do not edit vendor files.

## Original scoring adapter

The suite dynamically loads the pinned original `score_tools`, `evaluate_review`, bot predicate, combined-comment text transform and dedup parser/prompt. It does not reimplement F scores or matching. Every role/configuration/repeat gets a separate evaluations artifact and an internal non-hidden tool key. Matching uses all gold before category filtering. A completed empty extraction yields all original FNs. Runtime and grading failures remain incomplete and contribute no invented FNs.

`project_github_pages` accepts `github.json` with three keys: `review_comments`, `reviews`, `issue_comments`. Each value is a nonempty ordered page list, including an empty page1 for a successfully empty endpoint. Page shape is `{page, per_page:30, items, endpoint, parameters, observed_at}`. The adapter scores page1 per endpoint before bot filtering, with original endpoint ordering and field conversion. Later pages remain raw evidence and their omission counts are reported. Missing or malformed pages fail grading.

`run_pipeline(comments, gold, extractor, deduper, judge, settings)` is async. The caller provides explicitly authorized, configured instances of upstream CandidateExtractor, DedupLLM and LLMJudge. They expose `.model` and their original async methods. The caller owns credentials, allowance, transport-level raw request/response recording and saving the result to `martian-grading.json`. The adapter captures extraction output, dedup groups and parsed original pairwise judge responses. It rejects failed extraction, missing dedup and judge errors. `grade` is offline and replays saved pair responses through original matching. Input/gold/settings/pipeline hashes invalidate stale artifacts.

No clients are instantiated by the suite. No live model call has been made. Raw transport responses are not synthesized from parsed pair responses. Live acceptance needs real saved request/response evidence and an at-least-one-candidate development case.

## Published reference

Chosen published artifact: `vendor/martian/offline/results/anthropic_claude-opus-4-5-20251101/evaluations.json`, hash in `validation/martian-reference-parity.json`. The [pinned upstream README](https://github.com/withmartian/code-review-benchmark/blob/e616e849755441da38f18bf3adba2c9583b03803/offline/README.md#judge-models-used) lists this dated judge alongside Sonnet4.5 and GPT5.2. Its slash-form request model is `anthropic/claude-opus-4-5-20251101` under upstream model-name sanitization.

The pinned extraction, dedup and judging source explicitly passes temperature0.0. It uses OpenAI-compatible Chat Completions. Extraction system prompt: code-review issue extraction. Dedup uses STRICT_PROMPT; judging uses JUDGE_PROMPT. Max output tokens and reasoning effort are not explicitly supplied. Judge structured output is optional and defaults false in code.

**Historical limit:** the public result files and directory name do not prove the exact historical endpoint/provider routing, optional structured-output flag, server defaults or identical model implementation. False is the code default, not a verified historical run parameter. The live gate must resolve this or explicitly disclose an agreed protocol variant. An example `.env` model is not evidence for the reference run. Availability/access/quota remain unverified.

Offline reference replay matches the upstream materialized dashboard counts for every common tool/profile. The dashboard additionally omits copilot and greptile-v5 that score_tools still includes; the test records this difference. Reference CodeRabbit Core:TP94/FP194/FN64 across50 PRs, P0.3263889/R0.5949367/F2 0.5108696. These are **published historical results, not results of this experiment**.

## Snapshot inventory and frozen reconstructed pilot

`data/martian-inventory.json` accounts for all50 gold tasks. All50 public CodeRabbit benchmark copies received a metadata eligibility screen. Thirty-nine establish copied-base ancestry, reviewed-head identity and tree IDs;11 remain unresolved. Twelve candidates received a manual gold-code audit. Ten are eligible reconstructed inputs, two are excluded, and38 were not manually gold-audited. The original full173 gold records remain unchanged. This is a reconstructed10-task pilot, not a claim of exact historical replication or a certified50-task benchmark.

Selection uses SHA256 of `martian-pilot-2026-09-29:` plus golden URL within each original gold source file (five repository groups). Inspect candidates in that order and accept two per repository. Discourse7 was excluded because one gold assertion does not match the copied topic-post diff. Grafana106778 was excluded because the alleged missing React key is present. Their next seeded candidates, Discourse1 and Grafana80329, replace them. The ledger is `validation/martian-gold-presence.json`. Selection was reconciled after the all50 metadata screen and before new provider outcomes; the selected10 did not change. `validation/martian-metadata-screen.json` preserves all50 classifications and the full seeded order. Metadata eligibility does not prove gold presence for the remaining38.

For each accepted input, public CodeRabbit review.commit_id matches the saved head. The copied base is reachable in the saved PR commit graph. Base/head Git tree IDs are retained. Every gold item has a static code observation. Ten selected gold-relevant files were fetched at those revisions; head blob SHA1 was checked against GitHub, local binary/full-index git diffs were generated, and reverse/apply round trips reproduced the head. Patch text and SHA256 are saved in `validation/martian-local-patch-*.json`. Full changed-file API diffs and metadata are retained separately. **Selected-file round trips do not verify the full tree.** Full-tree reconstruction and diff verification remain a pre-run gate.

The evidence supports reconstructing the observed copied base/head, not identifying the exact historical benchmark base. `load_tasks` accepts disclosed reconstructed inputs. Static bug presence does not prove every upstream label correct: Keycloak37429's anchor warning is ambiguous despite a matcher guard; Discourse1's loop has a five-attempt bound despite a broader stale-size warning; Grafana107534 is a test gap. These original labels are retained with explicit caveats. No label is silently removed to improve results.

The manifest has10 scored, two control and two development tasks. Controls change only the team-admin AND to OR (Cal14740) and expected group_2 value6 to10 (Sentry80168). Exact replacements and resulting file hashes are frozen. Each control removes its fixed target from hidden gold and retains all other gold. Neither control is claimed clean. Development tasks are authored outside the original50: a Requests timeout regression and a minimal annotation-only zero-findings candidate. Requests documentation supports the default-no-timeout contract; this is not evidence that search is required. The zero-findings candidate has no gold and uses completion-only diagnostics. The original scorer skips it; zero findings are not guaranteed. All non-scored roles have primary=false.

## Leakage and interpretation

The manifest enumerates known original/copy PR URLs and benchmark pages from pinned source records. This only covers known answer locations. Unknown copies/fixes and opaque native-search filtering remain limitations. All raw evidence and hidden gold remain local; visible tasks use an explicit execution-field allowlist. Most Martian tasks do not establish external-search necessity. A null gain is not provider equivalence.

Client factory: `pipeline_clients(recording_async_openai_client, settings)` binds the three original classes without reading `.env` or falling back to model defaults. It performs no network call. The caller's transport must capture raw HTTP responses and enforce the authorized allowance. The request model, temperature and structured-output choice are explicit; original prompts/methods remain unchanged.

`report_series` provides suite-native values and descriptors for generic reporting. `config.role` narrows expected task/group coverage when roles run independently.
