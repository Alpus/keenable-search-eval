# Setup and experiment protocol

The canonical task checklist is maintained in the parent research workspace during implementation. This repository contains executable code, frozen manifests and validation evidence. No live results are claimed until a completed run bundle exists.

## Local setup

Use Docker Compose. Copy `.env.example` to `.env` and fill the required credentials locally. Keep `.env` private. The gateway receives only search-provider credentials and routing data; GitHub and model keys remain with the runner. `uv sync --frozen` supports local development using Python3.12.

Run `docker compose run --rm runner doctor --config configs/devdex_docs.yaml` (or `configs/martian.yaml`). Doctor validates local settings and saved evidence without network calls, reviews or model inference. It lists unverified prerequisites instead of guessing quotas.

Set `public_mcp_url` to a stable HTTPS tunnel to localhost:8766 (or `MCP_HOST_PORT`). Start the gateway with `docker compose up -d --build search-mcp`. For CodeRabbit, register neutral connections `eval-search-a` and `eval-search-b` at `/mcp/search-a` and `/mcp/search-b` with the respective MCP bearer tokens. Use a dedicated review scope for these test repositories; never give the gateway GitHub or model credentials. The current owner is Alpus and all generated repositories are private. Verify CodeRabbit access to each selected repository; a personal account is not assumed to have automatic App access for future repositories.

DevDex uses `/mcp/devdex`, a private per-attempt bearer context issued by the runner. Its agent runs in an isolated worker process, not in CodeRabbit. MCP descriptions/results are neutral and equivalent across providers.

## Explicit live gates

There are separate development configs and quotas. Store verified account/model/provider allowance in the config's `allowance_file`. It must contain `verified: true`, exact `suite`, `run_id`, `role`, `max_attempts`, an aware UTC `valid_until`, source `evidence`, `services`, `additional_spending_usd: 0` and `automatic_overage_disabled: true`. Do not set these fields before checking the actual account. Each live run and model/provider access requires real evidence. No silent paid overage or fallback model.

For Martian, first establish the real CodeRabbit App ID, review-check name and strict completion behavior, including a completed zero-findings review. Save that contract in `suite_options.completion_contract`. The pilot also needs successful original model grading. Historical judge flags not established by public results remain explicit; use of a documented variant requires a methodology decision. For DevDex, the original harness pins its own historical agent model; the review-model preference does not change it.

Scored configs require saved suite-specific `acceptance_evidence` with `suite`, `passed: true`, actual input/config hashes and links to live evidence. Development and evaluation splits/caps are distinct. Do not convert unsuccessful attempts into no-findings reviews, retry dead evaluation episodes or roll unused development quota into scored attempts.

## Run and resume

Use `docker compose run --rm runner run --config configs/martian-development.yaml`, then its pilot config after live acceptance. DevDex has analogous configs. `--plan-only` saves a deterministic schedule without external calls. A changed config, manifest, source or scorer needs a new run ID. Completed attempts are not replayed; unknown writes or in-flight model execution stop for reconciliation. A global runner lock protects the shared routing store.

The run command performs original Martian model grading after collection using verified allowance and a recording OpenAI-compatible transport. The explicit `grade --run RUN_ID` command can resume grading without recollecting reviews. `report --run RUN_ID` is offline and never calls a model. DevDex uses the original deterministic URL scorer directly during reporting. Save and inspect all raw artifacts, native grader outputs and operational failures.

## Metrics and interpretation

Martian uses the pinned original extraction, deduplication, pairwise matching and micro-aggregated scoring. Primary Core F2, with P/R/TP/FP/FN; Strict/F1 are secondary. Full-set counts173/158/139 do not apply to the10-task pilot. The original collector reads the first page; we archive all30-item pages and let the suite reproduce its original projection. A supplemental blind audit cannot modify the main score.

DevDex Docs uses30 held-out-for-our-tuning public questions,5 development questions and the same original agent across Keenable/Exa. Preserve canonical URL matching, first10 citations, native dead-run scoring and >10% suppression. Report recall@10/MRR@10, paired wins/ties/losses, coverage and duration. Some direct target URLs were unavailable during the source audit; see validation evidence. Public data is not guaranteed unseen in model training.

Run one repeat by default. Additional predeclared repeats use fresh attempts and separate native scores, never best-of or merged findings. Compare provider configurations on newly collected matched tasks. Hosted models, web content and CodeRabbit cannot be frozen by Docker. Neither a small pilot nor retrieval success demonstrates statistical superiority, customer revenue or CodeRabbit improvement on another workflow.

Charts contain measured results only. Fixture charts are prominently marked and kept in validation, never used as headline product evidence. Reports for the two suites remain separate.
