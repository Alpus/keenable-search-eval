"""Offline presentation of suite-native series; no inference or API clients."""

from __future__ import annotations

import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path
from statistics import mean, median, stdev

from .core import TERMINAL, EvalError, atomic_json, suite_module


def build_report(run_dir: Path):
    state = json.loads((run_dir / "state.json").read_text())
    config = state["config"]
    if any(a["status"] not in TERMINAL for a in state["attempts"]):
        raise EvalError(
            "Pending/running/unknown attempts block final grading; reconcile the run first"
        )
    attempts = [{**a, "artifact_dir": str(run_dir / a["artifact_dir"])} for a in state["attempts"]]
    from .core import ROOT, frozen_manifest, verify_run_code

    frozen_manifest(run_dir, state)
    verify_run_code(state, ROOT)
    grading_config = {
        **config,
        "manifest": str(run_dir / "manifest.json"),
        "manifest_path": str(run_dir / "manifest.json"),
        "configurations": config["arms"],
    }
    result = suite_module(config["suite"]).grade(attempts, run_dir / "grading", grading_config)
    return render(run_dir, config, attempts, result)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def capture_traces(run_dir, config, attempts, trace_dir):
    """Copy only this schedule's sanitized gateway records, never routing secrets."""
    arms = {a["id"]: a for a in config.get("arms", [])}
    output = []
    for attempt in attempts:
        aid = attempt["id"]
        name = sha256(aid.encode()) + ".jsonl"
        source = trace_dir / name
        target = run_dir / "evidence" / "gateway" / name
        # A moved report can be regenerated from its already captured evidence.
        source = source if source.is_file() else target
        rows, reservations, finished = [], {}, {}
        if source.is_file():
            payload = source.read_bytes()
            try:
                rows = [json.loads(line) for line in payload.splitlines() if line.strip()]
                for row in rows:
                    if (
                        row["attempt_id"] != aid
                        or row.get("configuration") != attempt["configuration"]
                        or row["operation"] not in {"search", "fetch"}
                        or row["event"] not in {"reserved", "finished"}
                    ):
                        raise ValueError("trace identity or event mismatch")
                    bucket = reservations if row["event"] == "reserved" else finished
                    if row["call_id"] in bucket:
                        raise ValueError("duplicate trace event")
                    bucket[row["call_id"]] = row
                if not set(finished) <= set(reservations):
                    raise ValueError("finish without reservation")
                for call_id, row in finished.items():
                    if row["operation"] != reservations[call_id]["operation"]:
                        raise ValueError("operation changed within call")
            except (KeyError, ValueError, TypeError) as exc:
                raise EvalError(f"Invalid trace for attempt {aid}: {exc}") from exc
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(payload)
        rejection_name = sha256(aid.encode()) + ".rejections.jsonl"
        rejection_target = run_dir / "evidence" / "gateway" / rejection_name
        rejection_source = trace_dir / rejection_name
        rejection_source = rejection_source if rejection_source.is_file() else rejection_target
        rejections = []
        if rejection_source.is_file():
            rejection_bytes = rejection_source.read_bytes()
            try:
                rejections = [
                    json.loads(line) for line in rejection_bytes.splitlines() if line.strip()
                ]
                if any(
                    r.get("event") != "rejected"
                    or r.get("attempt_id") != aid
                    or r.get("configuration") != attempt["configuration"]
                    for r in rejections
                ):
                    raise ValueError("rejection attribution mismatch")
            except (ValueError, TypeError) as exc:
                raise EvalError(f"Invalid rejection trace for {aid}: {exc}") from exc
            rejection_target.parent.mkdir(parents=True, exist_ok=True)
            rejection_target.write_bytes(rejection_bytes)
        arm = arms.get(attempt["configuration"], {})
        output.append(
            {
                "attempt_id": aid,
                "task_id": attempt["task_id"],
                "configuration": attempt["configuration"],
                "repeat": attempt["repeat"],
                "role": attempt["role"],
                "trace_available": source.is_file(),
                "trace_path": str(target.relative_to(run_dir)) if source.is_file() else None,
                "trace_sha256": sha256(payload) if source.is_file() else None,
                "observed_search_calls": sum(
                    r["operation"] == "search" for r in reservations.values()
                )
                if source.is_file()
                else None,
                "observed_fetch_calls": sum(
                    r["operation"] == "fetch" for r in reservations.values()
                )
                if source.is_file()
                else None,
                "finished_calls": len(finished) if source.is_file() else None,
                "failed_calls": sum(r.get("ok") is False for r in finished.values())
                if source.is_file()
                else None,
                "unfinished_calls": len(reservations) - len(finished) if source.is_file() else None,
                "rejected_calls": len(rejections) if rejection_source.is_file() else None,
                "rejection_errors": [r.get("error") for r in rejections],
                "rejection_path": str(rejection_target.relative_to(run_dir))
                if rejection_source.is_file()
                else None,
                "rejection_sha256": sha256(rejection_bytes) if rejection_source.is_file() else None,
                "native_search_enabled": arm.get("native_search"),
                "native_search_calls": None,
                "native_observability": "unknown; CodeRabbit does not expose native calls"
                if config["suite"] == "martian"
                else "not applicable",
            }
        )
    atomic_json(run_dir / "tool-calls.json", output)
    return output


def paired_deltas(config, attempts, result):
    """Pair the same task, role and repeat, never union findings across repeats."""
    baseline = config["baseline"]
    index = {}
    task_scores = {r["attempt_id"]: r for r in result.get("per_task", [])}
    declared = {(r["metric"], r["scope"]) for r in result["report_series"]}
    for a in attempts:
        key = (a["task_id"], a["role"], a["repeat"], a["configuration"])
        if key in index:
            raise EvalError("Duplicate attempt in paired report")
        index[key] = a
    rows = []
    for key, a in index.items():
        task, role, repeat, arm = key
        if arm == baseline:
            continue
        b = index.get((task, role, repeat, baseline))
        common = {
            "task_id": task,
            "role": role,
            "repeat": repeat,
            "configuration": arm,
            "baseline": baseline,
            "attempt_id": a["id"],
            "baseline_attempt_id": b["id"] if b else None,
        }
        both = b is not None and a["status"] == b["status"] == "completed"
        metrics = [
            (
                "completed",
                "operations",
                int(a["status"] == "completed"),
                int(b["status"] == "completed") if b else None,
            )
        ]
        metrics.append(
            (
                "duration_seconds",
                "operations",
                a.get("duration_seconds") if both else None,
                b.get("duration_seconds") if both else None,
            )
        )
        for metric, scope in sorted(declared):
            av, bv = task_scores.get(a["id"], {}), task_scores.get(b["id"], {}) if b else {}
            if metric in av or metric in bv:
                metrics.append(
                    (
                        metric,
                        scope,
                        av.get(metric) if both else None,
                        bv.get(metric) if both else None,
                    )
                )
        for metric, scope, value, base in metrics:
            rows.append(
                {
                    **common,
                    "metric": metric,
                    "scope": scope,
                    "value": value,
                    "baseline_value": base,
                    "delta": value - base if value is not None and base is not None else None,
                    "paired_completed": both,
                }
            )
    return rows


def summarize_repeats(config, attempts, series):
    if config["repeats"] <= 1:
        return []
    groups = defaultdict(list)
    cohorts = defaultdict(list)
    for a in attempts:
        cohorts[(a["configuration"], a["role"], a["repeat"])].append(a["task_id"])
    for row in series:
        groups[(row["configuration"], row["role"], row["scope"], row["metric"])].append(row)
    output = []
    for (arm, role, scope, metric), rows in sorted(groups.items()):
        task_sets = [sorted(cohorts[(arm, role, r["repeat"])]) for r in rows]
        same = bool(task_sets) and all(
            t == task_sets[0] and len(t) == len(set(t)) for t in task_sets
        )
        complete = (
            same
            and {r["repeat"] for r in rows} == set(range(1, config["repeats"] + 1))
            and len(rows) == config["repeats"]
            and all(r["complete"] and r["value"] is not None for r in rows)
        )
        values = [r["value"] for r in rows] if complete else []
        output.append(
            {
                "configuration": arm,
                "role": role,
                "scope": scope,
                "metric": metric,
                "repeats_expected": config["repeats"],
                "repeats_present": len(rows),
                "same_task_cohort": same,
                "complete": complete,
                "mean": mean(values) if values else None,
                "min": min(values) if values else None,
                "max": max(values) if values else None,
                "sample_stddev": stdev(values) if len(values) > 1 else None,
            }
        )
    return output


def audit_bundle(run_dir, config, attempts, result, root):
    files = {}
    paths = [
        ("state.json", run_dir / "state.json"),
        ("config.json", run_dir / "config.json"),
        ("visible-tasks.json", run_dir / "visible-tasks.json"),
        ("evidence/gateway-config.json", root / ".gateway/traces/gateway-config.json"),
    ]
    if config.get("manifest"):
        if (run_dir / "state.json").is_file():
            from .core import frozen_manifest

            frozen_manifest(run_dir, json.loads((run_dir / "state.json").read_text()))
            paths.append(("evidence/manifest.json", run_dir / "manifest.json"))
        elif config.get("fixture"):
            paths.append(("evidence/manifest.json", root / config["manifest"]))
    if config["suite"] == "devdex_docs":
        paths += [
            ("evidence/devdex-protocol.json", root / "data/devdex-docs-protocol.json"),
            ("evidence/devdex-source-access.json", root / "validation/devdex-source-access.json"),
        ]
    for name, source in paths:
        target = run_dir / name
        source = source if source.is_file() else target
        if source.is_file():
            payload = source.read_bytes()
            target.parent.mkdir(parents=True, exist_ok=True)
            if source != target:
                target.write_bytes(payload)
            files[name] = sha256(payload)
    models = []
    for attempt in attempts:
        path = Path(attempt["artifact_dir"]) / "record.json"
        if path.is_file():
            record = json.loads(path.read_text())
            models.append(
                {
                    "attempt_id": attempt["id"],
                    "record_sha256": sha256(path.read_bytes()),
                    **{
                        k: record.get(k)
                        for k in (
                            "model",
                            "actual_models",
                            "settings",
                            "request_snapshot_sha256",
                            "request_verified",
                        )
                    },
                }
            )
    state = (
        json.loads((run_dir / "state.json").read_text())
        if (run_dir / "state.json").is_file()
        else {}
    )
    audit = {
        "run_fingerprint": state.get("fingerprint"),
        "file_sha256": files,
        "source_commit": result.get("source_commit"),
        "pipeline": result.get("pipeline"),
        "arms": config.get("arms", []),
        "profiles": {
            name: {k: p.get(k) for k in ("provider", "endpoint", "connection", "tier", "mode")}
            for name, p in config.get("profiles", {}).items()
        },
        "suite_options": config.get("suite_options", {}),
        "observed_models": models,
        "limitations": result.get("limitations", []),
        "note": "Requested model and observed model are distinct. Missing values are unverified. Source access is a dated audit, not current uptime.",
    }
    atomic_json(run_dir / "audit.json", audit)
    return audit


def blind_audit_sample(run_dir, config, attempts, limit=20):
    """Sample unmatched findings for human diagnosis without changing native scores."""
    limit = min(20, max(0, limit))
    seed = config.get("seed", 1729)
    pools = defaultdict(list)
    unavailable = []

    def rank(value):
        return sha256(json.dumps([seed, value], sort_keys=True).encode())

    for attempt in attempts:
        path = Path(attempt["artifact_dir"]) / "martian-grading.json"
        if attempt["status"] != "completed" or not path.is_file():
            unavailable.append(attempt["id"])
            continue
        saved = json.loads(path.read_text())
        if saved.get("status") != "complete":
            unavailable.append(attempt["id"])
            continue
        visible = Path(attempt["artifact_dir"]) / "visible-task.json"
        task = json.loads(visible.read_text()) if visible.is_file() else {}
        code = {
            k: task.get("input", {}).get(k)
            for k in ("repo", "base_sha", "head_sha")
            if task.get("input", {}).get(k) is not None
        }
        for index, finding in enumerate(saved.get("evaluation", {}).get("false_positives", [])):
            text = finding.get("candidate") if isinstance(finding, dict) else finding
            if not isinstance(text, str) or not text.strip():
                raise EvalError("Malformed saved Martian false-positive candidate")
            pools[attempt["configuration"]].append(
                {
                    "task_id": attempt["task_id"],
                    "code": code,
                    "finding": text,
                    "configuration": attempt["configuration"],
                    "attempt_id": attempt["id"],
                    "repeat": attempt["repeat"],
                    "role": attempt["role"],
                    "source_index": index,
                    "source_sha256": sha256(path.read_bytes()),
                    "selection_key": rank([attempt["id"], index, text]),
                }
            )
    for pool in pools.values():
        pool.sort(key=lambda row: row["selection_key"])
    arms = sorted(pools, key=rank)
    selected, offset = [], 0
    while len(selected) < limit:
        found = False
        for arm in arms:
            if offset < len(pools[arm]):
                selected.append(pools[arm][offset])
                found = True
                if len(selected) == limit:
                    break
        if not found:
            break
        offset += 1
    # Hide the arm rotation from the reviewer, as well as all arm metadata.
    selected.sort(key=lambda row: rank(["blind-order", row["selection_key"]]))
    items, mapping = [], []
    for index, row in enumerate(selected, 1):
        item_id = f"finding-{index:03d}"
        items.append(
            {
                "item_id": item_id,
                "task_id": row["task_id"],
                "code": row["code"],
                "finding": row["finding"],
                "manual_verdict": None,
                "review_notes": "",
            }
        )
        mapping.append(
            {
                "item_id": item_id,
                **{
                    k: row[k]
                    for k in (
                        "configuration",
                        "attempt_id",
                        "repeat",
                        "role",
                        "source_index",
                        "source_sha256",
                    )
                },
                "source_field": "evaluation.false_positives",
            }
        )
    existing = run_dir / "blind-review.json"
    if existing.is_file():
        previous = json.loads(existing.read_text()).get("items", [])
        has_work = any(
            r.get("manual_verdict") is not None or r.get("review_notes") for r in previous
        )

        def identity(row):
            return {k: row.get(k) for k in ("item_id", "task_id", "code", "finding")}

        if has_work and [identity(r) for r in previous] != [identity(r) for r in items]:
            raise EvalError(
                "Blind sample changed after manual review; preserve existing review before rebuilding"
            )
        if has_work:
            for item, old in zip(items, previous, strict=True):
                item.update(
                    manual_verdict=old.get("manual_verdict"),
                    review_notes=old.get("review_notes", ""),
                )
    blind = {
        "purpose": "Diagnostic sample of unmatched findings, not a precision estimate. Manual verdicts never change native scores.",
        "instructions": "Review each finding against the identified code. Leave unknown cases unresolved. Do not open audit-unblinding.json before recording verdicts.",
        "evidence_type": "fixture" if config.get("fixture") else "saved_native_evaluation",
        "items": items,
    }
    unblinding = {
        "seed": seed,
        "limit": limit,
        "selection": "Seeded stable-hash order within each configuration, balanced round robin, then blinded order.",
        "eligible_by_configuration": {arm: len(pools[arm]) for arm in sorted(pools)},
        "unavailable_attempts": unavailable,
        "items": mapping,
    }
    atomic_json(existing, blind)
    atomic_json(run_dir / "audit-unblinding.json", unblinding)
    return len(items)


def evidence_markdown(config, traces, pairs, repeats, audit, result):
    lines = [
        "",
        "## Search evidence",
        "",
        "Counts are observed gateway reservations, including failed or unfinished calls. Missing traces mean unknown, not zero. Rejected calls are recorded separately when attributable. Unauthenticated/unattributed events remain gateway-local and are not assigned to a run. Native CodeRabbit tool calls remain unknown.",
        "",
        "| Configuration | Repeat | Role | Traces / Attempts | Search | Fetch | Failed | Unfinished | Rejected | Native search |",
        "|---|---:|---|---:|---:|---:|---:|---:|---:|---|",
    ]
    groups = defaultdict(list)
    for row in traces:
        groups[(row["configuration"], row["repeat"], row["role"])].append(row)
    for (arm, repeat, role), rows in sorted(groups.items()):
        available = sum(r["trace_available"] for r in rows)

        def count(key):
            values = [r[key] for r in rows if r[key] is not None]
            if not values:
                return "unknown"
            return str(sum(values)) + (" (partial)" if len(values) < len(rows) else "")

        native = "unknown" if config["suite"] == "martian" else "not applicable"
        lines.append(
            f"| {arm} | {repeat} | {role} | {available}/{len(rows)} | {count('observed_search_calls')} | {count('observed_fetch_calls')} | {count('failed_calls')} | {count('unfinished_calls')} | {count('rejected_calls')} | {native} |"
        )
    lines += [
        "",
        "Exact attempts, trace paths and hashes: [tool-calls.json](tool-calls.json).",
        "",
        "## Paired comparisons",
        "",
        "[Per-task deltas](paired-deltas.json) subtract the baseline on the same task, role and repeat. Missing pairs stay unavailable. Duration includes only pairs where both attempts completed. Positive duration means slower. No findings are pooled across repeats.",
    ]
    if not result.get("per_task"):
        lines.append(
            "This suite does not expose native per-task scores. Per-task comparisons cover completion and duration only; aggregate native metrics remain above."
        )
    if config["suite"] == "martian":
        lines += [
            "",
            "[Blind finding audit](blind-review.json): up to 20 unmatched findings, balanced across available configurations. This is a diagnostic sample, not a precision estimate. Manual verdicts start unresolved and never change native scores. Keep [unblinding metadata](audit-unblinding.json) separate until review is complete.",
        ]
    native_pairs = result.get("paired_descriptive", [])
    if native_pairs:
        lines += [
            "",
            "Native descriptive recall@10 pairs, including the scorer's failed-task handling:",
            "",
            "| Role | Repeat | Left | Right | Paired tasks | Left wins | Right wins | Ties |",
            "|---|---:|---|---|---:|---:|---:|---:|",
        ]
        for row in native_pairs:
            lines.append(
                f"| {row['role']} | {row['repeat']} | {row['left']} | {row['right']} | {row['paired_tasks']} | {row.get('left_wins', 0)} | {row.get('right_wins', 0)} | {row.get('ties', 0)} |"
            )
    if repeats:
        lines += [
            "",
            "## Repeat summaries",
            "",
            "Each row summarizes native per-repeat scores on the identical scheduled task cohort. Incomplete or suppressed repeats suppress the summary. These are descriptive ranges, not confidence intervals.",
            "",
            "| Configuration | Role | Scope | Metric | Mean | Min | Max | Sample SD | Complete |",
            "|---|---|---|---|---:|---:|---:|---:|---|",
        ]
        for row in repeats:
            vals = [
                "unavailable" if row[k] is None else f"{row[k]:.4f}"
                for k in ("mean", "min", "max", "sample_stddev")
            ]
            lines.append(
                f"| {row['configuration']} | {row['role']} | {row['scope']} | {row['metric']} | "
                + " | ".join(vals)
                + f" | {row['complete']} |"
            )
    lines += [
        "",
        "## Audit appendix",
        "",
        f"Run fingerprint: `{audit.get('run_fingerprint') or 'unverified'}`.",
        "[Audit metadata](audit.json) contains exact file hashes, arm settings, source revision, requested and observed models when recorded. Captured manifests and source-access audits are under `evidence/`; source availability is a dated observation.",
        "The bundle contains only this schedule's gateway traces. Routing credentials are not copied.",
    ]
    return lines


def render(run_dir, config, attempts, result, *, root=None, trace_dir=None):
    from .core import ROOT

    root = Path(root or ROOT)
    trace_dir = Path(trace_dir or root / ".gateway" / "traces")
    series = result.get("report_series", [])
    if not series:
        raise EvalError("Suite returned no declared report series")
    fields = [
        "configuration",
        "repeat",
        "role",
        "metric",
        "value",
        "unit",
        "direction",
        "denominator",
        "scope",
        "primary",
        "complete",
    ]
    with (run_dir / "metrics.csv").open("w") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(series)
    traces = capture_traces(run_dir, config, attempts, trace_dir)
    pairs = paired_deltas(config, attempts, result)
    repeats = summarize_repeats(config, attempts, series)
    audit = audit_bundle(run_dir, config, attempts, result, root)
    if config["suite"] == "martian":
        blind_audit_sample(
            run_dir,
            {
                **config,
                "fixture": config.get("fixture") or result.get("evidence_type") == "fixture",
            },
            attempts,
        )
    atomic_json(run_dir / "paired-deltas.json", pairs)
    atomic_json(run_dir / "repeat-summary.json", repeats)
    operational = []
    groups = defaultdict(list)
    for attempt in attempts:
        groups[(attempt["configuration"], attempt["repeat"], attempt["role"])].append(attempt)
    for (arm, repeat, role), values in sorted(groups.items()):
        durations = [
            a["duration_seconds"]
            for a in values
            if a["status"] == "completed" and a.get("duration_seconds") is not None
        ]
        operational.append(
            {
                "configuration": arm,
                "repeat": repeat,
                "role": role,
                "scheduled": len(values),
                "completed": sum(a["status"] == "completed" for a in values),
                "median_duration_seconds": median(durations) if durations else None,
            }
        )
    atomic_json(run_dir / "operational.json", operational)
    complete = bool(result.get("complete")) and all(a["status"] == "completed" for a in attempts)
    status = "COMPLETE" if complete else "INCOMPLETE"
    fixture = result.get("evidence_type") == "fixture" or config.get("fixture", False)
    label = "SYNTHETIC FIXTURE, NOT MEASURED" if fixture else "Controlled public-subset pilot"
    lines = [
        f"# {config['suite']}: {status}",
        "",
        label,
        "",
        f"Run: `{config['run_id']}`. Baseline: `{config['baseline']}`. Repeats: {config['repeats']}.",
        "",
        "Scores below are the suite's native metrics. Operational failures remain visible.",
        "",
        "| Configuration | Repeat | Role | Scope | Metric | Value | Denominator | Complete |",
        "|---|---:|---|---|---|---:|---:|---|",
    ]
    for row in series:
        value = "unavailable" if row["value"] is None else f"{row['value']:.4f}"
        lines.append(
            f"| {row['configuration']} | {row['repeat']} | {row['role']} | {row['scope']} | {row['metric']} | {value} | {row['denominator']} | {row['complete']} |"
        )
    lines += [
        "",
        "## Coverage and timing",
        "",
        "| Configuration | Repeat | Role | Completed / Scheduled | Median seconds |",
        "|---|---:|---|---:|---:|",
    ]
    for row in operational:
        lines.append(
            f"| {row['configuration']} | {row['repeat']} | {row['role']} | {row['completed']}/{row['scheduled']} | {row['median_duration_seconds']} |"
        )
    lines += evidence_markdown(config, traces, pairs, repeats, audit, result)
    lines += [
        "",
        "## Interpretation",
        "",
        "Descriptive pilot, not statistical superiority or an official leaderboard result.",
        "Native CodeRabbit search calls and internal costs are not observable. Different suites are not averaged.",
        "See grading artifacts for native matching, exclusions, suppression and denominator checks.",
    ]
    (run_dir / "report.md").write_text("\n".join(lines) + "\n")
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    primary = [r for r in series if r["primary"]]
    fig, axes = plt.subplots(1, 2, figsize=(11, 4), layout="constrained")
    valid = [r for r in primary if r["value"] is not None]
    axes[0].bar(
        [f"{r['configuration']} / {r['repeat']} / {r['role']} / {r['scope']}" for r in valid],
        [r["value"] for r in valid],
        color="#3764c7",
    )
    axes[0].set_title(primary[0]["metric"] if primary else "No primary metric")
    axes[0].tick_params(axis="x", rotation=30)
    timed = [r for r in operational if r["median_duration_seconds"] is not None]
    axes[1].bar(
        [f"{r['configuration']} / {r['repeat']} / {r['role']}" for r in timed],
        [r["median_duration_seconds"] for r in timed],
        color="#249c84",
    )
    axes[1].set_title("Completed episode/review median seconds")
    axes[1].tick_params(axis="x", rotation=30)
    fig.suptitle(f"{config['suite']} | {status} | {len(attempts)} scheduled attempts\n{label}")
    fig.savefig(run_dir / "results.png", dpi=160)
    fig.savefig(run_dir / "results.svg")
    plt.close(fig)
    return {
        "complete": complete,
        "report": str(run_dir / "report.md"),
        "chart": str(run_dir / "results.png"),
    }
