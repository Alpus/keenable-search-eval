"""Explicitly authorized original Martian model grading with raw transport evidence."""

import asyncio
import json
import os
from pathlib import Path

import httpx
from openai import AsyncOpenAI

from .core import (
    ROOT,
    EvalError,
    Experiment,
    atomic_json,
    frozen_manifest,
    lock,
    verify_allowance,
    verify_run_code,
)


def grade_live(run_dir: Path):
    state = json.loads((run_dir / "state.json").read_text())
    config = Experiment.model_validate(state["config"])
    verify_run_code(state, ROOT)
    if config.suite != "martian":
        raise EvalError("DevDex grading is deterministic; use report, not grade")
    with lock(ROOT / ".gateway/runner.lock"):
        verify_allowance(config, ROOT, len(state["attempts"]))
        return asyncio.run(_grade(state, config, run_dir))


async def _grade(state, config, run_dir):
    from .suites import martian

    manifest = frozen_manifest(run_dir, state)
    settings = config.suite_options.get("judge", manifest.get("judge", {}))
    if not settings.get("historical_structured_output_verified") and not settings.get(
        "protocol_variant_accepted"
    ):
        raise EvalError(
            "Historical judge parameters remain unverified; record an explicitly accepted protocol variant first"
        )
    base_url = os.getenv("MARTIAN_BASE_URL", "")
    key = os.getenv("MARTIAN_API_KEY", "")
    if not base_url.startswith("https://") or not key:
        raise EvalError("Set verified MARTIAN_BASE_URL and MARTIAN_API_KEY")
    tasks = {t["id"]: t for t in manifest["tasks"]}
    originals = martian.gold_records()
    graded = []
    for attempt in state["attempts"]:
        if attempt["status"] != "completed":
            continue
        folder = run_dir / attempt["artifact_dir"]
        target = folder / "martian-grading.json"
        raw = json.loads((folder / "github.json").read_text())
        projected = martian.project_github_pages(raw)["comments"]
        task = tasks[attempt["task_id"]]
        gold = (
            originals[task["golden_url"]]["comments"] if task["role"] == "scored" else task["gold"]
        )
        if target.exists():
            await martian.replay_pipeline(
                json.loads(target.read_text()),
                projected,
                gold,
                settings,
                fixed_target=task.get("fixed_target") if task["role"] == "control" else None,
            )
            graded.append(attempt["id"])
            continue
        ledger = folder / "judge-http.json"
        entries = json.loads(ledger.read_text()) if ledger.exists() else []
        if entries:
            raise EvalError(
                "Prior incomplete grading contains charged-call evidence; no automatic replay"
            )
        max_calls = config.suite_options.get("max_judge_calls_per_attempt")
        if type(max_calls) is not int or max_calls < 1:
            raise EvalError("Freeze max_judge_calls_per_attempt before inference")

        async def on_request(request):
            verify_allowance(config, ROOT, len(state["attempts"]))
            if len(entries) >= max_calls:
                raise EvalError("Judge call cap exhausted")
            request.extensions["search_eval_ledger_index"] = len(entries)
            entries.append(
                {
                    "method": request.method,
                    "url": str(request.url),
                    "body": json.loads(request.content),
                    "status": "reserved",
                }
            )
            atomic_json(ledger, entries)

        async def on_response(response):
            await response.aread()
            # Original matching may issue concurrent requests and complete out of order.
            index = response.request.extensions["search_eval_ledger_index"]
            body = response.json()
            entries[index].update({"status": response.status_code, "response": body})
            atomic_json(ledger, entries)
            if (
                response.status_code == 200
                and settings.get("model")
                and body.get("model") != settings["model"]
            ):
                raise EvalError("Judge returned an unexpected or missing model identity")

        async with httpx.AsyncClient(
            event_hooks={"request": [on_request], "response": [on_response]}
        ) as http:
            client = AsyncOpenAI(
                base_url=base_url, api_key=key, http_client=http, max_retries=0, timeout=120
            )
            clients = martian.pipeline_clients(client, settings)
            martian.configure_single_attempt_clients(clients)

            def before_judging(required):
                if len(entries) + required > max_calls:
                    raise EvalError("Complete judge matrix exceeds the remaining call budget")

            saved = await martian.run_pipeline(
                projected,
                gold,
                *clients,
                settings=settings,
                fixed_target=task.get("fixed_target") if task["role"] == "control" else None,
                before_judging=before_judging,
            )
            atomic_json(target, saved)
            graded.append(attempt["id"])
    return {
        "graded_attempts": graded,
        "report_command": f"search-eval report --run {config.run_id}",
    }
