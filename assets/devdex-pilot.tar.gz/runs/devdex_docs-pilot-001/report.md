# devdex_docs: COMPLETE

Controlled public-subset pilot

Run: `devdex_docs-pilot-001`. Baseline: `exa`. Repeats: 1.

Scores below are the suite's native metrics. Operational failures remain visible.

| Configuration | Repeat | Role | Scope | Metric | Value | Denominator | Complete |
|---|---:|---|---|---|---:|---:|---|
| exa | 1 | scored | docs | recall@10 | 0.3333 | 30 | True |
| exa | 1 | scored | docs | MRR@10 | 0.3167 | 30 | True |
| keenable | 1 | scored | docs | recall@10 | 0.3000 | 30 | True |
| keenable | 1 | scored | docs | MRR@10 | 0.3000 | 30 | True |

## Coverage and timing

| Configuration | Repeat | Role | Completed / Scheduled | Median seconds |
|---|---:|---|---:|---:|
| exa | 1 | scored | 30/30 | 20.320667655500074 |
| keenable | 1 | scored | 30/30 | 17.161498070499874 |

## Search evidence

Counts are observed gateway reservations, including failed or unfinished calls. Missing traces mean unknown, not zero. Rejected calls are recorded separately when attributable. Unauthenticated/unattributed events remain gateway-local and are not assigned to a run. Native CodeRabbit tool calls remain unknown.

| Configuration | Repeat | Role | Traces / Attempts | Search | Fetch | Failed | Unfinished | Rejected | Native search |
|---|---:|---|---:|---:|---:|---:|---:|---:|---|
| exa | 1 | scored | 30/30 | 62 | 4 | 0 | 0 | unknown | not applicable |
| keenable | 1 | scored | 30/30 | 62 | 2 | 0 | 0 | unknown | not applicable |

Exact attempts, trace paths and hashes: [tool-calls.json](tool-calls.json).

## Paired comparisons

[Per-task deltas](paired-deltas.json) subtract the baseline on the same task, role and repeat. Missing pairs stay unavailable. Duration includes only pairs where both attempts completed. Positive duration means slower. No findings are pooled across repeats.

Native descriptive recall@10 pairs, including the scorer's failed-task handling:

| Role | Repeat | Left | Right | Paired tasks | Left wins | Right wins | Ties |
|---|---:|---|---|---:|---:|---:|---:|
| scored | 1 | exa | keenable | 30 | 4 | 3 | 23 |

## Audit appendix

Run fingerprint: `5614fdf36ebd9e26ad48943beed88ca5d13206439f0b4f1bc8917a4867224e08`.
[Audit metadata](audit.json) contains exact file hashes, arm settings, source revision, requested and observed models when recorded. Captured manifests and source-access audits are under `evidence/`; source availability is a dated observation.
The bundle contains only this schedule's gateway traces. Routing credentials are not copied.

## Interpretation

Descriptive pilot, not statistical superiority or an official leaderboard result.
Native CodeRabbit search calls and internal costs are not observable. Different suites are not averaged.
See grading artifacts for native matching, exclusions, suppression and denominator checks.
