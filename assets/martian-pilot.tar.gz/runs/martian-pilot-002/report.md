# martian: COMPLETE

Controlled public-subset pilot

Run: `martian-pilot-002`. Baseline: `native`. Repeats: 1.

Scores below are the suite's native metrics. Operational failures remain visible.

## Models and inputs

[Resolved inputs](effective-inputs.json) record controlled settings and provider-managed defaults.


Dataset: `data/martian-pilot.json`; SHA256: `62173f97f581a36ccb107b9c8ed7fd63f945c19c03237b35946995b71758a15b`.
Scorer: `martian-original` at `e616e849755441da38f18bf3adba2c9583b03803`. File hashes are in resolved inputs.
Schedule seed: `1729`; repeats: `1`. The schedule seed does not control model sampling.
Requested search configurations: `native` (native=True, MCP=none); `none` (native=False, MCP=none); `keenable` (native=False, MCP=keenable); `exa` (native=False, MCP=exa).
Requested provider modes: `exa`: `auto` / `authenticated`; `keenable`: `pro` / `authenticated`.
Limits: `{"episode_timeout_seconds": 720, "max_attempts": 40, "max_fetch_calls": 8, "max_review_events_per_hour": null, "max_search_calls": 8, "poll_seconds": 10, "review_timeout_seconds": 1800}`.
Requested settings do not prove service application. Observed model IDs appear below; tool calls and responses remain in the evidence bundle. Unreported internal defaults remain unknown.

| Stage | Requested model | Observed model | Evidence limit |
|---|---|---|---|
| CodeRabbit reviewer | not selectable / unrecorded | not observed | Service-managed; model identity is not exposed by this integration |
| Martian extraction, deduplication and judge | claude-opus-4-5-20251101 | claude-opus-4-5-20251101 | Only successful saved HTTP responses establish observed identity |

## Native scores

| Configuration | Repeat | Role | Scope | Metric | Value | Denominator | Complete |
|---|---:|---|---|---|---:|---:|---|
| exa | 1 | scored | core | precision | 0.3250 | 28 | True |
| exa | 1 | scored | core | recall | 0.4643 | 28 | True |
| exa | 1 | scored | core | f1 | 0.3824 | 28 | True |
| exa | 1 | scored | core | F2 | 0.4276 | 28 | True |
| exa | 1 | scored | core | tp | 13.0000 | 28 | True |
| exa | 1 | scored | core | fp | 27.0000 | 28 | True |
| exa | 1 | scored | core | fn | 15.0000 | 28 | True |
| exa | 1 | scored | core | prs | 10.0000 | 28 | True |
| exa | 1 | scored | strict | precision | 0.2703 | 19 | True |
| exa | 1 | scored | strict | recall | 0.5263 | 19 | True |
| exa | 1 | scored | strict | f1 | 0.3571 | 19 | True |
| exa | 1 | scored | strict | F2 | 0.4425 | 19 | True |
| exa | 1 | scored | strict | tp | 10.0000 | 19 | True |
| exa | 1 | scored | strict | fp | 27.0000 | 19 | True |
| exa | 1 | scored | strict | fn | 9.0000 | 19 | True |
| exa | 1 | scored | strict | prs | 10.0000 | 19 | True |
| exa | 1 | scored | all | precision | 0.3415 | 32 | True |
| exa | 1 | scored | all | recall | 0.4375 | 32 | True |
| exa | 1 | scored | all | f1 | 0.3836 | 32 | True |
| exa | 1 | scored | all | F2 | 0.4142 | 32 | True |
| exa | 1 | scored | all | tp | 14.0000 | 32 | True |
| exa | 1 | scored | all | fp | 27.0000 | 32 | True |
| exa | 1 | scored | all | fn | 18.0000 | 32 | True |
| exa | 1 | scored | all | prs | 10.0000 | 32 | True |
| keenable | 1 | scored | core | precision | 0.4571 | 28 | True |
| keenable | 1 | scored | core | recall | 0.5714 | 28 | True |
| keenable | 1 | scored | core | f1 | 0.5079 | 28 | True |
| keenable | 1 | scored | core | F2 | 0.5442 | 28 | True |
| keenable | 1 | scored | core | tp | 16.0000 | 28 | True |
| keenable | 1 | scored | core | fp | 19.0000 | 28 | True |
| keenable | 1 | scored | core | fn | 12.0000 | 28 | True |
| keenable | 1 | scored | core | prs | 10.0000 | 28 | True |
| keenable | 1 | scored | strict | precision | 0.3667 | 19 | True |
| keenable | 1 | scored | strict | recall | 0.5789 | 19 | True |
| keenable | 1 | scored | strict | f1 | 0.4490 | 19 | True |
| keenable | 1 | scored | strict | F2 | 0.5189 | 19 | True |
| keenable | 1 | scored | strict | tp | 11.0000 | 19 | True |
| keenable | 1 | scored | strict | fp | 19.0000 | 19 | True |
| keenable | 1 | scored | strict | fn | 8.0000 | 19 | True |
| keenable | 1 | scored | strict | prs | 10.0000 | 19 | True |
| keenable | 1 | scored | all | precision | 0.4722 | 32 | True |
| keenable | 1 | scored | all | recall | 0.5312 | 32 | True |
| keenable | 1 | scored | all | f1 | 0.5000 | 32 | True |
| keenable | 1 | scored | all | F2 | 0.5183 | 32 | True |
| keenable | 1 | scored | all | tp | 17.0000 | 32 | True |
| keenable | 1 | scored | all | fp | 19.0000 | 32 | True |
| keenable | 1 | scored | all | fn | 15.0000 | 32 | True |
| keenable | 1 | scored | all | prs | 10.0000 | 32 | True |
| native | 1 | scored | core | precision | 0.3714 | 28 | True |
| native | 1 | scored | core | recall | 0.4643 | 28 | True |
| native | 1 | scored | core | f1 | 0.4127 | 28 | True |
| native | 1 | scored | core | F2 | 0.4422 | 28 | True |
| native | 1 | scored | core | tp | 13.0000 | 28 | True |
| native | 1 | scored | core | fp | 22.0000 | 28 | True |
| native | 1 | scored | core | fn | 15.0000 | 28 | True |
| native | 1 | scored | core | prs | 10.0000 | 28 | True |
| native | 1 | scored | strict | precision | 0.2667 | 19 | True |
| native | 1 | scored | strict | recall | 0.4211 | 19 | True |
| native | 1 | scored | strict | f1 | 0.3265 | 19 | True |
| native | 1 | scored | strict | F2 | 0.3774 | 19 | True |
| native | 1 | scored | strict | tp | 8.0000 | 19 | True |
| native | 1 | scored | strict | fp | 22.0000 | 19 | True |
| native | 1 | scored | strict | fn | 11.0000 | 19 | True |
| native | 1 | scored | strict | prs | 10.0000 | 19 | True |
| native | 1 | scored | all | precision | 0.3889 | 32 | True |
| native | 1 | scored | all | recall | 0.4375 | 32 | True |
| native | 1 | scored | all | f1 | 0.4118 | 32 | True |
| native | 1 | scored | all | F2 | 0.4268 | 32 | True |
| native | 1 | scored | all | tp | 14.0000 | 32 | True |
| native | 1 | scored | all | fp | 22.0000 | 32 | True |
| native | 1 | scored | all | fn | 18.0000 | 32 | True |
| native | 1 | scored | all | prs | 10.0000 | 32 | True |
| none | 1 | scored | core | precision | 0.4615 | 28 | True |
| none | 1 | scored | core | recall | 0.6429 | 28 | True |
| none | 1 | scored | core | f1 | 0.5373 | 28 | True |
| none | 1 | scored | core | F2 | 0.5960 | 28 | True |
| none | 1 | scored | core | tp | 18.0000 | 28 | True |
| none | 1 | scored | core | fp | 21.0000 | 28 | True |
| none | 1 | scored | core | fn | 10.0000 | 28 | True |
| none | 1 | scored | core | prs | 10.0000 | 28 | True |
| none | 1 | scored | strict | precision | 0.3636 | 19 | True |
| none | 1 | scored | strict | recall | 0.6316 | 19 | True |
| none | 1 | scored | strict | f1 | 0.4615 | 19 | True |
| none | 1 | scored | strict | F2 | 0.5505 | 19 | True |
| none | 1 | scored | strict | tp | 12.0000 | 19 | True |
| none | 1 | scored | strict | fp | 21.0000 | 19 | True |
| none | 1 | scored | strict | fn | 7.0000 | 19 | True |
| none | 1 | scored | strict | prs | 10.0000 | 19 | True |
| none | 1 | scored | all | precision | 0.4750 | 32 | True |
| none | 1 | scored | all | recall | 0.5938 | 32 | True |
| none | 1 | scored | all | f1 | 0.5278 | 32 | True |
| none | 1 | scored | all | F2 | 0.5655 | 32 | True |
| none | 1 | scored | all | tp | 19.0000 | 32 | True |
| none | 1 | scored | all | fp | 21.0000 | 32 | True |
| none | 1 | scored | all | fn | 13.0000 | 32 | True |
| none | 1 | scored | all | prs | 10.0000 | 32 | True |

## Coverage and timing

| Configuration | Repeat | Role | Completed / Scheduled | Median seconds |
|---|---:|---|---:|---:|
| exa | 1 | scored | 10/10 | 547.0 |
| keenable | 1 | scored | 10/10 | 594.5 |
| native | 1 | scored | 10/10 | 548.5 |
| none | 1 | scored | 10/10 | 593.0 |

## Search latency

Successful attributed search calls only, measured at the gateway. This is separate from end-to-end review time. Failed calls and missing traces stay visible; no native-search latency is inferred.

| Configuration | Repeat | Role | Successful timed calls | Median seconds | Failed search calls |
|---|---:|---|---:|---:|---:|
| exa | 1 | scored | 36 | 1.7559219380000286 | 0 |
| keenable | 1 | scored | 39 | 0.5310796669982665 | 0 |
| native | 1 | scored | 0 | None | 0 |
| none | 1 | scored | 0 | None | 0 |

Exact per-call observations: [search-latency.json](search-latency.json).

## Search evidence

Counts are observed gateway reservations, including failed or unfinished calls. Missing traces mean unknown, not zero. Rejected calls are recorded separately when attributable. Unauthenticated/unattributed events remain gateway-local and are not assigned to a run. Native CodeRabbit tool calls remain unknown.

| Configuration | Repeat | Role | Traces / Attempts | Search | Fetch | Failed | Unfinished | Rejected | Native search |
|---|---:|---|---:|---:|---:|---:|---:|---:|---|
| exa | 1 | scored | 10/10 | 36 | 52 | 2 | 0 | 5 (partial) | unknown |
| keenable | 1 | scored | 10/10 | 39 | 43 | 4 | 0 | unknown | unknown |
| native | 1 | scored | 0/10 | unknown | unknown | unknown | unknown | unknown | unknown |
| none | 1 | scored | 0/10 | unknown | unknown | unknown | unknown | unknown | unknown |

Exact attempts, trace paths and hashes: [tool-calls.json](tool-calls.json).

## Paired comparisons

[Per-task evidence](per-task-evidence.json) joins frozen suite annotations, gateway counts and baseline comparisons. UNKNOWN means no frozen relevance annotation. These tags do not prove search necessity or causal benefit.

[Per-task deltas](paired-deltas.json) subtract the baseline on the same task, role and repeat. Missing pairs stay unavailable. Duration includes only pairs where both attempts completed. Positive duration means slower. No findings are pooled across repeats.

Core F2 per-task differences are descriptive diagnostics. They do not replace the frozen full-cohort headline policy.

| Task | Configuration | Repeat | Role | Core F2 | Baseline Core F2 | Difference |
|---|---|---:|---|---:|---:|---:|
| grafana-107534 | none | 1 | scored | 0.0000 | 0.0000 | 0.0000 |
| grafana-107534 | exa | 1 | scored | 0.0000 | 0.0000 | 0.0000 |
| grafana-107534 | keenable | 1 | scored | 0.0000 | 0.0000 | 0.0000 |
| discourse-graphite-2 | keenable | 1 | scored | 0.7143 | 0.5556 | 0.1587 |
| discourse-graphite-2 | none | 1 | scored | 0.6250 | 0.5556 | 0.0694 |
| discourse-graphite-2 | exa | 1 | scored | 0.6250 | 0.5556 | 0.0694 |
| discourse-graphite-1 | exa | 1 | scored | 0.5000 | 0.2778 | 0.2222 |
| discourse-graphite-1 | none | 1 | scored | 0.4762 | 0.2778 | 0.1984 |
| discourse-graphite-1 | keenable | 1 | scored | 0.5263 | 0.2778 | 0.2485 |
| sentry-93824 | none | 1 | scored | 0.8333 | 0.5769 | 0.2564 |
| sentry-93824 | keenable | 1 | scored | 1.0000 | 0.5769 | 0.4231 |
| sentry-93824 | exa | 1 | scored | 0.4000 | 0.5769 | -0.1769 |
| sentry-80168 | keenable | 1 | scored | 0.3125 | 0.3846 | -0.0721 |
| sentry-80168 | exa | 1 | scored | 0.3571 | 0.3846 | -0.0275 |
| sentry-80168 | none | 1 | scored | 0.3333 | 0.3846 | -0.0513 |
| grafana-80329 | none | 1 | scored | 1.0000 | 0.5000 | 0.5000 |
| grafana-80329 | exa | 1 | scored | 0.4167 | 0.5000 | -0.0833 |
| grafana-80329 | keenable | 1 | scored | 0.5556 | 0.5000 | 0.0556 |
| cal.com-14740 | none | 1 | scored | 0.6452 | 0.4839 | 0.1613 |
| cal.com-14740 | keenable | 1 | scored | 0.5000 | 0.4839 | 0.0161 |
| cal.com-14740 | exa | 1 | scored | 0.5172 | 0.4839 | 0.0334 |
| keycloak-38446 | exa | 1 | scored | 0.0000 | 0.0000 | 0.0000 |
| keycloak-38446 | none | 1 | scored | 0.4167 | 0.0000 | 0.4167 |
| keycloak-38446 | keenable | 1 | scored | 0.0000 | 0.0000 | 0.0000 |
| keycloak-37429 | none | 1 | scored | 0.5556 | 0.5556 | 0.0000 |
| keycloak-37429 | keenable | 1 | scored | 0.5882 | 0.5556 | 0.0327 |
| keycloak-37429 | exa | 1 | scored | 0.5263 | 0.5556 | -0.0292 |
| cal.com-8087 | keenable | 1 | scored | 0.7143 | 0.6250 | 0.0893 |
| cal.com-8087 | none | 1 | scored | 0.7143 | 0.6250 | 0.0893 |
| cal.com-8087 | exa | 1 | scored | 0.8333 | 0.6250 | 0.2083 |
Predeclared headline policy: all scheduled tasks must have valid native grading. Any missing or failed outcome suppresses every headline value. Successful per-task scores remain diagnostic only; no post-hoc complete-case replacement is made.
Reconstructed pilot inputs use frozen source trees, titles from the gold metadata and a neutral PR body. These are identical across arms but differ from historical benchmark PR descriptions. Original scoring is preserved; historical leaderboard comparability is not claimed.

[Blind finding audit](blind-review.json): up to 20 unmatched findings, balanced across available configurations. This is a diagnostic sample, not a precision estimate. Manual verdicts start unresolved and never change native scores. Keep [unblinding metadata](audit-unblinding.json) separate until review is complete.

## Audit appendix

Run fingerprint: `5d60c60380f59b5275695a9f8acfaf8fce03a5ae69fa4d2a5de35ba2c4a836e1`.
[Audit metadata](audit.json) contains exact file hashes, arm settings, source revision, requested and observed models when recorded. Captured manifests and source-access audits are under `evidence/`; source availability is a dated observation.
The bundle contains only this schedule's gateway traces. Routing credentials are not copied.

## Per-task evidence

| Task | Configuration | Repeat | Role | Relevance | Search | Fetch | Baseline attempt |
|---|---|---:|---|---|---:|---:|---|
| grafana-107534 | none | 1 | scored | LOCAL | unknown | unknown | 65c12c359f29f458c6b666a4 |
| grafana-107534 | exa | 1 | scored | LOCAL | 6 | 4 | 65c12c359f29f458c6b666a4 |
| grafana-107534 | native | 1 | scored | LOCAL | unknown | unknown | 65c12c359f29f458c6b666a4 |
| grafana-107534 | keenable | 1 | scored | LOCAL | 5 | 7 | 65c12c359f29f458c6b666a4 |
| discourse-graphite-2 | keenable | 1 | scored | LOCAL | 2 | 4 | d83779928686df9bed698e03 |
| discourse-graphite-2 | none | 1 | scored | LOCAL | unknown | unknown | d83779928686df9bed698e03 |
| discourse-graphite-2 | native | 1 | scored | LOCAL | unknown | unknown | d83779928686df9bed698e03 |
| discourse-graphite-2 | exa | 1 | scored | LOCAL | 2 | 3 | d83779928686df9bed698e03 |
| discourse-graphite-1 | native | 1 | scored | EXTERNAL_PLAUSIBLE | unknown | unknown | 0d351c611362028df716b734 |
| discourse-graphite-1 | exa | 1 | scored | EXTERNAL_PLAUSIBLE | 3 | 7 | 0d351c611362028df716b734 |
| discourse-graphite-1 | none | 1 | scored | EXTERNAL_PLAUSIBLE | unknown | unknown | 0d351c611362028df716b734 |
| discourse-graphite-1 | keenable | 1 | scored | EXTERNAL_PLAUSIBLE | 7 | 8 | 0d351c611362028df716b734 |
| sentry-93824 | native | 1 | scored | EXTERNAL_PLAUSIBLE | unknown | unknown | a6d333eb1513fa7be19397da |
| sentry-93824 | none | 1 | scored | EXTERNAL_PLAUSIBLE | unknown | unknown | a6d333eb1513fa7be19397da |
| sentry-93824 | keenable | 1 | scored | EXTERNAL_PLAUSIBLE | 7 | 5 | a6d333eb1513fa7be19397da |
| sentry-93824 | exa | 1 | scored | EXTERNAL_PLAUSIBLE | 1 | 3 | a6d333eb1513fa7be19397da |
| sentry-80168 | keenable | 1 | scored | LOCAL | 2 | 3 | bbc310efa4902280be146ff0 |
| sentry-80168 | native | 1 | scored | LOCAL | unknown | unknown | bbc310efa4902280be146ff0 |
| sentry-80168 | exa | 1 | scored | LOCAL | 6 | 7 | bbc310efa4902280be146ff0 |
| sentry-80168 | none | 1 | scored | LOCAL | unknown | unknown | bbc310efa4902280be146ff0 |
| grafana-80329 | none | 1 | scored | LOCAL | unknown | unknown | c0f25c08398b1e9d65bdeb7a |
| grafana-80329 | exa | 1 | scored | LOCAL | 4 | 3 | c0f25c08398b1e9d65bdeb7a |
| grafana-80329 | keenable | 1 | scored | LOCAL | 2 | 3 | c0f25c08398b1e9d65bdeb7a |
| grafana-80329 | native | 1 | scored | LOCAL | unknown | unknown | c0f25c08398b1e9d65bdeb7a |
| cal.com-14740 | native | 1 | scored | LOCAL | unknown | unknown | 61c0a05dce8704f560151f41 |
| cal.com-14740 | none | 1 | scored | LOCAL | unknown | unknown | 61c0a05dce8704f560151f41 |
| cal.com-14740 | keenable | 1 | scored | LOCAL | 3 | 3 | 61c0a05dce8704f560151f41 |
| cal.com-14740 | exa | 1 | scored | LOCAL | 4 | 8 | 61c0a05dce8704f560151f41 |
| keycloak-38446 | exa | 1 | scored | LOCAL | 4 | 8 | e4276017631bf6d35fb5f366 |
| keycloak-38446 | none | 1 | scored | LOCAL | unknown | unknown | e4276017631bf6d35fb5f366 |
| keycloak-38446 | native | 1 | scored | LOCAL | unknown | unknown | e4276017631bf6d35fb5f366 |
| keycloak-38446 | keenable | 1 | scored | LOCAL | 2 | 1 | e4276017631bf6d35fb5f366 |
| keycloak-37429 | native | 1 | scored | LOCAL | unknown | unknown | c4b773a394fe8e02dbeb923e |
| keycloak-37429 | none | 1 | scored | LOCAL | unknown | unknown | c4b773a394fe8e02dbeb923e |
| keycloak-37429 | keenable | 1 | scored | LOCAL | 6 | 6 | c4b773a394fe8e02dbeb923e |
| keycloak-37429 | exa | 1 | scored | LOCAL | 3 | 5 | c4b773a394fe8e02dbeb923e |
| cal.com-8087 | native | 1 | scored | LOCAL | unknown | unknown | 33ed3e71f6fa8f8ce0e3ee6d |
| cal.com-8087 | keenable | 1 | scored | LOCAL | 3 | 3 | 33ed3e71f6fa8f8ce0e3ee6d |
| cal.com-8087 | none | 1 | scored | LOCAL | unknown | unknown | 33ed3e71f6fa8f8ce0e3ee6d |
| cal.com-8087 | exa | 1 | scored | LOCAL | 3 | 4 | 33ed3e71f6fa8f8ce0e3ee6d |

## Interpretation

Descriptive pilot, not statistical superiority or an official leaderboard result.
Native CodeRabbit search calls and internal costs are not observable. Different suites are not averaged.
See grading artifacts for native matching, exclusions, suppression and denominator checks.
