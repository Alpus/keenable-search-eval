# martian: INCOMPLETE

Live controls, excluded from benchmark results

Run: `martian-controls-002`. Baseline: `native`. Repeats: 1.

Scores below are the suite's native metrics. Operational failures remain visible.

## Models and inputs

[Resolved inputs](effective-inputs.json) record controlled settings and provider-managed defaults.


Dataset: `data/martian-pilot.json`; SHA256: `62173f97f581a36ccb107b9c8ed7fd63f945c19c03237b35946995b71758a15b`.
Scorer: `martian-original` at `e616e849755441da38f18bf3adba2c9583b03803`. File hashes are in resolved inputs.
Schedule seed: `1729`; repeats: `1`. The schedule seed does not control model sampling.
Requested search configurations: `native` (native=True, MCP=none); `none` (native=False, MCP=none); `keenable` (native=False, MCP=keenable); `exa` (native=False, MCP=exa).
Requested provider modes: `exa`: `auto` / `authenticated`; `keenable`: `pro` / `authenticated`.
Limits: `{"episode_timeout_seconds": 720, "max_attempts": 8, "max_fetch_calls": 8, "max_review_events_per_hour": null, "max_search_calls": 8, "poll_seconds": 10, "review_timeout_seconds": 1800}`.
Requested settings do not prove service application. Observed model IDs appear below; tool calls and responses remain in the evidence bundle. Unreported internal defaults remain unknown.

| Stage | Requested model | Observed model | Evidence limit |
|---|---|---|---|
| CodeRabbit reviewer | not selectable / unrecorded | not observed | Service-managed; model identity is not exposed by this integration |
| Martian extraction, deduplication and judge | claude-opus-4-5-20251101 | claude-opus-4-5-20251101 | Only successful saved HTTP responses establish observed identity |

## Native scores

| Configuration | Repeat | Role | Scope | Metric | Value | Denominator | Complete |
|---|---:|---|---|---|---:|---:|---|
| exa | 1 | control | core | precision | unavailable | 2 | False |
| exa | 1 | control | core | recall | unavailable | 2 | False |
| exa | 1 | control | core | f1 | unavailable | 2 | False |
| exa | 1 | control | core | F2 | unavailable | 2 | False |
| exa | 1 | control | core | tp | unavailable | 2 | False |
| exa | 1 | control | core | fp | unavailable | 2 | False |
| exa | 1 | control | core | fn | unavailable | 2 | False |
| exa | 1 | control | core | prs | unavailable | 2 | False |
| exa | 1 | control | strict | precision | unavailable | 1 | False |
| exa | 1 | control | strict | recall | unavailable | 1 | False |
| exa | 1 | control | strict | f1 | unavailable | 1 | False |
| exa | 1 | control | strict | F2 | unavailable | 1 | False |
| exa | 1 | control | strict | tp | unavailable | 1 | False |
| exa | 1 | control | strict | fp | unavailable | 1 | False |
| exa | 1 | control | strict | fn | unavailable | 1 | False |
| exa | 1 | control | strict | prs | unavailable | 1 | False |
| exa | 1 | control | all | precision | unavailable | 2 | False |
| exa | 1 | control | all | recall | unavailable | 2 | False |
| exa | 1 | control | all | f1 | unavailable | 2 | False |
| exa | 1 | control | all | F2 | unavailable | 2 | False |
| exa | 1 | control | all | tp | unavailable | 2 | False |
| exa | 1 | control | all | fp | unavailable | 2 | False |
| exa | 1 | control | all | fn | unavailable | 2 | False |
| exa | 1 | control | all | prs | unavailable | 2 | False |
| keenable | 1 | control | core | precision | unavailable | 2 | False |
| keenable | 1 | control | core | recall | unavailable | 2 | False |
| keenable | 1 | control | core | f1 | unavailable | 2 | False |
| keenable | 1 | control | core | F2 | unavailable | 2 | False |
| keenable | 1 | control | core | tp | unavailable | 2 | False |
| keenable | 1 | control | core | fp | unavailable | 2 | False |
| keenable | 1 | control | core | fn | unavailable | 2 | False |
| keenable | 1 | control | core | prs | unavailable | 2 | False |
| keenable | 1 | control | strict | precision | unavailable | 1 | False |
| keenable | 1 | control | strict | recall | unavailable | 1 | False |
| keenable | 1 | control | strict | f1 | unavailable | 1 | False |
| keenable | 1 | control | strict | F2 | unavailable | 1 | False |
| keenable | 1 | control | strict | tp | unavailable | 1 | False |
| keenable | 1 | control | strict | fp | unavailable | 1 | False |
| keenable | 1 | control | strict | fn | unavailable | 1 | False |
| keenable | 1 | control | strict | prs | unavailable | 1 | False |
| keenable | 1 | control | all | precision | unavailable | 2 | False |
| keenable | 1 | control | all | recall | unavailable | 2 | False |
| keenable | 1 | control | all | f1 | unavailable | 2 | False |
| keenable | 1 | control | all | F2 | unavailable | 2 | False |
| keenable | 1 | control | all | tp | unavailable | 2 | False |
| keenable | 1 | control | all | fp | unavailable | 2 | False |
| keenable | 1 | control | all | fn | unavailable | 2 | False |
| keenable | 1 | control | all | prs | unavailable | 2 | False |
| native | 1 | control | core | precision | unavailable | 2 | False |
| native | 1 | control | core | recall | unavailable | 2 | False |
| native | 1 | control | core | f1 | unavailable | 2 | False |
| native | 1 | control | core | F2 | unavailable | 2 | False |
| native | 1 | control | core | tp | unavailable | 2 | False |
| native | 1 | control | core | fp | unavailable | 2 | False |
| native | 1 | control | core | fn | unavailable | 2 | False |
| native | 1 | control | core | prs | unavailable | 2 | False |
| native | 1 | control | strict | precision | unavailable | 1 | False |
| native | 1 | control | strict | recall | unavailable | 1 | False |
| native | 1 | control | strict | f1 | unavailable | 1 | False |
| native | 1 | control | strict | F2 | unavailable | 1 | False |
| native | 1 | control | strict | tp | unavailable | 1 | False |
| native | 1 | control | strict | fp | unavailable | 1 | False |
| native | 1 | control | strict | fn | unavailable | 1 | False |
| native | 1 | control | strict | prs | unavailable | 1 | False |
| native | 1 | control | all | precision | unavailable | 2 | False |
| native | 1 | control | all | recall | unavailable | 2 | False |
| native | 1 | control | all | f1 | unavailable | 2 | False |
| native | 1 | control | all | F2 | unavailable | 2 | False |
| native | 1 | control | all | tp | unavailable | 2 | False |
| native | 1 | control | all | fp | unavailable | 2 | False |
| native | 1 | control | all | fn | unavailable | 2 | False |
| native | 1 | control | all | prs | unavailable | 2 | False |
| none | 1 | control | core | precision | unavailable | 2 | False |
| none | 1 | control | core | recall | unavailable | 2 | False |
| none | 1 | control | core | f1 | unavailable | 2 | False |
| none | 1 | control | core | F2 | unavailable | 2 | False |
| none | 1 | control | core | tp | unavailable | 2 | False |
| none | 1 | control | core | fp | unavailable | 2 | False |
| none | 1 | control | core | fn | unavailable | 2 | False |
| none | 1 | control | core | prs | unavailable | 2 | False |
| none | 1 | control | strict | precision | unavailable | 1 | False |
| none | 1 | control | strict | recall | unavailable | 1 | False |
| none | 1 | control | strict | f1 | unavailable | 1 | False |
| none | 1 | control | strict | F2 | unavailable | 1 | False |
| none | 1 | control | strict | tp | unavailable | 1 | False |
| none | 1 | control | strict | fp | unavailable | 1 | False |
| none | 1 | control | strict | fn | unavailable | 1 | False |
| none | 1 | control | strict | prs | unavailable | 1 | False |
| none | 1 | control | all | precision | unavailable | 2 | False |
| none | 1 | control | all | recall | unavailable | 2 | False |
| none | 1 | control | all | f1 | unavailable | 2 | False |
| none | 1 | control | all | F2 | unavailable | 2 | False |
| none | 1 | control | all | tp | unavailable | 2 | False |
| none | 1 | control | all | fp | unavailable | 2 | False |
| none | 1 | control | all | fn | unavailable | 2 | False |
| none | 1 | control | all | prs | unavailable | 2 | False |

## Coverage and timing

| Configuration | Repeat | Role | Completed / Scheduled | Median seconds |
|---|---:|---|---:|---:|
| exa | 1 | control | 2/2 | 555.5 |
| keenable | 1 | control | 2/2 | 558.0 |
| native | 1 | control | 2/2 | 475.0 |
| none | 1 | control | 2/2 | 603.0 |

## Search latency

Successful attributed search calls only, measured at the gateway. This is separate from end-to-end review time. Failed calls and missing traces stay visible; no native-search latency is inferred.

| Configuration | Repeat | Role | Successful timed calls | Median seconds | Failed search calls |
|---|---:|---|---:|---:|---:|
| exa | 1 | control | 5 | 1.6750157510032295 | 0 |
| keenable | 1 | control | 9 | 1.227551208998193 | 0 |
| native | 1 | control | 0 | None | 0 |
| none | 1 | control | 0 | None | 0 |

Exact per-call observations: [search-latency.json](search-latency.json).

## Search evidence

Counts are observed gateway reservations, including failed or unfinished calls. Missing traces mean unknown, not zero. Rejected calls are recorded separately when attributable. Unauthenticated/unattributed events remain gateway-local and are not assigned to a run. Native CodeRabbit tool calls remain unknown.

| Configuration | Repeat | Role | Traces / Attempts | Search | Fetch | Failed | Unfinished | Rejected | Native search |
|---|---:|---|---:|---:|---:|---:|---:|---:|---|
| exa | 1 | control | 2/2 | 5 | 15 | 1 | 0 | unknown | unknown |
| keenable | 1 | control | 2/2 | 9 | 9 | 2 | 0 | unknown | unknown |
| native | 1 | control | 0/2 | unknown | unknown | unknown | unknown | unknown | unknown |
| none | 1 | control | 0/2 | unknown | unknown | unknown | unknown | unknown | unknown |

Exact attempts, trace paths and hashes: [tool-calls.json](tool-calls.json).

## Paired comparisons

[Per-task evidence](per-task-evidence.json) joins frozen suite annotations, gateway counts and baseline comparisons. UNKNOWN means no frozen relevance annotation. These tags do not prove search necessity or causal benefit.

[Per-task deltas](paired-deltas.json) subtract the baseline on the same task, role and repeat. Missing pairs stay unavailable. Duration includes only pairs where both attempts completed. Positive duration means slower. No findings are pooled across repeats.

Core F2 per-task differences are descriptive diagnostics. They do not replace the frozen full-cohort headline policy.

| Task | Configuration | Repeat | Role | Core F2 | Baseline Core F2 | Difference |
|---|---|---:|---|---:|---:|---:|
| sentry-80168-fixed-control | none | 1 | control | 0.4167 | 0.5000 | -0.0833 |
| sentry-80168-fixed-control | keenable | 1 | control | 0.4545 | 0.5000 | -0.0455 |
| sentry-80168-fixed-control | exa | 1 | control | 0.5000 | 0.5000 | 0.0000 |
Predeclared headline policy: all scheduled tasks must have valid native grading. Any missing or failed outcome suppresses every headline value. Successful per-task scores remain diagnostic only; no post-hoc complete-case replacement is made.
Reconstructed pilot inputs use frozen source trees, titles from the gold metadata and a neutral PR body. These are identical across arms but differ from historical benchmark PR descriptions. Original scoring is preserved; historical leaderboard comparability is not claimed.

[Blind finding audit](blind-review.json): up to 20 unmatched findings, balanced across available configurations. This is a diagnostic sample, not a precision estimate. Manual verdicts start unresolved and never change native scores. Keep [unblinding metadata](audit-unblinding.json) separate until review is complete.

## Audit appendix

Run fingerprint: `366b9cc850cc3ba1cf29aad10fcd6e07d80d3adf65a17d050454a4c33ba20a4d`.
[Audit metadata](audit.json) contains exact file hashes, arm settings, source revision, requested and observed models when recorded. Captured manifests and source-access audits are under `evidence/`; source availability is a dated observation.
The bundle contains only this schedule's gateway traces. Routing credentials are not copied.

## Per-task evidence

| Task | Configuration | Repeat | Role | Relevance | Search | Fetch | Baseline attempt |
|---|---|---:|---|---|---:|---:|---|
| sentry-80168-fixed-control | native | 1 | control | UNKNOWN | unknown | unknown | c583f7e1f8e26d21cfcc6338 |
| sentry-80168-fixed-control | none | 1 | control | UNKNOWN | unknown | unknown | c583f7e1f8e26d21cfcc6338 |
| sentry-80168-fixed-control | keenable | 1 | control | UNKNOWN | 3 | 2 | c583f7e1f8e26d21cfcc6338 |
| sentry-80168-fixed-control | exa | 1 | control | UNKNOWN | 2 | 8 | c583f7e1f8e26d21cfcc6338 |
| cal.com-14740-fixed-control | exa | 1 | control | UNKNOWN | 3 | 7 | a513cb1103cc62dad7376fd4 |
| cal.com-14740-fixed-control | native | 1 | control | UNKNOWN | unknown | unknown | a513cb1103cc62dad7376fd4 |
| cal.com-14740-fixed-control | keenable | 1 | control | UNKNOWN | 6 | 7 | a513cb1103cc62dad7376fd4 |
| cal.com-14740-fixed-control | none | 1 | control | UNKNOWN | unknown | unknown | a513cb1103cc62dad7376fd4 |

## Interpretation

Descriptive pilot, not statistical superiority or an official leaderboard result.
Native CodeRabbit search calls and internal costs are not observable. Different suites are not averaged.
See grading artifacts for native matching, exclusions, suppression and denominator checks.
