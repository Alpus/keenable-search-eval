# finding-011

Successful external recovery-code creation does not invalidate an existing Keycloak-managed set - if a user has an unconsumed local fallback credential and the external provider accepts a replacement set, external rejection of an older code still permits built-in validation against that older credential

## head: server-spi-private/src/main/java/org/keycloak/utils/CredentialHelper.java:110-132
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/server-spi-private/src/main/java/org/keycloak/utils/CredentialHelper.java#L110-L132

```text
110:     }
111: 
112:     /**
113:      * Create RecoveryCodes credential either in userStorage or local storage (Keycloak DB)
114:      */
115:     public static void createRecoveryCodesCredential(KeycloakSession session, RealmModel realm, UserModel user, RecoveryAuthnCodesCredentialModel credentialModel, List<String> generatedCodes) {
116:         var recoveryCodeCredentialProvider = session.getProvider(CredentialProvider.class, "keycloak-recovery-authn-codes");
117:         String recoveryCodesJson;
118:         try {
119:             recoveryCodesJson =  JsonSerialization.writeValueAsString(generatedCodes);
120:         } catch (IOException e) {
121:             throw new RuntimeException(e);
122:         }
123:         UserCredentialModel recoveryCodesCredential = new UserCredentialModel("", credentialModel.getType(), recoveryCodesJson);
124: 
125:         boolean userStorageCreated = user.credentialManager().updateCredential(recoveryCodesCredential);
126:         if (userStorageCreated) {
127:             logger.debugf("Created RecoveryCodes credential for user '%s' in the user storage", user.getUsername());
128:         } else {
129:             recoveryCodeCredentialProvider.createCredential(realm, user, credentialModel);
130:         }
131:     }
132: 
```

## head: services/src/main/java/org/keycloak/credential/RecoveryAuthnCodesCredentialProvider.java:35-43
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/services/src/main/java/org/keycloak/credential/RecoveryAuthnCodesCredentialProvider.java#L35-L43

```text
35:     @Override
36:     public CredentialModel createCredential(RealmModel realm, UserModel user,
37:             RecoveryAuthnCodesCredentialModel credentialModel) {
38: 
39:         user.credentialManager().getStoredCredentialsByTypeStream(getType()).findFirst()
40:                 .ifPresent(model -> deleteCredential(realm, user, model.getId()));
41: 
42:         return user.credentialManager().createStoredCredential(credentialModel);
43:     }
```

## head: model/storage/src/main/java/org/keycloak/credential/UserCredentialManager.java:58-79
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/model/storage/src/main/java/org/keycloak/credential/UserCredentialManager.java#L58-L79

```text
58:     @Override
59:     public boolean isValid(List<CredentialInput> inputs) {
60:         if (!isValid(user)) {
61:             return false;
62:         }
63: 
64:         List<CredentialInput> toValidate = new LinkedList<>(inputs);
65: 
66:         if (user.isFederated()) {
67:             UserStorageProviderModel model = getStorageProviderModel(realm, user.getFederationLink());
68:             if (model == null || !model.isEnabled()) return false;
69: 
70:             CredentialInputValidator validator = getStorageProviderInstance(model, CredentialInputValidator.class);
71:             if (validator != null) {
72:                 validate(realm, user, toValidate, validator);
73:             }
74:         }
75: 
76:         getCredentialProviders(session, CredentialInputValidator.class)
77:                 .forEach(validator -> validate(realm, user, toValidate, validator));
78: 
79:         return toValidate.isEmpty();
```

## head: model/storage/src/main/java/org/keycloak/credential/UserCredentialManager.java:270-282
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/model/storage/src/main/java/org/keycloak/credential/UserCredentialManager.java#L270-L282

```text
270:     private void validate(RealmModel realm, UserModel user, List<CredentialInput> toValidate, CredentialInputValidator validator) {
271:         toValidate.removeIf(input -> {
272:             if(validator.supportsCredentialType(input.getType())) {
273:                 return session.getProvider(TracingProvider.class).trace(validator.getClass(), "isValid", span -> {
274:                     boolean valid = validator.isValid(realm, user, input);
275:                     if (!valid) {
276:                         span.setStatus(StatusCode.ERROR);
277:                     }
278:                     return valid;
279:                 });
280:             }
281:             return false;
282:         });
```

## head: services/src/main/java/org/keycloak/credential/RecoveryAuthnCodesCredentialProvider.java:98-118
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/services/src/main/java/org/keycloak/credential/RecoveryAuthnCodesCredentialProvider.java#L98-L118

```text
98:     @Override
99:     public boolean isValid(RealmModel realm, UserModel user, CredentialInput credentialInput) {
100:         String rawInputRecoveryAuthnCode = credentialInput.getChallengeResponse();
101:         Optional<CredentialModel> credential = user.credentialManager().getStoredCredentialsByTypeStream(getType()).findFirst();
102:         if (credential.isPresent()) {
103:             RecoveryAuthnCodesCredentialModel credentialModel = RecoveryAuthnCodesCredentialModel
104:                     .createFromCredentialModel(credential.get());
105:             if (!credentialModel.allCodesUsed()) {
106:                 Optional<RecoveryAuthnCodeRepresentation> nextRecoveryAuthnCode = credentialModel.getNextRecoveryAuthnCode();
107:                 if (nextRecoveryAuthnCode.isPresent()) {
108:                     String nextRecoveryCode = nextRecoveryAuthnCode.get().getEncodedHashedValue();
109:                     if (RecoveryAuthnCodesUtils.verifyRecoveryCodeInput(rawInputRecoveryAuthnCode, nextRecoveryCode)) {
110:                         credentialModel.removeRecoveryAuthnCode();
111:                         user.credentialManager().updateStoredCredential(credentialModel);
112:                         return true;
113:                     }
114: 
115:                 }
116:             }
117:         }
118:         return false;
```
