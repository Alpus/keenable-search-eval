# finding-012

Calendar update failure is not recoverable - handler persists attendees before calling updateCalendarAttendees, ignores failed results, sends emails, and returns success. Retry with same guests rejects them as existing before calendar can be repaired

## head: packages/trpc/server/routers/viewer/bookings/addGuests.handler.ts:76-109
Commit: `92f44dcea7ff19e9123a30c63c167a2938df5a55`
Source: https://github.com/code-review-benchmark/cal_dot_com__cal.com__coderabbit__PR14740__20260122/blob/92f44dcea7ff19e9123a30c63c167a2938df5a55/packages/trpc/server/routers/viewer/bookings/addGuests.handler.ts#L76-L109

```text
76:       !booking.attendees.some((attendee) => guest === attendee.email) &&
77:       !blacklistedGuestEmails.includes(guest)
78:   );
79: 
80:   if (uniqueGuests.length === 0)
81:     throw new TRPCError({ code: "BAD_REQUEST", message: "emails_must_be_unique_valid" });
82: 
83:   const guestsFullDetails = uniqueGuests.map((guest) => {
84:     return {
85:       name: "",
86:       email: guest,
87:       timeZone: organizer.timeZone,
88:       locale: organizer.locale,
89:     };
90:   });
91: 
92:   const bookingAttendees = await prisma.booking.update({
93:     where: {
94:       id: bookingId,
95:     },
96:     include: {
97:       attendees: true,
98:     },
99:     data: {
100:       attendees: {
101:         createMany: {
102:           data: guestsFullDetails,
103:         },
104:       },
105:     },
106:   });
107: 
108:   const attendeesListPromises = bookingAttendees.attendees.map(async (attendee) => {
109:     return {
```

## head: packages/trpc/server/routers/viewer/bookings/addGuests.handler.ts:158-174
Commit: `92f44dcea7ff19e9123a30c63c167a2938df5a55`
Source: https://github.com/code-review-benchmark/cal_dot_com__cal.com__coderabbit__PR14740__20260122/blob/92f44dcea7ff19e9123a30c63c167a2938df5a55/packages/trpc/server/routers/viewer/bookings/addGuests.handler.ts#L158-L174

```text
158:   const credentials = await getUsersCredentials(ctx.user);
159: 
160:   const eventManager = new EventManager({
161:     ...user,
162:     credentials: [...credentials],
163:   });
164: 
165:   await eventManager.updateCalendarAttendees(evt, booking);
166: 
167:   try {
168:     await sendAddGuestsEmails(evt, guests);
169:   } catch (err) {
170:     console.log("Error sending AddGuestsEmails");
171:   }
172: 
173:   return { message: "Guests added" };
174: };
```

## head: packages/core/EventManager.ts:596-602
Commit: `92f44dcea7ff19e9123a30c63c167a2938df5a55`
Source: https://github.com/code-review-benchmark/cal_dot_com__cal.com__coderabbit__PR14740__20260122/blob/92f44dcea7ff19e9123a30c63c167a2938df5a55/packages/core/EventManager.ts#L596-L602

```text
596:   public async updateCalendarAttendees(event: CalendarEvent, booking: PartialBooking) {
597:     if (booking.references.length === 0) {
598:       console.error("Tried to update references but there wasn't any.");
599:       return;
600:     }
601:     await this.updateAllCalendarEvents(event, booking);
602:   }
```

## head: packages/core/EventManager.ts:920-941
Commit: `92f44dcea7ff19e9123a30c63c167a2938df5a55`
Source: https://github.com/code-review-benchmark/cal_dot_com__cal.com__coderabbit__PR14740__20260122/blob/92f44dcea7ff19e9123a30c63c167a2938df5a55/packages/core/EventManager.ts#L920-L941

```text
920:       return Promise.all(result);
921:     } catch (error) {
922:       let message = `Tried to 'updateAllCalendarEvents' but there was no '{thing}' for '${credential?.type}', userId: '${credential?.userId}', bookingId: '${booking?.id}'`;
923:       if (error instanceof Error) {
924:         message = message.replace("{thing}", error.message);
925:       }
926: 
927:       return Promise.resolve(
928:         calendarReference?.map((reference) => {
929:           return {
930:             appName: "none",
931:             type: reference?.type || "calendar",
932:             success: false,
933:             uid: "",
934:             originalEvent: event,
935:             credentialId: 0,
936:           };
937:         }) ?? ([] as Array<EventResult<NewCalendarEventType>>)
938:       );
939:     }
940:   }
941: 
```

## head: packages/core/CalendarManager.ts:329-349
Commit: `92f44dcea7ff19e9123a30c63c167a2938df5a55`
Source: https://github.com/code-review-benchmark/cal_dot_com__cal.com__coderabbit__PR14740__20260122/blob/92f44dcea7ff19e9123a30c63c167a2938df5a55/packages/core/CalendarManager.ts#L329-L349

```text
329:     calendar && bookingRefUid
330:       ? await calendar
331:           .updateEvent(bookingRefUid, calEvent, externalCalendarId)
332:           .then((event: NewCalendarEventType | NewCalendarEventType[]) => {
333:             success = true;
334:             return event;
335:           })
336:           .catch(async (e: { calError: string }) => {
337:             // @TODO: This code will be off till we can investigate an error with it
338:             // @see https://github.com/calcom/cal.com/issues/3949
339:             // await sendBrokenIntegrationEmail(calEvent, "calendar");
340:             log.error(
341:               "updateEvent failed",
342:               safeStringify({ e, calEvent: getPiiFreeCalendarEvent(calEvent) })
343:             );
344:             if (e?.calError) {
345:               calError = e.calError;
346:             }
347:             return undefined;
348:           })
349:       : undefined;
```
