# finding-002

Unsubscribe action toggles notification level instead of being one-way - if topic is already muted, clicking the link sets it to regular, so a second visit re-enables notifications instead of keeping it muted

## head: app/controllers/topics_controller.rb:98-116
Commit: `6669a2d94d76eea3b99b8c476d12b1eb66726b07`
Source: https://github.com/code-review-benchmark/discourse__discourse-graphite__coderabbit__PR2__20260122/blob/6669a2d94d76eea3b99b8c476d12b1eb66726b07/app/controllers/topics_controller.rb#L98-L116

```text
98:   def unsubscribe
99:     @topic_view = TopicView.new(params[:topic_id], current_user)
100: 
101:     if slugs_do_not_match || (!request.format.json? && params[:slug].blank?)
102:       return redirect_to @topic_view.topic.unsubscribe_url, status: 301
103:     end
104: 
105:     tu = TopicUser.find_by(user_id: current_user.id, topic_id: params[:topic_id])
106: 
107:     if tu.notification_level > TopicUser.notification_levels[:regular]
108:       tu.notification_level = TopicUser.notification_levels[:regular]
109:     else
110:       tu.notification_level = TopicUser.notification_levels[:muted]
111:     end
112: 
113:     tu.save!
114: 
115:     perform_show_response
116:   end
```

## head: app/models/topic_user.rb:18-21
Commit: `6669a2d94d76eea3b99b8c476d12b1eb66726b07`
Source: https://github.com/code-review-benchmark/discourse__discourse-graphite__coderabbit__PR2__20260122/blob/6669a2d94d76eea3b99b8c476d12b1eb66726b07/app/models/topic_user.rb#L18-L21

```text
18:     # Enums
19:     def notification_levels
20:       @notification_levels ||= Enum.new(:muted, :regular, :tracking, :watching, start: 0)
21:     end
```
