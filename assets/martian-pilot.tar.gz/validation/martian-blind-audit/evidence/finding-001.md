# finding-001

Possible StringIndexOutOfBoundsException in difference range calculation - prefix loop and suffix loop run independently and can overlap, causing invalid substring ranges like sanitized.substring(1, 0)

## head: misc/theme-verifier/src/main/java/org/keycloak/themeverifier/VerifyMessageProperties.java:90-111
Commit: `02f48f776f43734d1ac8914d3ad6a7115acdcb33`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR37429__20260122/blob/02f48f776f43734d1ac8914d3ad6a7115acdcb33/misc/theme-verifier/src/main/java/org/keycloak/themeverifier/VerifyMessageProperties.java#L90-L111

```text
90:             // Only if the English source string contains HTML we also allow HTML in the translation
91:             PolicyFactory policy = containsHtml(englishValue) ? POLICY_SOME_HTML : POLICY_NO_HTML;
92:             String sanitized = policy.sanitize(value);
93: 
94:             // Sanitizer will escape HTML entities for quotes and also for numberic tags like '<1>'
95:             sanitized = org.apache.commons.text.StringEscapeUtils.unescapeHtml4(sanitized);
96:             // Sanitizer will add them when there are double curly braces
97:             sanitized = sanitized.replace("<!-- -->", "");
98: 
99:             if (!Objects.equals(sanitized, value)) {
100: 
101:                 // Strip identical characters from the beginning and the end to show where the difference is
102:                 int start = 0;
103:                 while (start < sanitized.length() && start < value.length() && value.charAt(start) == sanitized.charAt(start)) {
104:                     start++;
105:                 }
106:                 int end = 0;
107:                 while (end < sanitized.length() && end < value.length() && value.charAt(value.length() - end - 1) == sanitized.charAt(sanitized.length() - end - 1)) {
108:                     end++;
109:                 }
110: 
111:                 messages.add("Illegal HTML in key " + key + " for file " + file + ": '" + value.substring(start, value.length() - end) + "' vs. '" + sanitized.substring(start, sanitized.length() - end) + "'");
```

## head: misc/theme-verifier/src/main/java/org/keycloak/themeverifier/VerifyMessageProperties.java:58-63
Commit: `02f48f776f43734d1ac8914d3ad6a7115acdcb33`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR37429__20260122/blob/02f48f776f43734d1ac8914d3ad6a7115acdcb33/misc/theme-verifier/src/main/java/org/keycloak/themeverifier/VerifyMessageProperties.java#L58-L63

```text
58:     PolicyFactory POLICY_SOME_HTML = new org.owasp.html.HtmlPolicyBuilder()
59:             .allowElements(
60:                     "br", "p", "strong", "b"
61:             ).toFactory();
62: 
63:     PolicyFactory POLICY_NO_HTML = new org.owasp.html.HtmlPolicyBuilder().toFactory();
```
