# finding-018

In BackwardsCompatibilityUserStorage.getCredentials, removeUser can remove the map entry while an already resolved federated UserModel still references this provider, causing NullPointerException when getCredentials dereferences myUser - should return empty stream when entry is missing

## head: testsuite/integration-arquillian/servers/auth-server/services/testsuite-providers/src/main/java/org/keycloak/testsuite/federation/BackwardsCompatibilityUserStorage.java:226-251
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/testsuite/integration-arquillian/servers/auth-server/services/testsuite-providers/src/main/java/org/keycloak/testsuite/federation/BackwardsCompatibilityUserStorage.java#L226-L251

```text
226:     private MyUser getMyUser(UserModel user) {
227:         return users.get(translateUserName(user.getUsername()));
228:     }
229: 
230:     @Override
231:     public Stream<CredentialModel> getCredentials(RealmModel realm, UserModel user) {
232:         var myUser = getMyUser(user);
233:         RecoveryAuthnCodesCredentialModel model;
234:         List<CredentialModel> credentialModels = new ArrayList<>();
235:         if (myUser.recoveryCodes != null) {
236:             try {
237:                 model = RecoveryAuthnCodesCredentialModel.createFromValues(
238:                         JsonSerialization.readValue(myUser.recoveryCodes.getCredentialData(), List.class),
239:                         myUser.recoveryCodes.getCreatedDate(),
240:                         myUser.recoveryCodes.getUserLabel()
241:                 );
242:                 credentialModels.add(model);
243:             } catch (IOException e) {
244:                 log.error("Could not deserialize  credential of type: recovery-codes");
245:             }
246:         }
247:         if (myUser.otp != null) {
248:             credentialModels.add(myUser.getOtp());
249:         }
250: 
251:         return credentialModels.stream();
```

## head: testsuite/integration-arquillian/servers/auth-server/services/testsuite-providers/src/main/java/org/keycloak/testsuite/federation/BackwardsCompatibilityUserStorage.java:347-368
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/testsuite/integration-arquillian/servers/auth-server/services/testsuite-providers/src/main/java/org/keycloak/testsuite/federation/BackwardsCompatibilityUserStorage.java#L347-L368

```text
347:     @Override
348:     public UserModel getUserByUsername(RealmModel realm, String username) {
349:         if (!users.containsKey(translateUserName(username))) return null;
350: 
351:         return createUser(realm, username);
352:     }
353: 
354:     @Override
355:     public UserModel getUserByEmail(RealmModel realm, String email) {
356:         return null;
357:     }
358: 
359:     @Override
360:     public UserModel addUser(RealmModel realm, String username) {
361:         users.put(translateUserName(username), new MyUser(username));
362:         return createUser(realm, username);
363:     }
364: 
365:     @Override
366:     public boolean removeUser(RealmModel realm, UserModel user) {
367:         return users.remove(translateUserName(user.getUsername())) != null;
368:     }
```

## head: model/storage/src/main/java/org/keycloak/credential/UserCredentialManager.java:130-145
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/model/storage/src/main/java/org/keycloak/credential/UserCredentialManager.java#L130-L145

```text
130:     public Stream<CredentialModel> getFederatedCredentialsStream() {
131:         if (user.isFederated()) {
132:             UserStorageProviderModel model = getStorageProviderModel(realm, user.getFederationLink());
133: 
134:             if (model == null || !model.isEnabled()) {
135:                 return Stream.empty();
136:             }
137: 
138:             CredentialInputUpdater credentialProvider = getStorageProviderInstance(model, CredentialInputUpdater.class);
139: 
140:             if (credentialProvider != null) {
141:                 return credentialProvider.getCredentials(realm, user);
142:             }
143:         }
144: 
145:         return Stream.empty();
```
