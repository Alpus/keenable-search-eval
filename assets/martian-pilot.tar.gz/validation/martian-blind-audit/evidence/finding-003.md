# finding-003

disableCredentialType() does not clear MyUser.recoveryCodes, and getDisableableCredentialTypesStream() does not report recovery codes - a request to disable recovery codes leaves the provider configured for that credential type

## head: testsuite/integration-arquillian/servers/auth-server/services/testsuite-providers/src/main/java/org/keycloak/testsuite/federation/BackwardsCompatibilityUserStorage.java:193-204
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/testsuite/integration-arquillian/servers/auth-server/services/testsuite-providers/src/main/java/org/keycloak/testsuite/federation/BackwardsCompatibilityUserStorage.java#L193-L204

```text
193:         } else if (input.getType().equals(RecoveryAuthnCodesCredentialModel.TYPE)) {
194:             CredentialModel recoveryCodesModel = new CredentialModel();
195:             recoveryCodesModel.setId(KeycloakModelUtils.generateId());
196:             recoveryCodesModel.setType(input.getType());
197:             recoveryCodesModel.setCredentialData(input.getChallengeResponse());
198:             long createdDate = Time.currentTimeMillis();
199:             recoveryCodesModel.setCreatedDate(createdDate);
200:             users.get(translateUserName(user.getUsername())).recoveryCodes = recoveryCodesModel;
201:             return true;
202:         } else {
203:             log.infof("Attempt to update unsupported credential of type: %s", input.getType());
204:             return false;
```

## head: testsuite/integration-arquillian/servers/auth-server/services/testsuite-providers/src/main/java/org/keycloak/testsuite/federation/BackwardsCompatibilityUserStorage.java:216-276
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/testsuite/integration-arquillian/servers/auth-server/services/testsuite-providers/src/main/java/org/keycloak/testsuite/federation/BackwardsCompatibilityUserStorage.java#L216-L276

```text
216:     @Override
217:     public void disableCredentialType(RealmModel realm, UserModel user, String credentialType) {
218:         if (isOTPType(credentialType)) {
219:             MyUser myUser = getMyUser(user);
220:             myUser.otp = null;
221:         } else {
222:             log.infof("Unsupported to disable credential of type: %s", credentialType);
223:         }
224:     }
225: 
226:     private MyUser getMyUser(UserModel user) {
227:         return users.get(translateUserName(user.getUsername()));
228:     }
229: 
230:     @Override
231:     public Stream<CredentialModel> getCredentials(RealmModel realm, UserModel user) {
232:         var myUser = getMyUser(user);
233:         RecoveryAuthnCodesCredentialModel model;
234:         List<CredentialModel> credentialModels = new ArrayList<>();
235:         if (myUser.recoveryCodes != null) {
236:             try {
237:                 model = RecoveryAuthnCodesCredentialModel.createFromValues(
238:                         JsonSerialization.readValue(myUser.recoveryCodes.getCredentialData(), List.class),
239:                         myUser.recoveryCodes.getCreatedDate(),
240:                         myUser.recoveryCodes.getUserLabel()
241:                 );
242:                 credentialModels.add(model);
243:             } catch (IOException e) {
244:                 log.error("Could not deserialize  credential of type: recovery-codes");
245:             }
246:         }
247:         if (myUser.otp != null) {
248:             credentialModels.add(myUser.getOtp());
249:         }
250: 
251:         return credentialModels.stream();
252:     }
253: 
254:     @Override
255:     public Stream<String> getDisableableCredentialTypesStream(RealmModel realm, UserModel user) {
256:         Set<String> types = new HashSet<>();
257: 
258:         MyUser myUser = getMyUser(user);
259:         if (myUser != null && myUser.otp != null) {
260:             types.add(CredentialModel.OTP);
261:         }
262: 
263:         return types.stream();
264:     }
265: 
266:     @Override
267:     public boolean isConfiguredFor(RealmModel realm, UserModel user, String credentialType) {
268:         // Always assume that password is supported
269:         if (CredentialModel.PASSWORD.equals(credentialType)) return true;
270:         MyUser myUser = getMyUser(user);
271:         if (myUser == null) return false;
272: 
273:         if (isOTPType(credentialType) && myUser.otp != null) {
274:             return true;
275:         } else if (credentialType.equals(RecoveryAuthnCodesCredentialModel.TYPE) && myUser.recoveryCodes != null) {
276:             return true;
```

## head: testsuite/integration-arquillian/tests/base/src/test/java/org/keycloak/testsuite/federation/storage/BackwardsCompatibilityUserStorageTest.java:240-270
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/testsuite/integration-arquillian/tests/base/src/test/java/org/keycloak/testsuite/federation/storage/BackwardsCompatibilityUserStorageTest.java#L240-L270

```text
240:     @Test
241:     public void testRecoveryKeysSetupAndLogin() throws URISyntaxException, IOException {
242:         try {
243:             configureBrowserFlowWithRecoveryAuthnCodes(testingClient, 0);
244: 
245:             String userId = addUserAndResetPassword("otp1", "pass");
246:             getCleanup().addUserId(userId);
247: 
248:             // Setup RecoveryKeys
249:             List<String> recoveryKeys = setupRecoveryKeysForUserWithRequiredAction(userId, true);
250: 
251:             // Assert user has RecoveryKeys in the userStorage
252:             assertUserDontHaveDBCredentials();
253:             assertUserHasRecoveryKeysCredentialInUserStorage(true);
254: 
255:             TestAppHelper testAppHelper = new TestAppHelper(oauth, loginPage, appPage);
256: 
257:             // Authenticate as the user
258:             testAppHelper.startLogin("otp1", "pass");
259:             enterRecoveryCodes(enterRecoveryAuthnCodePage, driver, 0, recoveryKeys);
260:             enterRecoveryAuthnCodePage.clickSignInButton();
261: 
262:             appPage.assertCurrent();
263: 
264:             testAppHelper.logout();
265:         } finally {
266:             // Revert copy of browser flow to original to keep clean slate after this test
267:             BrowserFlowTest.revertFlows(testRealm(), BROWSER_FLOW_WITH_RECOVERY_AUTHN_CODES);
268:         }
269:     }
270: 
```
