"""Small deterministic checks of source logic. No service or sanitizer integration run."""
import re,json
out={}
# Direct translation of VerifyMessageProperties.java:102-111.
value='<p>';sanitized='<p></p>';start=end=0
while start<len(sanitized) and start<len(value) and value[start]==sanitized[start]: start+=1
while end<len(sanitized) and end<len(value) and value[-end-1]==sanitized[-end-1]: end+=1
out['difference_range']={'input':value,'assumed_sanitizer_output':sanitized,'start':start,'value_end':len(value)-end,'invalid_java_substring':start>len(value)-end,'limitation':'Sanitizer output supplied, not executed.'}
assert start>len(value)-end
# normalizeValue for the explicitly allowed choice-message keys.
payload='{2,choice,0#<img src=x onerror=alert(1)>|1#value|1<values}'
normalized=re.sub(r'\{[0-9]+,choice,[^}]*}', '...',payload)
out['choice_normalization']={'input':payload,'normalized':normalized,'html_removed_before_sanitizer': '<img' not in normalized}
assert normalized=='...'
# TopicsController unsubscribe conditional; levels supplied by TopicUser Enum.
out['unsubscribe_levels']={str(n):(1 if n>1 else 0) for n in range(4)}
assert out['unsubscribe_levels']['0']==0
# BackwardsCompatibilityUserStorage recovery-code validator does not mutate keys.
keys=['code1','code2']; first=any(x=='code1' for x in keys);second=any(x=='code1' for x in keys)
out['test_fixture_reuse']={'first':first,'second':second,'remaining':keys}
assert first and second and len(keys)==2
print(json.dumps(out,indent=2))
