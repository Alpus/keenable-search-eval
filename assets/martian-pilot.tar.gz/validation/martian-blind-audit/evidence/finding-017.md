# finding-017

iter_cluster_memory_usage() calls Redis INFO for every cluster node. Each buffer uses the configured span-buffer cluster, so the loop repeats the same cluster-wide query once per buffer, adding redundant Redis calls and duplicating memory entries.

## head: src/sentry/spans/consumers/process/flusher.py:296-305
Commit: `3162ad68a5c87666788b27a44eb31235025091a9`
Source: https://github.com/code-review-benchmark/sentry__sentry__coderabbit__PR93824__20260122/blob/3162ad68a5c87666788b27a44eb31235025091a9/src/sentry/spans/consumers/process/flusher.py#L296-L305

```text
296:         # wait until the situation is improved manually.
297:         max_memory_percentage = options.get("spans.buffer.max-memory-percentage")
298:         if max_memory_percentage < 1.0:
299:             memory_infos: list[ServiceMemory] = []
300:             for buffer in self.buffers.values():
301:                 memory_infos.extend(buffer.get_memory_info())
302:             used = sum(x.used for x in memory_infos)
303:             available = sum(x.available for x in memory_infos)
304:             if available > 0 and used / available > max_memory_percentage:
305:                 if not self.redis_was_full:
```

## head: src/sentry/spans/buffer.py:117-118
Commit: `3162ad68a5c87666788b27a44eb31235025091a9`
Source: https://github.com/code-review-benchmark/sentry__sentry__coderabbit__PR93824__20260122/blob/3162ad68a5c87666788b27a44eb31235025091a9/src/sentry/spans/buffer.py#L117-L118

```text
117: def get_redis_client() -> RedisCluster[bytes] | StrictRedis[bytes]:
118:     return redis.redis_clusters.get_binary(settings.SENTRY_SPAN_BUFFER_CLUSTER)
```

## head: src/sentry/spans/buffer.py:153-165
Commit: `3162ad68a5c87666788b27a44eb31235025091a9`
Source: https://github.com/code-review-benchmark/sentry__sentry__coderabbit__PR93824__20260122/blob/3162ad68a5c87666788b27a44eb31235025091a9/src/sentry/spans/buffer.py#L153-L165

```text
153:     def __init__(self, assigned_shards: list[int]):
154:         self.assigned_shards = list(assigned_shards)
155:         self.add_buffer_sha: str | None = None
156:         self.any_shard_at_limit = False
157:         self._current_compression_level = None
158:         self._zstd_compressor: zstandard.ZstdCompressor | None = None
159:         self._zstd_decompressor = zstandard.ZstdDecompressor()
160: 
161:     @cached_property
162:     def client(self) -> RedisCluster[bytes] | StrictRedis[bytes]:
163:         return get_redis_client()
164: 
165:     # make it pickleable
```

## head: src/sentry/spans/buffer.py:375-376
Commit: `3162ad68a5c87666788b27a44eb31235025091a9`
Source: https://github.com/code-review-benchmark/sentry__sentry__coderabbit__PR93824__20260122/blob/3162ad68a5c87666788b27a44eb31235025091a9/src/sentry/spans/buffer.py#L375-L376

```text
375:     def get_memory_info(self) -> Generator[ServiceMemory]:
376:         return iter_cluster_memory_usage(self.client)
```

## head: src/sentry/processing/backpressure/memory.py:82-105
Commit: `3162ad68a5c87666788b27a44eb31235025091a9`
Source: https://github.com/code-review-benchmark/sentry__sentry__coderabbit__PR93824__20260122/blob/3162ad68a5c87666788b27a44eb31235025091a9/src/sentry/processing/backpressure/memory.py#L82-L105

```text
82: def iter_cluster_memory_usage(cluster: Cluster) -> Generator[ServiceMemory]:
83:     """
84:     A generator that yields redis `INFO` results for each of the nodes in the `cluster`.
85:     """
86:     if isinstance(cluster, RedisCluster):
87:         # `RedisCluster` returns these as a dictionary, with the node-id as key
88:         cluster_info = cluster.info()
89:     elif isinstance(cluster, StrictRedis):
90:         cluster_info = {"main": cluster.info()}
91:     else:
92:         # rb.Cluster returns a promise with a dictionary with a _local_ node-id as key
93:         with cluster.all() as client:
94:             promise = client.info()
95:         cluster_info = promise.value
96: 
97:     for node_id, info in cluster_info.items():
98:         # we only care about the memory level of leader nodes, not followers
99:         if info.get("role") != "master":
100:             continue
101:         node_info = get_host_port_info(node_id, cluster)
102:         memory_usage = get_memory_usage(node_id, info)
103:         memory_usage.host = node_info.host
104:         memory_usage.port = node_info.port
105:         yield memory_usage
```
