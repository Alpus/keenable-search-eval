# finding-013

For federated users, removeStoredCredentialById targets federated storage instead of the provider's CredentialInputUpdater, so exhausted provider credentials can remain available to later lookups - need provider-aware cleanup for this path

## head: services/src/main/java/org/keycloak/authentication/authenticators/browser/RecoveryAuthnCodesFormAuthenticator.java:79-92
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/services/src/main/java/org/keycloak/authentication/authenticators/browser/RecoveryAuthnCodesFormAuthenticator.java#L79-L92

```text
79:                 result = true;
80:                 Optional<CredentialModel> optUserCredentialFound = RecoveryAuthnCodesUtils.getCredential(authenticatedUser);
81:                 RecoveryAuthnCodesCredentialModel recoveryCodeCredentialModel = null;
82:                 if (optUserCredentialFound.isPresent()) {
83:                     recoveryCodeCredentialModel = RecoveryAuthnCodesCredentialModel
84:                             .createFromCredentialModel(optUserCredentialFound.get());
85:                     if (recoveryCodeCredentialModel.allCodesUsed()) {
86:                         authenticatedUser.credentialManager().removeStoredCredentialById(
87:                                 recoveryCodeCredentialModel.getId());
88:                     }
89:                 }
90:                 if (recoveryCodeCredentialModel == null || recoveryCodeCredentialModel.allCodesUsed()) {
91:                     authenticatedUser.addRequiredAction(UserModel.RequiredAction.CONFIGURE_RECOVERY_AUTHN_CODES);
92:                 }
```

## head: server-spi/src/main/java/org/keycloak/models/utils/RecoveryAuthnCodesUtils.java:49-62
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/server-spi/src/main/java/org/keycloak/models/utils/RecoveryAuthnCodesUtils.java#L49-L62

```text
49: 
50:     /**
51:      * Checks the user storage for the credential. If not found it will look for the credential in the local storage
52:      *
53:      * @param user - User model
54:      * @return - a optional  credential model
55:      */
56:     public static Optional<CredentialModel> getCredential(UserModel user) {
57:         return user.credentialManager()
58:                 .getFederatedCredentialsStream()
59:                 .filter(c -> RecoveryAuthnCodesCredentialModel.TYPE.equals(c.getType()))
60:                 .findFirst()
61:                 .or(() -> user.credentialManager().getStoredCredentialsByTypeStream(RecoveryAuthnCodesCredentialModel.TYPE).findFirst());
62:     }
```

## head: model/storage/src/main/java/org/keycloak/credential/UserCredentialManager.java:113-145
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/model/storage/src/main/java/org/keycloak/credential/UserCredentialManager.java#L113-L145

```text
113:     @Override
114:     public boolean removeStoredCredentialById(String id) {
115:         throwExceptionIfInvalidUser(user);
116:         return getStoreForUser(user).removeStoredCredential(realm, user, id);
117:     }
118: 
119:     @Override
120:     public CredentialModel getStoredCredentialById(String id) {
121:         return getStoreForUser(user).getStoredCredentialById(realm, user, id);
122:     }
123: 
124:     @Override
125:     public Stream<CredentialModel> getStoredCredentialsStream() {
126:         return getStoreForUser(user).getStoredCredentialsStream(realm, user);
127:     }
128: 
129:     @Override
130:     public Stream<CredentialModel> getFederatedCredentialsStream() {
131:         if (user.isFederated()) {
132:             UserStorageProviderModel model = getStorageProviderModel(realm, user.getFederationLink());
133: 
134:             if (model == null || !model.isEnabled()) {
135:                 return Stream.empty();
136:             }
137: 
138:             CredentialInputUpdater credentialProvider = getStorageProviderInstance(model, CredentialInputUpdater.class);
139: 
140:             if (credentialProvider != null) {
141:                 return credentialProvider.getCredentials(realm, user);
142:             }
143:         }
144: 
145:         return Stream.empty();
```

## head: model/storage/src/main/java/org/keycloak/credential/UserCredentialManager.java:173-187
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/model/storage/src/main/java/org/keycloak/credential/UserCredentialManager.java#L173-L187

```text
173:     public void disableCredentialType(String credentialType) {
174:         if (!StorageId.isLocalStorage(user.getId())) throwExceptionIfInvalidUser(user);
175:         if (user.isFederated()) {
176:             UserStorageProviderModel model = getStorageProviderModel(realm, user.getFederationLink());
177:             if (model == null || !model.isEnabled()) return;
178: 
179:             CredentialInputUpdater updater = getStorageProviderInstance(model, CredentialInputUpdater.class);
180:             if (updater.supportsCredentialType(credentialType)) {
181:                 updater.disableCredentialType(realm, user, credentialType);
182:             }
183:         }
184: 
185:         getCredentialProviders(session, CredentialInputUpdater.class)
186:                 .filter(updater -> updater.supportsCredentialType(credentialType))
187:                 .forEach(updater -> updater.disableCredentialType(realm, user, credentialType));
```

## head: model/storage/src/main/java/org/keycloak/credential/UserCredentialManager.java:298-304
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/model/storage/src/main/java/org/keycloak/credential/UserCredentialManager.java#L298-L304

```text
298:     private UserCredentialStore getStoreForUser(UserModel user) {
299:         StoreManagers p = (StoreManagers) session.getProvider(DatastoreProvider.class);
300:         if (StorageId.isLocalStorage(user.getId())) {
301:             return (UserCredentialStore) p.userLocalStorage();
302:         } else {
303:             return (UserCredentialStore) p.userFederatedStorage();
304:         }
```
