# finding-019

runShardSplitQuery applies request.filters before shard discovery, then the resulting targets go to runSplitQuery which applies the same filters again, causing ad hoc filters to be added twice since addAdHocFilters adds each filter through addLabelToQuery and does not remove existing filters

## head: public/app/plugins/datasource/loki/shardQuerySplitting.ts:48-54
Commit: `1cab4143d443c33079566f6ca36931eb8468159f`
Source: https://github.com/code-review-benchmark/grafana__grafana__coderabbit__PR107534__20260122/blob/1cab4143d443c33079566f6ca36931eb8468159f/public/app/plugins/datasource/loki/shardQuerySplitting.ts#L48-L54

```text
48: export function runShardSplitQuery(datasource: LokiDatasource, request: DataQueryRequest<LokiQuery>) {
49:   const queries = request.targets
50:     .filter((query) => query.expr)
51:     .filter((query) => !query.hide)
52:     .map((query) => datasource.applyTemplateVariables(query, request.scopedVars, request.filters));
53: 
54:   return splitQueriesByStreamShard(datasource, request, queries);
```

## head: public/app/plugins/datasource/loki/shardQuerySplitting.ts:145-166
Commit: `1cab4143d443c33079566f6ca36931eb8468159f`
Source: https://github.com/code-review-benchmark/grafana__grafana__coderabbit__PR107534__20260122/blob/1cab4143d443c33079566f6ca36931eb8468159f/public/app/plugins/datasource/loki/shardQuerySplitting.ts#L145-L166

```text
145: 
146:     const targets = adjustTargetsFromResponseState(groups[group].targets, mergedResponse);
147:     if (!targets.length) {
148:       nextRequest();
149:       return;
150:     }
151: 
152:     const shardsToQuery =
153:       shards && cycle !== undefined && groupSize ? groupShardRequests(shards, cycle, groupSize) : [];
154:     const subRequest = { ...request, targets: interpolateShardingSelector(targets, shardsToQuery) };
155:     // Request may not have a request id
156:     if (request.requestId) {
157:       subRequest.requestId =
158:         shardsToQuery.length > 0 ? `${request.requestId}_shard_${group}_${cycle}_${groupSize}` : request.requestId;
159:     }
160: 
161:     debug(shardsToQuery.length ? `Querying ${shardsToQuery.join(', ')}` : 'Running regular query');
162: 
163:     subquerySubscription = runSplitQuery(datasource, subRequest, {
164:       skipPartialUpdates: true,
165:       disableRetry: true,
166:     }).subscribe({
```

## head: public/app/plugins/datasource/loki/querySplitting.ts:293-303
Commit: `1cab4143d443c33079566f6ca36931eb8468159f`
Source: https://github.com/code-review-benchmark/grafana__grafana__coderabbit__PR107534__20260122/blob/1cab4143d443c33079566f6ca36931eb8468159f/public/app/plugins/datasource/loki/querySplitting.ts#L293-L303

```text
293:   request: DataQueryRequest<LokiQuery>,
294:   options: QuerySplittingOptions = {}
295: ) {
296:   const queries = request.targets
297:     .filter((query) => !query.hide)
298:     .filter((query) => query.expr)
299:     .map((query) => datasource.applyTemplateVariables(query, request.scopedVars, request.filters));
300:   const [nonSplittingQueries, normalQueries] = partition(queries, (query) => !querySupportsSplitting(query));
301:   const [logQueries, metricQueries] = partition(normalQueries, (query) => isLogsQuery(query.expr));
302: 
303:   request.queryGroupId = uuidv4();
```

## head: public/app/plugins/datasource/loki/datasource.ts:1073-1088
Commit: `1cab4143d443c33079566f6ca36931eb8468159f`
Source: https://github.com/code-review-benchmark/grafana__grafana__coderabbit__PR107534__20260122/blob/1cab4143d443c33079566f6ca36931eb8468159f/public/app/plugins/datasource/loki/datasource.ts#L1073-L1088

```text
1073:   addAdHocFilters(queryExpr: string, adhocFilters?: AdHocVariableFilter[]) {
1074:     if (!adhocFilters?.length) {
1075:       return queryExpr;
1076:     }
1077: 
1078:     let expr = replaceVariables(queryExpr);
1079: 
1080:     expr = adhocFilters.reduce((acc: string, filter: { key: string; operator: string; value: string }) => {
1081:       const { key, operator } = filter;
1082:       let { value } = filter;
1083:       if (!isRegexSelector(operator)) {
1084:         // We want to escape special characters in value for non-regex selectors to match the same char in the log line as the user types in the input
1085:         value = escapeLabelValueInSelector(value, operator);
1086:       }
1087:       return addLabelToQuery(acc, key, operator, value);
1088:     }, expr);
```

## head: public/app/plugins/datasource/loki/datasource.ts:1110-1139
Commit: `1cab4143d443c33079566f6ca36931eb8468159f`
Source: https://github.com/code-review-benchmark/grafana__grafana__coderabbit__PR107534__20260122/blob/1cab4143d443c33079566f6ca36931eb8468159f/public/app/plugins/datasource/loki/datasource.ts#L1110-L1139

```text
1110:   applyTemplateVariables(target: LokiQuery, scopedVars: ScopedVars, adhocFilters?: AdHocVariableFilter[]): LokiQuery {
1111:     // We want to interpolate these variables on backend because we support using them in
1112:     // alerting/ML queries and we want to have consistent interpolation for all queries
1113:     const { __auto, __interval, __interval_ms, __range, __range_s, __range_ms, ...rest } = scopedVars || {};
1114: 
1115:     const variables = {
1116:       ...rest,
1117: 
1118:       // pass through for backend interpolation. Need to be in scopedVars for Scenes though
1119:       __interval: {
1120:         value: '$__interval',
1121:       },
1122:       __interval_ms: {
1123:         value: '$__interval_ms',
1124:       },
1125:     };
1126: 
1127:     const exprWithAdHoc = this.addAdHocFilters(
1128:       this.templateSrv.replace(target.expr, variables, this.interpolateQueryExpr),
1129:       adhocFilters
1130:     );
1131: 
1132:     const step = this.templateSrv.replace(target.step, variables);
1133:     const legendFormat = this.templateSrv.replace(target.legendFormat, variables);
1134: 
1135:     return {
1136:       ...target,
1137:       expr: exprWithAdHoc,
1138:       step,
1139:       legendFormat,
```

## head: public/app/plugins/datasource/loki/modifyQuery.ts:170-215
Commit: `1cab4143d443c33079566f6ca36931eb8468159f`
Source: https://github.com/code-review-benchmark/grafana__grafana__coderabbit__PR107534__20260122/blob/1cab4143d443c33079566f6ca36931eb8468159f/public/app/plugins/datasource/loki/modifyQuery.ts#L170-L215

```text
170:   if (!labelType) {
171:     const identifierSelectorMatchers = getIdentifierInStreamPositions(query);
172:     const indexedKeys = identifierSelectorMatchers.map((match) => match.getExpression(query));
173:     if (indexedKeys.includes(key)) {
174:       labelType = LabelType.Indexed;
175:     }
176:   }
177: 
178:   const everyStreamSelectorHasMatcher = streamSelectorPositions.every((streamSelectorPosition) =>
179:     hasStreamSelectorMatchers.some(
180:       (matcherPosition) =>
181:         matcherPosition.from >= streamSelectorPosition.from && matcherPosition.to <= streamSelectorPosition.to
182:     )
183:   );
184: 
185:   const filter = toLabelFilter(key, value, operator);
186:   if (labelType === LabelType.Parsed || labelType === LabelType.StructuredMetadata) {
187:     const lastPositionsPerExpression = getLastPositionPerExpression(query, [
188:       ...streamSelectorPositions,
189:       ...labelFilterPositions,
190:       ...parserPositions,
191:       ...labelFormatPositions,
192:     ]);
193: 
194:     return addFilterAsLabelFilter(query, lastPositionsPerExpression, filter);
195:   } else if (labelType === LabelType.Indexed) {
196:     return addFilterToStreamSelector(query, streamSelectorPositions, filter);
197:   } else {
198:     // labelType is not set, so we need to figure out where to add the label
199:     // if we don't have a parser, or have empty stream selectors, we will just add it to the stream selector
200:     if (parserPositions.length === 0 || everyStreamSelectorHasMatcher === false) {
201:       return addFilterToStreamSelector(query, streamSelectorPositions, filter);
202:     } else {
203:       // If `labelType` is not set, it indicates a potential metric query (`labelType` is present only in log queries that came from a Loki instance supporting the `categorize-labels` API). In case we are not adding the label to stream selectors we need to find the last position to add in each expression.
204:       // E.g. in `sum(rate({foo="bar"} | logfmt [$__auto])) / sum(rate({foo="baz"} | logfmt [$__auto]))` we need to add the label at two places.
205:       const lastPositionsPerExpression = getLastPositionPerExpression(query, [
206:         ...parserPositions,
207:         ...labelFilterPositions,
208:         ...labelFormatPositions,
209:       ]);
210: 
211:       return addFilterAsLabelFilter(query, lastPositionsPerExpression, filter);
212:     }
213:   }
214: }
215: 
```

## head: public/app/plugins/datasource/loki/modifyQuery.ts:477-502
Commit: `1cab4143d443c33079566f6ca36931eb8468159f`
Source: https://github.com/code-review-benchmark/grafana__grafana__coderabbit__PR107534__20260122/blob/1cab4143d443c33079566f6ca36931eb8468159f/public/app/plugins/datasource/loki/modifyQuery.ts#L477-L502

```text
477: function addFilterToStreamSelector(
478:   query: string,
479:   vectorSelectorPositions: NodePosition[],
480:   filter: QueryBuilderLabelFilter
481: ): string {
482:   let newQuery = '';
483:   let prev = 0;
484: 
485:   for (let i = 0; i < vectorSelectorPositions.length; i++) {
486:     // This is basically just doing splice on a string for each matched vector selector.
487:     const match = vectorSelectorPositions[i];
488:     const isLast = i === vectorSelectorPositions.length - 1;
489: 
490:     const start = query.substring(prev, match.from);
491:     const end = isLast ? query.substring(match.to) : '';
492:     const matchVisQuery = buildVisualQueryFromString(query.substring(match.from, match.to));
493: 
494:     if (!labelExists(matchVisQuery.query.labels, filter)) {
495:       // We don't want to add duplicate labels.
496:       matchVisQuery.query.labels.push(filter);
497:     }
498:     const newLabels = modeller.renderQuery(matchVisQuery.query);
499:     newQuery += start + newLabels + end;
500:     prev = match.to;
501:   }
502:   return newQuery;
```

## head: public/app/plugins/datasource/loki/modifyQuery.ts:511-540
Commit: `1cab4143d443c33079566f6ca36931eb8468159f`
Source: https://github.com/code-review-benchmark/grafana__grafana__coderabbit__PR107534__20260122/blob/1cab4143d443c33079566f6ca36931eb8468159f/public/app/plugins/datasource/loki/modifyQuery.ts#L511-L540

```text
511: export function addFilterAsLabelFilter(
512:   query: string,
513:   positionsToAddAfter: NodePosition[],
514:   filter: QueryBuilderLabelFilter
515: ): string {
516:   let newQuery = '';
517:   let prev = 0;
518: 
519:   for (let i = 0; i < positionsToAddAfter.length; i++) {
520:     // This is basically just doing splice on a string for each matched vector selector.
521:     const match = positionsToAddAfter[i];
522:     const isLast = i === positionsToAddAfter.length - 1;
523: 
524:     const start = query.substring(prev, match.to);
525:     const end = isLast ? query.substring(match.to) : '';
526: 
527:     let labelFilter = '';
528:     // For < and >, if the value is number, we don't add quotes around it and use it as number
529:     if (!Number.isNaN(Number(filter.value)) && (filter.op === '<' || filter.op === '>')) {
530:       labelFilter = ` | ${filter.label}${filter.op}${Number(filter.value)}`;
531:     } else {
532:       // we now unescape all escaped values again, because we are using backticks which can handle those cases.
533:       // we also don't care about the operator here, because we need to unescape for both, regex and equal.
534:       labelFilter = ` | ${filter.label}${filter.op}\`${unescapeLabelValue(filter.value)}\``;
535:     }
536: 
537:     newQuery += start + labelFilter + end;
538:     prev = match.to;
539:   }
540:   return newQuery;
```
