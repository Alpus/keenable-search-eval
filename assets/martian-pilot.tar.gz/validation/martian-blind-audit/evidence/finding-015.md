# finding-015

Choice pattern branches are replaced before sanitization, allowing prohibited HTML like '<img src=x onerror=alert(1)>' inside choice branches to bypass validation

## head: misc/theme-verifier/src/main/java/org/keycloak/themeverifier/VerifyMessageProperties.java:82-95
Commit: `02f48f776f43734d1ac8914d3ad6a7115acdcb33`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR37429__20260122/blob/02f48f776f43734d1ac8914d3ad6a7115acdcb33/misc/theme-verifier/src/main/java/org/keycloak/themeverifier/VerifyMessageProperties.java#L82-L95

```text
82:         bundle.getKeys().asIterator().forEachRemaining(key -> {
83:             String value = bundle.getString(key);
84:             value = normalizeValue(key, value);
85:             String englishValue = getEnglishValue(key, bundleEnglish);
86:             englishValue = normalizeValue(key, englishValue);
87: 
88:             value = santizeAnchors(key, value, englishValue);
89: 
90:             // Only if the English source string contains HTML we also allow HTML in the translation
91:             PolicyFactory policy = containsHtml(englishValue) ? POLICY_SOME_HTML : POLICY_NO_HTML;
92:             String sanitized = policy.sanitize(value);
93: 
94:             // Sanitizer will escape HTML entities for quotes and also for numberic tags like '<1>'
95:             sanitized = org.apache.commons.text.StringEscapeUtils.unescapeHtml4(sanitized);
```

## head: misc/theme-verifier/src/main/java/org/keycloak/themeverifier/VerifyMessageProperties.java:117-130
Commit: `02f48f776f43734d1ac8914d3ad6a7115acdcb33`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR37429__20260122/blob/02f48f776f43734d1ac8914d3ad6a7115acdcb33/misc/theme-verifier/src/main/java/org/keycloak/themeverifier/VerifyMessageProperties.java#L117-L130

```text
117:     private String normalizeValue(String key, String value) {
118:         if (key.equals("templateHelp")) {
119:             // Allow "CLAIM.<NAME>" here
120:             value = value.replaceAll("CLAIM\\.<[A-Z]*>", "");
121:         } else if (key.equals("optimizeLookupHelp")) {
122:             // Allow "<Extensions>" here
123:             value = value.replaceAll("<Extensions>", "");
124:         } else if (key.startsWith("linkExpirationFormatter.timePeriodUnit") || key.equals("error-invalid-multivalued-size")) {
125:             // The problem is the "<" that appears in the choice
126:             value = value.replaceAll("\\{[0-9]+,choice,[^}]*}", "...");
127:         }
128: 
129:         // Unescape HTML entities, as we later also unescape HTML entities in the sanitized value
130:         value = org.apache.commons.text.StringEscapeUtils.unescapeHtml4(value);
```
