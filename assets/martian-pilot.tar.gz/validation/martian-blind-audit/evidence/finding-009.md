# finding-009

Admin UI receives error-invalid-multivalued-size through i18next which does not evaluate Java MessageFormat or ChoiceFormat, so {0} and {2,choice,...} reach the UI unchanged - need to use i18next-compatible interpolation and pluralization syntax

## head: js/apps/admin-ui/maven-resources/theme/keycloak.v2/admin/messages/messages_en.properties:3138-3138
Commit: `02f48f776f43734d1ac8914d3ad6a7115acdcb33`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR37429__20260122/blob/02f48f776f43734d1ac8914d3ad6a7115acdcb33/js/apps/admin-ui/maven-resources/theme/keycloak.v2/admin/messages/messages_en.properties#L3138-L3138

```text
3138: error-invalid-multivalued-size=Attribute {0} must have at least {1} and at most {2} {2,choice,0#values|1#value|1<values}.
```

## base: js/apps/admin-ui/maven-resources/theme/keycloak.v2/admin/messages/messages_en.properties:3138-3138
Commit: `f3c8e8f3487112f2c99aa78400430cce2d30be39`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR37429__20260122/blob/f3c8e8f3487112f2c99aa78400430cce2d30be39/js/apps/admin-ui/maven-resources/theme/keycloak.v2/admin/messages/messages_en.properties#L3138-L3138

```text
3138: error-invalid-multivalued-size=Attribute {{0}} must have at least {{1}} and at most {{2}} value(s).
```

## head: js/apps/admin-ui/src/i18n/i18n.ts:13-37
Commit: `02f48f776f43734d1ac8914d3ad6a7115acdcb33`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR37429__20260122/blob/02f48f776f43734d1ac8914d3ad6a7115acdcb33/js/apps/admin-ui/src/i18n/i18n.ts#L13-L37

```text
13: export const i18n = createInstance({
14:   fallbackLng: DEFAULT_LOCALE,
15:   keySeparator: KEY_SEPARATOR,
16:   interpolation: {
17:     escapeValue: false,
18:   },
19:   defaultNS: [environment.realm],
20:   ns: [environment.realm],
21:   backend: {
22:     loadPath: joinPath(
23:       environment.adminBaseUrl,
24:       `resources/{{ns}}/admin/{{lng}}`,
25:     ),
26:     parse: (data: string) => {
27:       const messages = JSON.parse(data);
28: 
29:       const result: Record<string, string> = {};
30:       messages.forEach((v: KeyValue) => (result[v.key] = v.value));
31:       return result;
32:     },
33:   },
34: });
35: 
36: i18n.use(HttpBackend);
37: i18n.use(initReactI18next);
```

## head: services/src/main/java/org/keycloak/services/resources/ThemeResource.java:119-157
Commit: `02f48f776f43734d1ac8914d3ad6a7115acdcb33`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR37429__20260122/blob/02f48f776f43734d1ac8914d3ad6a7115acdcb33/services/src/main/java/org/keycloak/services/resources/ThemeResource.java#L119-L157

```text
119:     @Path("/{realm}/{themeType}/{locale}")
120:     @Produces(MediaType.APPLICATION_JSON)
121:     public Response getLocalizationTexts(@PathParam("realm") String realmName, @QueryParam("theme") String theme,
122:                                          @PathParam("locale") String localeString, @PathParam("themeType") String themeType,
123:                                          @QueryParam("source") boolean showSource) throws IOException {
124:         final RealmModel realm = session.realms().getRealmByName(realmName);
125:         final Optional<Theme.Type> type = getThemeType(themeType);
126:         if (realm == null || type.isEmpty()) {
127:             return Response.status(Response.Status.NOT_FOUND).build();
128:         }
129:         session.getContext().setRealm(realm);
130:         List<KeySource> result;
131: 
132:         Theme theTheme;
133:         if (theme == null) {
134:             theTheme = session.theme().getTheme(type.get());
135:         } else {
136:             theTheme = session.theme().getTheme(theme, type.get());
137:         }
138: 
139:         final Locale locale = Locale.forLanguageTag(localeString);
140:         if (showSource) {
141:             Properties messagesByLocale = theTheme.getMessages("messages", locale);
142:             Set<KeySource> resultSet = messagesByLocale.entrySet().stream().map(e ->
143:                     new KeySource((String) e.getKey(), (String) e.getValue(), Source.THEME)).collect(toSet());
144: 
145:             Map<Locale, Properties> realmLocalizationMessages = LocaleUtil.getRealmLocalizationTexts(realm, locale);
146:             for (Locale currentLocale = locale; currentLocale != null; currentLocale = LocaleUtil.getParentLocale(currentLocale)) {
147:                 final List<KeySource> realmOverride = realmLocalizationMessages.get(currentLocale).entrySet().stream().map(e ->
148:                         new KeySource((String) e.getKey(), (String) e.getValue(), Source.REALM)).collect(toList());
149:                 resultSet.addAll(realmOverride);
150:             }
151:             result = new ArrayList<>(resultSet);
152:         } else {
153:             result = theTheme.getEnhancedMessages(realm, locale).entrySet().stream().map(e ->
154:                     new KeySource((String) e.getKey(), (String) e.getValue())).collect(toList());
155:         }
156: 
157:         return Cors.builder().allowedOrigins("*").auth().add(Response.ok(result));
```
