# finding-016

The unsubscribe action is exposed through GET routes and calls tu.save! after login, allowing CSRF attacks where an authenticated browser navigation can change the user's notification level without confirmation - should be moved to a non-GET endpoint with CSRF protection

## head: config/routes.rb:438-442
Commit: `6669a2d94d76eea3b99b8c476d12b1eb66726b07`
Source: https://github.com/code-review-benchmark/discourse__discourse-graphite__coderabbit__PR2__20260122/blob/6669a2d94d76eea3b99b8c476d12b1eb66726b07/config/routes.rb#L438-L442

```text
438:   get "t/:slug/:topic_id/moderator-liked" => "topics#moderator_liked", constraints: {topic_id: /\d+/}
439:   get "t/:slug/:topic_id/summary" => "topics#show", defaults: {summary: true}, constraints: {topic_id: /\d+/}
440:   get "t/:slug/:topic_id/unsubscribe" => "topics#unsubscribe", constraints: {topic_id: /\d+/}
441:   get "t/:topic_id/unsubscribe" => "topics#unsubscribe", constraints: {topic_id: /\d+/}
442:   get "t/:topic_id/summary" => "topics#show", constraints: {topic_id: /\d+/}
```

## head: app/controllers/topics_controller.rb:14-32
Commit: `6669a2d94d76eea3b99b8c476d12b1eb66726b07`
Source: https://github.com/code-review-benchmark/discourse__discourse-graphite__coderabbit__PR2__20260122/blob/6669a2d94d76eea3b99b8c476d12b1eb66726b07/app/controllers/topics_controller.rb#L14-L32

```text
14:                                           :status,
15:                                           :invite,
16:                                           :mute,
17:                                           :unmute,
18:                                           :set_notifications,
19:                                           :move_posts,
20:                                           :merge_topic,
21:                                           :clear_pin,
22:                                           :re_pin,
23:                                           :autoclose,
24:                                           :bulk,
25:                                           :reset_new,
26:                                           :change_post_owners,
27:                                           :bookmark,
28:                                           :unsubscribe]
29: 
30:   before_filter :consider_user_for_promotion, only: :show
31: 
32:   skip_before_filter :check_xhr, only: [:show, :unsubscribe, :feed]
```

## head: app/controllers/topics_controller.rb:98-116
Commit: `6669a2d94d76eea3b99b8c476d12b1eb66726b07`
Source: https://github.com/code-review-benchmark/discourse__discourse-graphite__coderabbit__PR2__20260122/blob/6669a2d94d76eea3b99b8c476d12b1eb66726b07/app/controllers/topics_controller.rb#L98-L116

```text
98:   def unsubscribe
99:     @topic_view = TopicView.new(params[:topic_id], current_user)
100: 
101:     if slugs_do_not_match || (!request.format.json? && params[:slug].blank?)
102:       return redirect_to @topic_view.topic.unsubscribe_url, status: 301
103:     end
104: 
105:     tu = TopicUser.find_by(user_id: current_user.id, topic_id: params[:topic_id])
106: 
107:     if tu.notification_level > TopicUser.notification_levels[:regular]
108:       tu.notification_level = TopicUser.notification_levels[:regular]
109:     else
110:       tu.notification_level = TopicUser.notification_levels[:muted]
111:     end
112: 
113:     tu.save!
114: 
115:     perform_show_response
116:   end
```

## head: app/controllers/application_controller.rb:21-34
Commit: `6669a2d94d76eea3b99b8c476d12b1eb66726b07`
Source: https://github.com/code-review-benchmark/discourse__discourse-graphite__coderabbit__PR2__20260122/blob/6669a2d94d76eea3b99b8c476d12b1eb66726b07/app/controllers/application_controller.rb#L21-L34

```text
21:   protect_from_forgery
22: 
23:   # Default Rails 3.2 lets the request through with a blank session
24:   #  we are being more pedantic here and nulling session / current_user
25:   #  and then raising a CSRF exception
26:   def handle_unverified_request
27:     # NOTE: API key is secret, having it invalidates the need for a CSRF token
28:     unless is_api?
29:       super
30:       clear_current_user
31:       render text: "['BAD CSRF']", status: 403
32:     end
33:   end
34: 
```
