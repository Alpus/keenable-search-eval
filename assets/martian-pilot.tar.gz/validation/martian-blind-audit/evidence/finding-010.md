# finding-010

In packages/app-store/wipemycalother/lib/reschedule.ts line 125, the mapped cleanup promises are not awaited inside the existing try block

## head: packages/app-store/wipemycalother/lib/reschedule.ts:121-139
Commit: `820d7fa87e0c824c5dee8082a33efadb1a2566f7`
Source: https://github.com/code-review-benchmark/cal_dot_com__cal.com__coderabbit__PR8087__20260122/blob/820d7fa87e0c824c5dee8082a33efadb1a2566f7/packages/app-store/wipemycalother/lib/reschedule.ts#L121-L139

```text
121:     const bookingRefsFiltered: BookingReference[] = bookingToReschedule.references.filter(
122:       (ref) => !!credentialsMap.get(ref.type)
123:     );
124:     try {
125:       bookingRefsFiltered.forEach(async (bookingRef) => {
126:         if (bookingRef.uid) {
127:           if (bookingRef.type.endsWith("_calendar")) {
128:             const calendar = await getCalendar(credentialsMap.get(bookingRef.type));
129:             return calendar?.deleteEvent(bookingRef.uid, builder.calendarEvent);
130:           } else if (bookingRef.type.endsWith("_video")) {
131:             return deleteMeeting(credentialsMap.get(bookingRef.type), bookingRef.uid);
132:           }
133:         }
134:       });
135:     } catch (error) {
136:       if (error instanceof Error) {
137:         logger.error(error.message);
138:       }
139:     }
```

## base: packages/app-store/wipemycalother/lib/reschedule.ts:121-139
Commit: `ba9688a04a8398c9a8332ee7061bfae2f2efd524`
Source: https://github.com/code-review-benchmark/cal_dot_com__cal.com__coderabbit__PR8087__20260122/blob/ba9688a04a8398c9a8332ee7061bfae2f2efd524/packages/app-store/wipemycalother/lib/reschedule.ts#L121-L139

```text
121:     const bookingRefsFiltered: BookingReference[] = bookingToReschedule.references.filter(
122:       (ref) => !!credentialsMap.get(ref.type)
123:     );
124:     try {
125:       bookingRefsFiltered.forEach((bookingRef) => {
126:         if (bookingRef.uid) {
127:           if (bookingRef.type.endsWith("_calendar")) {
128:             const calendar = getCalendar(credentialsMap.get(bookingRef.type));
129:             return calendar?.deleteEvent(bookingRef.uid, builder.calendarEvent);
130:           } else if (bookingRef.type.endsWith("_video")) {
131:             return deleteMeeting(credentialsMap.get(bookingRef.type), bookingRef.uid);
132:           }
133:         }
134:       });
135:     } catch (error) {
136:       if (error instanceof Error) {
137:         logger.error(error.message);
138:       }
139:     }
```
