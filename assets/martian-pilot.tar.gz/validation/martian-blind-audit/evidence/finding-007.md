# finding-007

Account resource endpoint returns messages without invoking AccountConsole.convertPropValue or Java MessageFormat, so ChoiceFormat expression remains literal in validation errors - need to use i18next interpolation for the Account resource

## head: js/apps/account-ui/maven-resources/theme/keycloak.v3/account/messages/messages_en.properties:188-188
Commit: `02f48f776f43734d1ac8914d3ad6a7115acdcb33`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR37429__20260122/blob/02f48f776f43734d1ac8914d3ad6a7115acdcb33/js/apps/account-ui/maven-resources/theme/keycloak.v3/account/messages/messages_en.properties#L188-L188

```text
188: error-invalid-multivalued-size=Attribute {0} must have at least {1} and at most {2} {2,choice,0#values|1#value|1<values}.
```

## base: js/apps/account-ui/maven-resources/theme/keycloak.v3/account/messages/messages_en.properties:188-188
Commit: `f3c8e8f3487112f2c99aa78400430cce2d30be39`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR37429__20260122/blob/f3c8e8f3487112f2c99aa78400430cce2d30be39/js/apps/account-ui/maven-resources/theme/keycloak.v3/account/messages/messages_en.properties#L188-L188

```text
188: error-invalid-multivalued-size=Attribute {{0}} must have at least {{1}} and at most {{2}} value(s).
```

## head: js/apps/account-ui/src/i18n.ts:25-47
Commit: `02f48f776f43734d1ac8914d3ad6a7115acdcb33`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR37429__20260122/blob/02f48f776f43734d1ac8914d3ad6a7115acdcb33/js/apps/account-ui/src/i18n.ts#L25-L47

```text
25: export const i18n = createInstance({
26:   fallbackLng: DEFAULT_LOCALE,
27:   interpolation: {
28:     escapeValue: false,
29:   },
30:   backend: {
31:     loadPath: joinPath(
32:       environment.serverBaseUrl,
33:       `resources/${environment.realm}/account/{{lng}}`,
34:     ),
35:     parse: (data: string) => {
36:       const messages = JSON.parse(data);
37: 
38:       const result: Record<string, string> = {};
39:       messages.forEach((v: KeyValue) => (result[v.key] = v.value));
40:       return result;
41:     },
42:   },
43: });
44: 
45: i18n.use(HttpBackend);
46: i18n.use(keycloakLanguageDetector);
47: i18n.use(initReactI18next);
```

## head: services/src/main/java/org/keycloak/services/resources/ThemeResource.java:119-157
Commit: `02f48f776f43734d1ac8914d3ad6a7115acdcb33`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR37429__20260122/blob/02f48f776f43734d1ac8914d3ad6a7115acdcb33/services/src/main/java/org/keycloak/services/resources/ThemeResource.java#L119-L157

```text
119:     @Path("/{realm}/{themeType}/{locale}")
120:     @Produces(MediaType.APPLICATION_JSON)
121:     public Response getLocalizationTexts(@PathParam("realm") String realmName, @QueryParam("theme") String theme,
122:                                          @PathParam("locale") String localeString, @PathParam("themeType") String themeType,
123:                                          @QueryParam("source") boolean showSource) throws IOException {
124:         final RealmModel realm = session.realms().getRealmByName(realmName);
125:         final Optional<Theme.Type> type = getThemeType(themeType);
126:         if (realm == null || type.isEmpty()) {
127:             return Response.status(Response.Status.NOT_FOUND).build();
128:         }
129:         session.getContext().setRealm(realm);
130:         List<KeySource> result;
131: 
132:         Theme theTheme;
133:         if (theme == null) {
134:             theTheme = session.theme().getTheme(type.get());
135:         } else {
136:             theTheme = session.theme().getTheme(theme, type.get());
137:         }
138: 
139:         final Locale locale = Locale.forLanguageTag(localeString);
140:         if (showSource) {
141:             Properties messagesByLocale = theTheme.getMessages("messages", locale);
142:             Set<KeySource> resultSet = messagesByLocale.entrySet().stream().map(e ->
143:                     new KeySource((String) e.getKey(), (String) e.getValue(), Source.THEME)).collect(toSet());
144: 
145:             Map<Locale, Properties> realmLocalizationMessages = LocaleUtil.getRealmLocalizationTexts(realm, locale);
146:             for (Locale currentLocale = locale; currentLocale != null; currentLocale = LocaleUtil.getParentLocale(currentLocale)) {
147:                 final List<KeySource> realmOverride = realmLocalizationMessages.get(currentLocale).entrySet().stream().map(e ->
148:                         new KeySource((String) e.getKey(), (String) e.getValue(), Source.REALM)).collect(toList());
149:                 resultSet.addAll(realmOverride);
150:             }
151:             result = new ArrayList<>(resultSet);
152:         } else {
153:             result = theTheme.getEnhancedMessages(realm, locale).entrySet().stream().map(e ->
154:                     new KeySource((String) e.getKey(), (String) e.getValue())).collect(toList());
155:         }
156: 
157:         return Cors.builder().allowedOrigins("*").auth().add(Response.ok(result));
```

## head: services/src/main/java/org/keycloak/services/resources/account/AccountConsole.java:301-335
Commit: `02f48f776f43734d1ac8914d3ad6a7115acdcb33`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR37429__20260122/blob/02f48f776f43734d1ac8914d3ad6a7115acdcb33/services/src/main/java/org/keycloak/services/resources/account/AccountConsole.java#L301-L335

```text
301:     private String messagesToJsonString(Properties props) {
302:         if (props == null) return "";
303:         Properties newProps = new Properties();
304:         for (String prop : props.stringPropertyNames()) {
305:             newProps.put(prop, convertPropValue(props.getProperty(prop)));
306:         }
307:         try {
308:             return JsonSerialization.writeValueAsString(newProps);
309:         } catch (IOException e) {
310:             throw new RuntimeException(e);
311:         }
312:     }
313: 
314:     private String convertPropValue(String propertyValue) {
315:         // this mimics the behavior of java.text.MessageFormat used for the freemarker templates:
316:         // To print a single quote one needs to write two single quotes.
317:         // Single quotes will be stripped.
318:         // Usually single quotes would escape parameters, but this not implemented here.
319:         propertyValue = propertyValue.replaceAll("'('?)", "$1");
320:         propertyValue = putJavaParamsInNgTranslateFormat(propertyValue);
321: 
322:         return propertyValue;
323:     }
324: 
325:     // Put java resource bundle params in ngx-translate format
326:     // Do you like {0} and {1} ?
327:     //    becomes
328:     // Do you like {{param_0}} and {{param_1}} ?
329:     private String putJavaParamsInNgTranslateFormat(String propertyValue) {
330:         Matcher matcher = bundleParamPattern.matcher(propertyValue);
331:         while (matcher.find()) {
332:             propertyValue = propertyValue.replace(matcher.group(1), "{{param_" + matcher.group(2) + "}}");
333:         }
334: 
335:         return propertyValue;
```
