# finding-004

CLI default of 1 for flusher_processes limits every deployment to one flusher process, losing per-shard parallelism and causing all shards to flush serially, increasing flush latency and backpressure risk - should default to None

## head: src/sentry/consumers/__init__.py:427-441
Commit: `3162ad68a5c87666788b27a44eb31235025091a9`
Source: https://github.com/code-review-benchmark/sentry__sentry__coderabbit__PR93824__20260122/blob/3162ad68a5c87666788b27a44eb31235025091a9/src/sentry/consumers/__init__.py#L427-L441

```text
427:         "topic": Topic.INGEST_SPANS,
428:         "dlq_topic": Topic.INGEST_SPANS_DLQ,
429:         "strategy_factory": "sentry.spans.consumers.process.factory.ProcessSpansStrategyFactory",
430:         "click_options": [
431:             *multiprocessing_options(default_max_batch_size=100),
432:             click.Option(
433:                 ["--flusher-processes", "flusher_processes"],
434:                 default=1,
435:                 type=int,
436:                 help="Maximum number of processes for the span flusher. Defaults to 1.",
437:             ),
438:         ],
439:     },
440:     "process-segments": {
441:         "topic": Topic.BUFFERED_SEGMENTS,
```

## base: src/sentry/spans/consumers/process/flusher.py:42-96
Commit: `de11fb0166a7244115bb066edd65ec0d6b7e365c`
Source: https://github.com/code-review-benchmark/sentry__sentry__coderabbit__PR93824__20260122/blob/de11fb0166a7244115bb066edd65ec0d6b7e365c/src/sentry/spans/consumers/process/flusher.py#L42-L96

```text
42:         self,
43:         buffer: SpansBuffer,
44:         next_step: ProcessingStrategy[FilteredPayload | int],
45:         produce_to_pipe: Callable[[KafkaPayload], None] | None = None,
46:     ):
47:         self.buffer = buffer
48:         self.next_step = next_step
49: 
50:         self.mp_context = mp_context = multiprocessing.get_context("spawn")
51:         self.stopped = mp_context.Value("i", 0)
52:         self.redis_was_full = False
53:         self.current_drift = mp_context.Value("i", 0)
54:         self.backpressure_since = mp_context.Value("i", 0)
55:         self.healthy_since = mp_context.Value("i", 0)
56:         self.process_restarts = 0
57:         self.produce_to_pipe = produce_to_pipe
58: 
59:         self._create_process()
60: 
61:     def _create_process(self):
62:         # Optimistically reset healthy_since to avoid a race between the
63:         # starting process and the next flush cycle. Keep back pressure across
64:         # the restart, however.
65:         self.healthy_since.value = int(time.time())
66: 
67:         make_process: Callable[..., multiprocessing.context.SpawnProcess | threading.Thread]
68:         if self.produce_to_pipe is None:
69:             target = run_with_initialized_sentry(
70:                 SpanFlusher.main,
71:                 # unpickling buffer will import sentry, so it needs to be
72:                 # pickled separately. at the same time, pickling
73:                 # synchronization primitives like multiprocessing.Value can
74:                 # only be done by the Process
75:                 self.buffer,
76:             )
77:             make_process = self.mp_context.Process
78:         else:
79:             target = partial(SpanFlusher.main, self.buffer)
80:             make_process = threading.Thread
81: 
82:         self.process = make_process(
83:             target=target,
84:             args=(
85:                 self.stopped,
86:                 self.current_drift,
87:                 self.backpressure_since,
88:                 self.healthy_since,
89:                 self.produce_to_pipe,
90:             ),
91:             daemon=True,
92:         )
93: 
94:         self.process.start()
95: 
96:     @staticmethod
```

## head: src/sentry/spans/consumers/process/flusher.py:44-68
Commit: `3162ad68a5c87666788b27a44eb31235025091a9`
Source: https://github.com/code-review-benchmark/sentry__sentry__coderabbit__PR93824__20260122/blob/3162ad68a5c87666788b27a44eb31235025091a9/src/sentry/spans/consumers/process/flusher.py#L44-L68

```text
44:         self,
45:         buffer: SpansBuffer,
46:         next_step: ProcessingStrategy[FilteredPayload | int],
47:         max_processes: int | None = None,
48:         produce_to_pipe: Callable[[KafkaPayload], None] | None = None,
49:     ):
50:         self.next_step = next_step
51:         self.max_processes = max_processes or len(buffer.assigned_shards)
52: 
53:         self.mp_context = mp_context = multiprocessing.get_context("spawn")
54:         self.stopped = mp_context.Value("i", 0)
55:         self.redis_was_full = False
56:         self.current_drift = mp_context.Value("i", 0)
57:         self.produce_to_pipe = produce_to_pipe
58: 
59:         # Determine which shards get their own processes vs shared processes
60:         self.num_processes = min(self.max_processes, len(buffer.assigned_shards))
61:         self.process_to_shards_map: dict[int, list[int]] = {
62:             i: [] for i in range(self.num_processes)
63:         }
64:         for i, shard in enumerate(buffer.assigned_shards):
65:             process_index = i % self.num_processes
66:             self.process_to_shards_map[process_index].append(shard)
67: 
68:         self.processes: dict[int, multiprocessing.context.SpawnProcess | threading.Thread] = {}
```
