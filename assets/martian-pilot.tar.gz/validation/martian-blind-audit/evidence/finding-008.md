# finding-008

When the unsubscribe route is entered through client-side navigation, the model calls PostStream.loadTopicView which requests /t/<topicId>.json instead of the unsubscribe endpoint, so the notification level remains unchanged

## head: app/assets/javascripts/discourse/routes/topic-unsubscribe.js.es6:1-23
Commit: `6669a2d94d76eea3b99b8c476d12b1eb66726b07`
Source: https://github.com/code-review-benchmark/discourse__discourse-graphite__coderabbit__PR2__20260122/blob/6669a2d94d76eea3b99b8c476d12b1eb66726b07/app/assets/javascripts/discourse/routes/topic-unsubscribe.js.es6#L1-L23

```text
1: import PostStream from "discourse/models/post-stream";
2: 
3: export default Discourse.Route.extend({
4:   model(params) {
5:     const topic = this.store.createRecord("topic", { id: params.id });
6:     return PostStream.loadTopicView(params.id).then(json => {
7:       topic.updateFromJson(json);
8:       return topic;
9:     });
10:   },
11: 
12:   afterModel(topic) {
13:     // hide the notification reason text
14:     topic.set("details.notificationReasonText", null);
15:   },
16: 
17:   actions: {
18:     didTransition() {
19:       this.controllerFor("application").set("showFooter", true);
20:       return true;
21:     }
22:   }
23: });
```

## head: app/assets/javascripts/discourse/models/post-stream.js.es6:811-823
Commit: `6669a2d94d76eea3b99b8c476d12b1eb66726b07`
Source: https://github.com/code-review-benchmark/discourse__discourse-graphite__coderabbit__PR2__20260122/blob/6669a2d94d76eea3b99b8c476d12b1eb66726b07/app/assets/javascripts/discourse/models/post-stream.js.es6#L811-L823

```text
811:   loadTopicView(topicId, args) {
812:     const opts = _.merge({}, args);
813:     let url = Discourse.getURL("/t/") + topicId;
814:     if (opts.nearPost) {
815:       url += "/" + opts.nearPost;
816:     }
817:     delete opts.nearPost;
818:     delete opts.__type;
819:     delete opts.store;
820: 
821:     return PreloadStore.getAndRemove("topic_" + topicId, function() {
822:       return Discourse.ajax(url + ".json", {data: opts});
823:     });
```

## head: app/assets/javascripts/discourse/routes/app-route-map.js.es6:10-14
Commit: `6669a2d94d76eea3b99b8c476d12b1eb66726b07`
Source: https://github.com/code-review-benchmark/discourse__discourse-graphite__coderabbit__PR2__20260122/blob/6669a2d94d76eea3b99b8c476d12b1eb66726b07/app/assets/javascripts/discourse/routes/app-route-map.js.es6#L10-L14

```text
10:     this.route('fromParamsNear', { path: '/:nearPost' });
11:   });
12:   this.resource('topicBySlug', { path: '/t/:slug' });
13:   this.route('topicUnsubscribe', { path: '/t/:slug/:id/unsubscribe' });
14: 
```

## head: config/routes.rb:438-442
Commit: `6669a2d94d76eea3b99b8c476d12b1eb66726b07`
Source: https://github.com/code-review-benchmark/discourse__discourse-graphite__coderabbit__PR2__20260122/blob/6669a2d94d76eea3b99b8c476d12b1eb66726b07/config/routes.rb#L438-L442

```text
438:   get "t/:slug/:topic_id/moderator-liked" => "topics#moderator_liked", constraints: {topic_id: /\d+/}
439:   get "t/:slug/:topic_id/summary" => "topics#show", defaults: {summary: true}, constraints: {topic_id: /\d+/}
440:   get "t/:slug/:topic_id/unsubscribe" => "topics#unsubscribe", constraints: {topic_id: /\d+/}
441:   get "t/:topic_id/unsubscribe" => "topics#unsubscribe", constraints: {topic_id: /\d+/}
442:   get "t/:topic_id/summary" => "topics#show", constraints: {topic_id: /\d+/}
```
