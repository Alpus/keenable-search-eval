# finding-006

Unsubscribe messaging is misleading - it says notifications will stop but actually only lowers tracking/watching to regular, users can still receive reply or mention notifications

## head: app/controllers/topics_controller.rb:105-115
Commit: `6669a2d94d76eea3b99b8c476d12b1eb66726b07`
Source: https://github.com/code-review-benchmark/discourse__discourse-graphite__coderabbit__PR2__20260122/blob/6669a2d94d76eea3b99b8c476d12b1eb66726b07/app/controllers/topics_controller.rb#L105-L115

```text
105:     tu = TopicUser.find_by(user_id: current_user.id, topic_id: params[:topic_id])
106: 
107:     if tu.notification_level > TopicUser.notification_levels[:regular]
108:       tu.notification_level = TopicUser.notification_levels[:regular]
109:     else
110:       tu.notification_level = TopicUser.notification_levels[:muted]
111:     end
112: 
113:     tu.save!
114: 
115:     perform_show_response
```

## head: config/locales/client.en.yml:983-987
Commit: `6669a2d94d76eea3b99b8c476d12b1eb66726b07`
Source: https://github.com/code-review-benchmark/discourse__discourse-graphite__coderabbit__PR2__20260122/blob/6669a2d94d76eea3b99b8c476d12b1eb66726b07/config/locales/client.en.yml#L983-L987

```text
983:     topic:
984:       unsubscribe:
985:         stop_notifications: "You will stop receiving notifications for <strong>{{title}}</strong>."
986:         change_notification_state: "You can change your notification state"
987:       filter_to: "{{post_count}} posts in topic"
```

## head: config/locales/server.en.yml:1852-1855
Commit: `6669a2d94d76eea3b99b8c476d12b1eb66726b07`
Source: https://github.com/code-review-benchmark/discourse__discourse-graphite__coderabbit__PR2__20260122/blob/6669a2d94d76eea3b99b8c476d12b1eb66726b07/config/locales/server.en.yml#L1852-L1855

```text
1852:   unsubscribe_link: |
1853:     To unsubscribe from these emails, visit your [user preferences](%{user_preferences_url}).
1854: 
1855:     To stop receiving notifications about this particular topic, [click here](%{unsubscribe_url}).
```

## head: app/services/post_alerter.rb:95-105
Commit: `6669a2d94d76eea3b99b8c476d12b1eb66726b07`
Source: https://github.com/code-review-benchmark/discourse__discourse-graphite__coderabbit__PR2__20260122/blob/6669a2d94d76eea3b99b8c476d12b1eb66726b07/app/services/post_alerter.rb#L95-L105

```text
95: 
96:     notifier_id = opts[:user_id] || post.user_id
97: 
98:     # apply muting here
99:     return if notifier_id && MutedUser.where(user_id: user.id, muted_user_id: notifier_id)
100:                                       .joins(:muted_user)
101:                                       .where('NOT admin AND NOT moderator')
102:                                       .exists?
103: 
104:     # skip if muted on the topic
105:     return if TopicUser.get(post.topic, user).try(:notification_level) == TopicUser.notification_levels[:muted]
```
