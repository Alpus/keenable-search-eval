# finding-005

Loop control variable process_index is not used within loop body - should be renamed to _process_index

## head: src/sentry/spans/consumers/process/flusher.py:328-347
Commit: `3162ad68a5c87666788b27a44eb31235025091a9`
Source: https://github.com/code-review-benchmark/sentry__sentry__coderabbit__PR93824__20260122/blob/3162ad68a5c87666788b27a44eb31235025091a9/src/sentry/spans/consumers/process/flusher.py#L328-L347

```text
328:     def join(self, timeout: float | None = None):
329:         # set stopped flag first so we can "flush" the background threads while
330:         # next_step is also shutting down. we can do two things at once!
331:         self.stopped.value = True
332:         deadline = time.time() + timeout if timeout else None
333: 
334:         self.next_step.join(timeout)
335: 
336:         # Wait for all processes to finish
337:         for process_index, process in self.processes.items():
338:             if deadline is not None:
339:                 remaining_time = deadline - time.time()
340:                 if remaining_time <= 0:
341:                     break
342: 
343:             while process.is_alive() and (deadline is None or deadline > time.time()):
344:                 time.sleep(0.1)
345: 
346:             if isinstance(process, multiprocessing.Process):
347:                 process.terminate()
```
