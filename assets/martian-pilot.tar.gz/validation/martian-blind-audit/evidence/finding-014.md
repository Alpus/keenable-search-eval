# finding-014

Recovery code validation in federated credential validator only checks anyMatch and leaves the stored list unchanged, allowing code reuse on subsequent logins - need to remove matched challenge response from generatedKeys and persist the updated list

## head: testsuite/integration-arquillian/servers/auth-server/services/testsuite-providers/src/main/java/org/keycloak/testsuite/federation/BackwardsCompatibilityUserStorage.java:309-340
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/testsuite/integration-arquillian/servers/auth-server/services/testsuite-providers/src/main/java/org/keycloak/testsuite/federation/BackwardsCompatibilityUserStorage.java#L309-L340

```text
309:         } else if (isOTPType(input.getType())) {
310:             UserCredentialModel otpCredential = (UserCredentialModel) input;
311: 
312:             // Special hardcoded OTP, which is always considered valid
313:             if ("123456".equals(otpCredential.getValue())) {
314:                 return true;
315:             }
316: 
317:             CredentialModel storedOTPCredential = myUser.otp;
318:             if (storedOTPCredential == null) {
319:                 log.warnf("Not found credential for the user %s", user.getUsername());
320:                 return false;
321:             }
322: 
323:             TimeBasedOTP validator = new TimeBasedOTP(storedOTPCredential.getAlgorithm(), storedOTPCredential.getDigits(),
324:                     storedOTPCredential.getPeriod(), realm.getOTPPolicy().getLookAheadWindow());
325:             return validator.validateTOTP(otpCredential.getValue(), storedOTPCredential.getValue().getBytes());
326:         } else if (input.getType().equals(RecoveryAuthnCodesCredentialModel.TYPE)) {
327:             CredentialModel storedRecoveryKeys = myUser.recoveryCodes;
328:             if (storedRecoveryKeys == null) {
329:                 log.warnf("Not found credential for the user %s", user.getUsername());
330:                 return false;
331:             }
332:             List generatedKeys;
333:             try {
334:                 generatedKeys = JsonSerialization.readValue(storedRecoveryKeys.getCredentialData(), List.class);
335:             } catch (IOException e) {
336:                 log.warnf("Cannot deserialize recovery keys credential for the user %s", user.getUsername());
337:                 return false;
338:             }
339: 
340:             return generatedKeys.stream().anyMatch(key -> key.equals(input.getChallengeResponse()));
```

## head: services/src/main/java/org/keycloak/credential/RecoveryAuthnCodesCredentialProvider.java:99-112
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/services/src/main/java/org/keycloak/credential/RecoveryAuthnCodesCredentialProvider.java#L99-L112

```text
99:     public boolean isValid(RealmModel realm, UserModel user, CredentialInput credentialInput) {
100:         String rawInputRecoveryAuthnCode = credentialInput.getChallengeResponse();
101:         Optional<CredentialModel> credential = user.credentialManager().getStoredCredentialsByTypeStream(getType()).findFirst();
102:         if (credential.isPresent()) {
103:             RecoveryAuthnCodesCredentialModel credentialModel = RecoveryAuthnCodesCredentialModel
104:                     .createFromCredentialModel(credential.get());
105:             if (!credentialModel.allCodesUsed()) {
106:                 Optional<RecoveryAuthnCodeRepresentation> nextRecoveryAuthnCode = credentialModel.getNextRecoveryAuthnCode();
107:                 if (nextRecoveryAuthnCode.isPresent()) {
108:                     String nextRecoveryCode = nextRecoveryAuthnCode.get().getEncodedHashedValue();
109:                     if (RecoveryAuthnCodesUtils.verifyRecoveryCodeInput(rawInputRecoveryAuthnCode, nextRecoveryCode)) {
110:                         credentialModel.removeRecoveryAuthnCode();
111:                         user.credentialManager().updateStoredCredential(credentialModel);
112:                         return true;
```

## head: testsuite/integration-arquillian/tests/base/src/test/java/org/keycloak/testsuite/federation/storage/BackwardsCompatibilityUserStorageTest.java:240-270
Commit: `ce2dcc537b4b1f98a335e88cfe8e0b804483252a`
Source: https://github.com/code-review-benchmark/keycloak__keycloak__coderabbit__PR38446__20260122/blob/ce2dcc537b4b1f98a335e88cfe8e0b804483252a/testsuite/integration-arquillian/tests/base/src/test/java/org/keycloak/testsuite/federation/storage/BackwardsCompatibilityUserStorageTest.java#L240-L270

```text
240:     @Test
241:     public void testRecoveryKeysSetupAndLogin() throws URISyntaxException, IOException {
242:         try {
243:             configureBrowserFlowWithRecoveryAuthnCodes(testingClient, 0);
244: 
245:             String userId = addUserAndResetPassword("otp1", "pass");
246:             getCleanup().addUserId(userId);
247: 
248:             // Setup RecoveryKeys
249:             List<String> recoveryKeys = setupRecoveryKeysForUserWithRequiredAction(userId, true);
250: 
251:             // Assert user has RecoveryKeys in the userStorage
252:             assertUserDontHaveDBCredentials();
253:             assertUserHasRecoveryKeysCredentialInUserStorage(true);
254: 
255:             TestAppHelper testAppHelper = new TestAppHelper(oauth, loginPage, appPage);
256: 
257:             // Authenticate as the user
258:             testAppHelper.startLogin("otp1", "pass");
259:             enterRecoveryCodes(enterRecoveryAuthnCodePage, driver, 0, recoveryKeys);
260:             enterRecoveryAuthnCodePage.clickSignInButton();
261: 
262:             appPage.assertCurrent();
263: 
264:             testAppHelper.logout();
265:         } finally {
266:             // Revert copy of browser flow to original to keep clean slate after this test
267:             BrowserFlowTest.revertFlows(testRealm(), BROWSER_FLOW_WITH_RECOVERY_AUTHN_CODES);
268:         }
269:     }
270: 
```
