# Search attribution and audit limitations

All 20 MCP reviews in the main cohort have an attributed successful search. Keenable made 39 successful searches and 43 fetch attempts (four failed). Exa made 36 successful searches and 52 fetch attempts (two failed). Five Exa fetch requests were rejected at the call cap. All reserved calls finished. Fetch used the same gateway reader in both arms.

The control cohort has four MCP reviews with successful attributed searches: Keenable made nine searches and nine fetch attempts (two failed); Exa made five searches and 15 fetch attempts (one failed). No attributed control rejection was saved.

Native CodeRabbit calls and internal retrieval remain unknown. Missing rejection files do not establish zero rejections. The gateway has 22 unscoped rejections, none with an identity matching these runs; they remain unassigned. These limits constrain causal claims, not the completed main cohort's descriptive native scores. Small samples, one review per configuration and task, and reconstructed public inputs prevent a general provider-quality conclusion.

A separate 20-finding source audit found 13 source-supported introduced findings, two test-fixture limitations, four contradicted/style/preexisting findings and one unresolved. The selected sample includes duplicates and related defects. Partial blinding limitations were disclosed. This audit does not estimate precision or change native scores.

All 48 saved CodeRabbit review artifacts report included allowance. An actual first overage is not evidenced.

Evidence: `attribution.json` contains per-attempt counts and paths. `receipt.json` binds inputs by SHA256. Reproduce offline with `python3 validation/submission-attribution/reconcile.py --source ../keenable-search-eval` from the release checkout.
