#!/usr/bin/env python3
"""Offline attribution audit. Reads evidence only; writes this candidate directory."""
import argparse
import collections
import hashlib
import json
import re
from pathlib import Path
from urllib.parse import urlsplit

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', type=Path, default=HERE.parents[2] / 'keenable-search-eval')
args = parser.parse_args()
ROOT = args.source.resolve()
inputs = {}
checks = collections.Counter()


def read(path):
    raw = path.read_bytes()
    label = ('measured/' + str(path.relative_to(ROOT))) if path.is_relative_to(ROOT) else ('release/' + str(path.relative_to(HERE.parents[1])))
    inputs[label] = hashlib.sha256(raw).hexdigest()
    return raw


def js(path):
    return json.loads(read(path))


def lines(path):
    return [json.loads(x) for x in read(path).splitlines() if x.strip()]


def require(condition, label):
    if not condition:
        raise ValueError(label)
    checks[label] += 1


def identity(url):
    p = urlsplit(url or '')
    return (p.hostname or '').lower() + p.path.rstrip('/').lower()


def bodies(value):
    if isinstance(value, dict):
        for k, v in value.items():
            if k == 'body' and isinstance(v, str):
                yield v
            else:
                yield from bodies(v)
    elif isinstance(value, list):
        for v in value:
            yield from bodies(v)


def audit_run(run):
    p = ROOT / 'runs' / run
    state, config = js(p / 'state.json'), js(p / 'config.json')
    reports = {x['attempt_id']: x for x in js(p / 'tool-calls.json')}
    runtime = js(p / 'evidence/gateway-config.json')['runtime_sha256']
    arms = {x['id']: x for x in config['arms']}
    result = js(p / 'grading/martian-result.json')
    read(p / 'report.md')
    attempts, errors = [], collections.Counter()
    for a in state['attempts']:
        aid, arm = a['id'], a['configuration']
        r = reports[aid]
        require((r['configuration'], r['task_id'], r['repeat'], r['role']) == (arm, a['task_id'], a['repeat'], a['role']), 'report_schedule_identity')
        require(a['head_sha'] == a['expected_head'], 'scheduled_head_identity')
        settings = js(p / a['artifact_dir'] / 'effective-settings.json')['knowledge_base']
        require(settings['web_search']['enabled'] == arms[arm]['native_search'], 'requested_native_setting')
        require(settings['mcp']['usage'] == ('enabled' if arms[arm]['mcp'] else 'disabled'), 'requested_mcp_setting')
        gh = js(p / a['artifact_dir'] / 'github.json')
        statuses = [s for page in gh['commit_statuses'] for s in page['items']]
        require(any(s['id'] == a['status_id'] and s['state'] == 'success' and s['context'] == 'CodeRabbit' for s in statuses), 'completion_status_identity')
        reviews = [s for page in gh['reviews'] for s in page['items']]
        require(any(s['id'] == a['review_id'] and s['commit_id'] == a['expected_head'] for s in reviews), 'submitted_review_head_identity')
        billing = sorted(set(line for body in bodies(gh) for line in body.splitlines() if 'This review used your included allowance.' in line or re.search(r'\boverage\b|pay.as.you.go', line, re.I)))
        name = hashlib.sha256(aid.encode()).hexdigest()
        trace = p / 'evidence/gateway' / (name + '.jsonl')
        reservations, finished, rejected = {}, {}, []
        if trace.exists():
            for event in lines(trace):
                require(event['attempt_id'] == aid and event['configuration'] == arm and event['gateway_runtime_sha256'] == runtime, 'trace_attempt_arm_runtime_identity')
                require(event['operation'] in ('search', 'fetch') and event['event'] in ('reserved', 'finished'), 'trace_event_type')
                bucket = reservations if event['event'] == 'reserved' else finished
                require(event['call_id'] not in bucket, 'unique_call_event')
                bucket[event['call_id']] = event
            require(set(finished) <= set(reservations), 'finish_has_reservation')
            for cid, event in finished.items():
                require(all(event[k] == reservations[cid][k] for k in ('operation', 'profile', 'fingerprint', 'attempt_fingerprint')), 'finish_reservation_identity')
                if event['operation'] == 'search' and event.get('ok') is True:
                    require(event.get('provider') == arm, 'search_response_provider_identity')
            require(hashlib.sha256(trace.read_bytes()).hexdigest() == r['trace_sha256'], 'reported_trace_digest')
            original = ROOT / '.gateway/traces' / trace.name
            if original.exists():
                require(read(original) == trace.read_bytes(), 'captured_trace_matches_original')
        reject_path = trace.with_name(name + '.rejections.jsonl')
        if reject_path.exists():
            rejected = lines(reject_path)
            require(hashlib.sha256(reject_path.read_bytes()).hexdigest() == r['rejection_sha256'], 'reported_rejection_digest')
            for event in rejected:
                require(event['event'] == 'rejected' and event['attempt_id'] == aid and event['configuration'] == arm and identity(event['review_url']) == identity(a['review_url']) and event['gateway_runtime_sha256'] == runtime, 'rejection_attempt_arm_review_runtime_identity')
            original = ROOT / '.gateway/traces' / reject_path.name
            if original.exists():
                require(read(original) == reject_path.read_bytes(), 'captured_rejections_match_original')
        if arms[arm]['mcp']:
            require(trace.exists() and any(e['operation'] == 'search' and e.get('ok') is True for e in finished.values()), 'mcp_attempt_has_successful_search')
        counters = {}
        for op in ('search', 'fetch'):
            counters[op] = None if not trace.exists() else {
                'reserved': sum(e['operation'] == op for e in reservations.values()),
                'successful': sum(e['operation'] == op and e.get('ok') is True for e in finished.values()),
                'failed': sum(e['operation'] == op and e.get('ok') is False for e in finished.values()),
                'unfinished': sum(e['operation'] == op and cid not in finished for cid, e in reservations.items()),
                'provider': arm if op == 'search' else 'shared_gateway_reader',
            }
            require(r['observed_' + op + '_calls'] == (counters[op]['reserved'] if counters[op] else None), 'reported_operation_count')
        require(all(e['operation'] == 'fetch' and e['error'] == 'call_cap_exhausted' for e in rejected), 'observed_rejections_are_fetch_cap')
        failure_counts = collections.Counter(e['error'] for e in finished.values() if e.get('ok') is False)
        rejection_counts = collections.Counter(e['error'] for e in rejected)
        errors.update(failure_counts)
        require(r['failed_calls'] == (sum(failure_counts.values()) if trace.exists() else None), 'reported_failure_count')
        require(r['rejected_calls'] == (len(rejected) if reject_path.exists() else None), 'reported_rejection_count')
        attempts.append({
            'attempt_id': aid, 'task_id': a['task_id'], 'configuration': arm, 'repeat': a['repeat'], 'role': a['role'],
            'review_completed': a['status'] == 'completed', 'native_grading_present': (p / a['artifact_dir'] / 'martian-grading.json').exists(),
            'source': f'runs/{run}/{a["artifact_dir"]}', 'trace': str(trace.relative_to(ROOT)) if trace.exists() else None,
            'trace_sha256': r['trace_sha256'], 'calls': counters, 'failure_errors': dict(failure_counts),
            'rejection_file': str(reject_path.relative_to(ROOT)) if reject_path.exists() else None,
            'observed_rejections': len(rejected), 'rejections_by_operation': dict(collections.Counter(e['operation'] for e in rejected)),
            'rejection_errors': dict(rejection_counts), 'rejection_coverage': 'attributed_records_only; unscoped events excluded',
            'native_calls': None, 'billing_evidence': billing,
        })
    grouped = []
    for arm in sorted(arms):
        rows = [r for r in attempts if r['configuration'] == arm]
        observed = [r for r in rows if r['trace']]
        calls = {op: ({k: sum(r['calls'][op][k] for r in observed) for k in ('reserved', 'successful', 'failed', 'unfinished')} if observed else None) for op in ('search', 'fetch')}
        grouped.append({'configuration': arm, 'attempts': len(rows), 'completed_reviews': sum(r['review_completed'] for r in rows), 'traced_attempts': len(observed), 'calls': calls, 'observed_attributed_rejections': sum(r['observed_rejections'] for r in rows), 'attempts_with_rejection_file': sum(bool(r['rejection_file']) for r in rows), 'native_calls': None})
    return {'run_id': run, 'arms': grouped, 'attempts': attempts, 'errors': dict(errors), 'native_result_complete': result['complete'], 'grading_files_present': sum(r['native_grading_present'] for r in attempts), 'native_result_failures': result['failures'], 'headline_metrics': [r for r in result['report_series'] if r['scope'] == 'core' and r['metric'] in ('F2', 'precision', 'recall')], 'included_allowance_receipts': sum(any('This review used your included allowance.' in s for s in r['billing_evidence']) for r in attempts)}


runs = [audit_run(r) for r in ('martian-pilot-002', 'martian-controls-002')]
require(all(any('This review used your included allowance.' in s for s in a['billing_evidence']) and not any(re.search(r'\boverage\b|pay.as.you.go', s, re.I) for s in a['billing_evidence']) for r in runs for a in r['attempts']), 'all_review_receipts_report_included_allowance_only')
unscoped_path = ROOT / '.gateway/traces/rejections.jsonl'
unscoped = lines(unscoped_path)
require(all(e.get('attempt_id') is None and e.get('configuration') is None for e in unscoped), 'global_rejections_are_unscoped')
all_urls = {identity(a['review_url']) for r in runs for a in js(ROOT / 'runs' / r['run_id'] / 'state.json')['attempts']}
matching = sum(bool(e.get('review_url')) and identity(e['review_url']) in all_urls for e in unscoped)
require(matching == 0, 'no_unscoped_review_identity_matches_schedule')
blind = js(HERE.parent / 'martian-blind-audit/root-validation.json')
verdicts_path = HERE.parent / 'martian-blind-audit/verdicts.json'
require(hashlib.sha256(read(verdicts_path)).hexdigest() == blind['verdicts_sha256'], 'locked_blind_verdict_digest')
trial = js(ROOT / 'validation/coderabbit-trial-overage.json')
for file in ('src/search_eval/gateway.py', 'src/search_eval/report.py'):
    read(ROOT / file)
summary = {
    'schema_version': 1, 'method': 'Offline reconciliation of existing saved evidence; no network, model calls, native-score edits, or unscoped-event reassignment.',
    'runs': runs,
    'unscoped_gateway_rejections': {'observed': len(unscoped), 'errors': dict(collections.Counter(e['error'] for e in unscoped)), 'operations': dict(collections.Counter(e.get('operation') or 'unknown' for e in unscoped)), 'schedule_review_identity_matches': matching, 'assigned_to_runs': 0, 'source': '.gateway/traces/rejections.jsonl'},
    'blind_audit': {'source': 'validation/martian-blind-audit/root-validation.json', 'disposition_counts': blind['disposition_counts'], 'limitations': blind['limitations'], 'native_scores_changed': blind['native_scores_changed']},
    'billing': {'included_allowance_receipts': sum(r['included_allowance_receipts'] for r in runs), 'review_count': sum(len(r['attempts']) for r in runs), 'actual_first_overage_receipt_observed': False, 'trial_record_status': trial['confirmation_pending'], 'interpretation': 'Eligibility and subscription settings are not evidence that an overage occurred. All 48 review artifacts explicitly report included allowance.'},
    'interpretation': [
        'Main cohort native metrics remain publishable as descriptive frozen-cohort results. Attribution reconciliation found no missing MCP attempt trace, failed search, unfinished call, or identity mismatch.',
        'Controls are a separate cohort. Missing valid grading blocks only their complete headline, not the completed main cohort. Use native_result_complete at this receipt snapshot.',
        'Each MCP arm has a successful attributed search on every main and control attempt. Fetch is the same bounded gateway reader in both arms, not a provider search or provider-specific reader.',
        'No trace in native/none arms means no instrumented MCP trace, not a measured zero for all retrieval. Native calls, service model identity and internal retrieval remain unknown. Requested disabled settings do not prove service internals.',
        'An absent rejection file means no saved attributed rejection record. The global unscoped log prevents interpreting the per-arm observed rejection count as complete rejected-call coverage.',
        'Single reviews per arm and task, a small reconstructed public subset, live changing retrieval, optional tool use and opaque service internals limit causal attribution and generalization. Search success proves returned gateway output, not relevance or use in a finding.',
        'The 20-finding manual audit is diagnostic: 13 source-supported introduced findings, two test-fixture limitations, four contradicted/style/preexisting findings and one unresolved. It includes duplicates and related defects. It cannot estimate precision or repair native scores. Partial blinding limitations remain disclosed.'
    ]
}
(HERE / 'attribution.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
public = [
    '# Search attribution and audit limitations', '',
    'All 20 MCP reviews in the main cohort have an attributed successful search. Keenable made 39 successful searches and 43 fetch attempts (four failed). Exa made 36 successful searches and 52 fetch attempts (two failed). Five Exa fetch requests were rejected at the call cap. All reserved calls finished. Fetch used the same gateway reader in both arms.', '',
    'The control cohort has four MCP reviews with successful attributed searches: Keenable made nine searches and nine fetch attempts (two failed); Exa made five searches and 15 fetch attempts (one failed). No attributed control rejection was saved.', '',
    'Native CodeRabbit calls and internal retrieval remain unknown. Missing rejection files do not establish zero rejections. The gateway has 22 unscoped rejections, none with an identity matching these runs; they remain unassigned. These limits constrain causal claims, not the completed main cohort\'s descriptive native scores. Small samples, one review per configuration and task, and reconstructed public inputs prevent a general provider-quality conclusion.', '',
    'A separate 20-finding source audit found 13 source-supported introduced findings, two test-fixture limitations, four contradicted/style/preexisting findings and one unresolved. The selected sample includes duplicates and related defects. Partial blinding limitations were disclosed. This audit does not estimate precision or change native scores.', '',
    'All 48 saved CodeRabbit review artifacts report included allowance. An actual first overage is not evidenced.', '',
    'Evidence: `attribution.json` contains per-attempt counts and paths. `receipt.json` binds inputs by SHA256. Reproduce offline with `python3 validation/submission-attribution/reconcile.py --source ../keenable-search-eval` from the release checkout.', ''
]
(HERE / 'candidate.md').write_text('\n'.join(public))
receipt = {'status': 'passed', 'checks': dict(checks), 'input_sha256': inputs, 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'output_sha256': {f: hashlib.sha256((HERE / f).read_bytes()).hexdigest() for f in ('attribution.json', 'candidate.md')}, 'side_effects': 'Only the three files attribution.json, candidate.md and receipt.json in this candidate directory are written.'}
(HERE / 'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': 'passed', 'checks': sum(checks.values()), 'runs': [{k: r[k] for k in ('run_id', 'arms', 'native_result_complete', 'grading_files_present')} for r in runs]}, indent=2))
