"""Controlled developer search evaluation."""
