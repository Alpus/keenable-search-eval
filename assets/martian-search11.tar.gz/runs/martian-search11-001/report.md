# martian: COMPLETE

Controlled public-subset pilot

Run: `martian-search11-001`. Baseline: `native`. Repeats: 1.

Scores below are the suite's native metrics. Operational failures remain visible.

## Models and inputs

[Resolved inputs](effective-inputs.json) record controlled settings and provider-managed defaults.


Dataset: `data/martian-search11.json`; SHA256: `4f88417ce15f630ceb072f6c68f53a79edbd102f332aee9705dbbca2d3e56b38`.
Scorer: `martian-original` at `e616e849755441da38f18bf3adba2c9583b03803`. File hashes are in resolved inputs.
Schedule seed: `1729`; repeats: `1`. The schedule seed does not control model sampling.
Requested search configurations: `native` (native=True, MCP=none); `none` (native=False, MCP=none); `keenable` (native=False, MCP=keenable); `exa` (native=False, MCP=exa).
Requested provider modes: `exa`: `auto` / `authenticated`; `keenable`: `pro` / `authenticated`.
Limits: `{"episode_timeout_seconds": 720, "max_attempts": 44, "max_concurrent_reviews": 10, "max_fetch_calls": 8, "max_review_events_per_hour": null, "max_search_calls": 8, "poll_seconds": 10, "review_timeout_seconds": 1800}`.
Requested settings do not prove service application. Observed model IDs appear below; tool calls and responses remain in the evidence bundle. Unreported internal defaults remain unknown.

| Stage | Requested model | Observed model | Evidence limit |
|---|---|---|---|
| CodeRabbit reviewer | not selectable / unrecorded | not observed | Service-managed; model identity is not exposed by this integration |
| Martian extraction, deduplication and judge | claude-opus-4-5-20251101 | claude-opus-4-5-20251101 | Only successful saved HTTP responses establish observed identity |

## Native scores

| Configuration | Repeat | Role | Scope | Metric | Value | Denominator | Complete |
|---|---:|---|---|---|---:|---:|---|
| exa | 1 | scored | core | precision | 0.5490 | 47 | True |
| exa | 1 | scored | core | recall | 0.5957 | 47 | True |
| exa | 1 | scored | core | f1 | 0.5714 | 47 | True |
| exa | 1 | scored | core | F2 | 0.5858 | 47 | True |
| exa | 1 | scored | core | tp | 28.0000 | 47 | True |
| exa | 1 | scored | core | fp | 23.0000 | 47 | True |
| exa | 1 | scored | core | fn | 19.0000 | 47 | True |
| exa | 1 | scored | core | prs | 11.0000 | 47 | True |
| exa | 1 | scored | strict | precision | 0.5400 | 43 | True |
| exa | 1 | scored | strict | recall | 0.6279 | 43 | True |
| exa | 1 | scored | strict | f1 | 0.5806 | 43 | True |
| exa | 1 | scored | strict | F2 | 0.6081 | 43 | True |
| exa | 1 | scored | strict | tp | 27.0000 | 43 | True |
| exa | 1 | scored | strict | fp | 23.0000 | 43 | True |
| exa | 1 | scored | strict | fn | 16.0000 | 43 | True |
| exa | 1 | scored | strict | prs | 11.0000 | 43 | True |
| exa | 1 | scored | all | precision | 0.5490 | 48 | True |
| exa | 1 | scored | all | recall | 0.5833 | 48 | True |
| exa | 1 | scored | all | f1 | 0.5657 | 48 | True |
| exa | 1 | scored | all | F2 | 0.5761 | 48 | True |
| exa | 1 | scored | all | tp | 28.0000 | 48 | True |
| exa | 1 | scored | all | fp | 23.0000 | 48 | True |
| exa | 1 | scored | all | fn | 20.0000 | 48 | True |
| exa | 1 | scored | all | prs | 11.0000 | 48 | True |
| keenable | 1 | scored | core | precision | 0.4762 | 47 | True |
| keenable | 1 | scored | core | recall | 0.6383 | 47 | True |
| keenable | 1 | scored | core | f1 | 0.5455 | 47 | True |
| keenable | 1 | scored | core | F2 | 0.5976 | 47 | True |
| keenable | 1 | scored | core | tp | 30.0000 | 47 | True |
| keenable | 1 | scored | core | fp | 33.0000 | 47 | True |
| keenable | 1 | scored | core | fn | 17.0000 | 47 | True |
| keenable | 1 | scored | core | prs | 11.0000 | 47 | True |
| keenable | 1 | scored | strict | precision | 0.4762 | 43 | True |
| keenable | 1 | scored | strict | recall | 0.6977 | 43 | True |
| keenable | 1 | scored | strict | f1 | 0.5660 | 43 | True |
| keenable | 1 | scored | strict | F2 | 0.6383 | 43 | True |
| keenable | 1 | scored | strict | tp | 30.0000 | 43 | True |
| keenable | 1 | scored | strict | fp | 33.0000 | 43 | True |
| keenable | 1 | scored | strict | fn | 13.0000 | 43 | True |
| keenable | 1 | scored | strict | prs | 11.0000 | 43 | True |
| keenable | 1 | scored | all | precision | 0.4762 | 48 | True |
| keenable | 1 | scored | all | recall | 0.6250 | 48 | True |
| keenable | 1 | scored | all | f1 | 0.5405 | 48 | True |
| keenable | 1 | scored | all | F2 | 0.5882 | 48 | True |
| keenable | 1 | scored | all | tp | 30.0000 | 48 | True |
| keenable | 1 | scored | all | fp | 33.0000 | 48 | True |
| keenable | 1 | scored | all | fn | 18.0000 | 48 | True |
| keenable | 1 | scored | all | prs | 11.0000 | 48 | True |
| native | 1 | scored | core | precision | 0.6512 | 47 | True |
| native | 1 | scored | core | recall | 0.5957 | 47 | True |
| native | 1 | scored | core | f1 | 0.6222 | 47 | True |
| native | 1 | scored | core | F2 | 0.6061 | 47 | True |
| native | 1 | scored | core | tp | 28.0000 | 47 | True |
| native | 1 | scored | core | fp | 15.0000 | 47 | True |
| native | 1 | scored | core | fn | 19.0000 | 47 | True |
| native | 1 | scored | core | prs | 11.0000 | 47 | True |
| native | 1 | scored | strict | precision | 0.6512 | 43 | True |
| native | 1 | scored | strict | recall | 0.6512 | 43 | True |
| native | 1 | scored | strict | f1 | 0.6512 | 43 | True |
| native | 1 | scored | strict | F2 | 0.6512 | 43 | True |
| native | 1 | scored | strict | tp | 28.0000 | 43 | True |
| native | 1 | scored | strict | fp | 15.0000 | 43 | True |
| native | 1 | scored | strict | fn | 15.0000 | 43 | True |
| native | 1 | scored | strict | prs | 11.0000 | 43 | True |
| native | 1 | scored | all | precision | 0.6512 | 48 | True |
| native | 1 | scored | all | recall | 0.5833 | 48 | True |
| native | 1 | scored | all | f1 | 0.6154 | 48 | True |
| native | 1 | scored | all | F2 | 0.5957 | 48 | True |
| native | 1 | scored | all | tp | 28.0000 | 48 | True |
| native | 1 | scored | all | fp | 15.0000 | 48 | True |
| native | 1 | scored | all | fn | 20.0000 | 48 | True |
| native | 1 | scored | all | prs | 11.0000 | 48 | True |
| none | 1 | scored | core | precision | 0.6000 | 47 | True |
| none | 1 | scored | core | recall | 0.6383 | 47 | True |
| none | 1 | scored | core | f1 | 0.6186 | 47 | True |
| none | 1 | scored | core | F2 | 0.6303 | 47 | True |
| none | 1 | scored | core | tp | 30.0000 | 47 | True |
| none | 1 | scored | core | fp | 20.0000 | 47 | True |
| none | 1 | scored | core | fn | 17.0000 | 47 | True |
| none | 1 | scored | core | prs | 11.0000 | 47 | True |
| none | 1 | scored | strict | precision | 0.5918 | 43 | True |
| none | 1 | scored | strict | recall | 0.6744 | 43 | True |
| none | 1 | scored | strict | f1 | 0.6304 | 43 | True |
| none | 1 | scored | strict | F2 | 0.6561 | 43 | True |
| none | 1 | scored | strict | tp | 29.0000 | 43 | True |
| none | 1 | scored | strict | fp | 20.0000 | 43 | True |
| none | 1 | scored | strict | fn | 14.0000 | 43 | True |
| none | 1 | scored | strict | prs | 11.0000 | 43 | True |
| none | 1 | scored | all | precision | 0.6000 | 48 | True |
| none | 1 | scored | all | recall | 0.6250 | 48 | True |
| none | 1 | scored | all | f1 | 0.6122 | 48 | True |
| none | 1 | scored | all | F2 | 0.6198 | 48 | True |
| none | 1 | scored | all | tp | 30.0000 | 48 | True |
| none | 1 | scored | all | fp | 20.0000 | 48 | True |
| none | 1 | scored | all | fn | 18.0000 | 48 | True |
| none | 1 | scored | all | prs | 11.0000 | 48 | True |

## Coverage and timing

| Configuration | Repeat | Role | Completed / Scheduled | Median seconds |
|---|---:|---|---:|---:|
| exa | 1 | scored | 11/11 | 570.0 |
| keenable | 1 | scored | 11/11 | 597.0 |
| native | 1 | scored | 11/11 | 618.0 |
| none | 1 | scored | 11/11 | 557.0 |

## Search latency

Successful attributed search calls only, measured at the gateway. This is separate from end-to-end review time. Failed calls and missing traces stay visible; no native-search latency is inferred.

| Configuration | Repeat | Role | Successful timed calls | Median seconds | Failed search calls |
|---|---:|---|---:|---:|---:|
| exa | 1 | scored | 35 | 1.7371211669997138 | 0 |
| keenable | 1 | scored | 42 | 0.46881554199990205 | 0 |
| native | 1 | scored | 0 | None | 0 |
| none | 1 | scored | 0 | None | 0 |

Exact per-call observations: [search-latency.json](search-latency.json).

## Search evidence

Counts are observed gateway reservations, including failed or unfinished calls. Missing traces mean unknown, not zero. Rejected calls are recorded separately when attributable. Unauthenticated/unattributed events remain gateway-local and are not assigned to a run. Native CodeRabbit tool calls remain unknown.

| Configuration | Repeat | Role | Traces / Attempts | Search | Fetch | Failed | Unfinished | Rejected | Native search |
|---|---:|---|---:|---:|---:|---:|---:|---:|---|
| exa | 1 | scored | 11/11 | 35 | 48 | 8 | 0 | 2 (partial) | unknown |
| keenable | 1 | scored | 11/11 | 42 | 48 | 10 | 0 | unknown | unknown |
| native | 1 | scored | 0/11 | unknown | unknown | unknown | unknown | unknown | unknown |
| none | 1 | scored | 0/11 | unknown | unknown | unknown | unknown | unknown | unknown |

Exact attempts, trace paths and hashes: [tool-calls.json](tool-calls.json).

## Paired comparisons

[Per-task evidence](per-task-evidence.json) joins frozen suite annotations, gateway counts and baseline comparisons. UNKNOWN means no frozen relevance annotation. These tags do not prove search necessity or causal benefit.

[Per-task deltas](paired-deltas.json) subtract the baseline on the same task, role and repeat. Missing pairs stay unavailable. Duration includes only pairs where both attempts completed. Positive duration means slower. No findings are pooled across repeats.

Core F2 per-task differences are descriptive diagnostics. They do not replace the frozen full-cohort headline policy.

| Task | Configuration | Repeat | Role | Core F2 | Baseline Core F2 | Difference |
|---|---|---:|---|---:|---:|---:|
| discourse-graphite-5 | none | 1 | scored | 0.3846 | 0.0000 | 0.3846 |
| discourse-graphite-5 | exa | 1 | scored | 0.3571 | 0.0000 | 0.3571 |
| discourse-graphite-5 | keenable | 1 | scored | 0.0000 | 0.0000 | 0.0000 |
| discourse-graphite-1 | keenable | 1 | scored | 0.5263 | 0.5263 | 0.0000 |
| discourse-graphite-1 | none | 1 | scored | 0.2941 | 0.5263 | -0.2322 |
| discourse-graphite-1 | exa | 1 | scored | 0.2500 | 0.5263 | -0.2763 |
| discourse-graphite-4 | exa | 1 | scored | 0.4054 | 0.2857 | 0.1197 |
| discourse-graphite-4 | none | 1 | scored | 0.5405 | 0.2857 | 0.2548 |
| discourse-graphite-4 | keenable | 1 | scored | 0.6098 | 0.2857 | 0.3240 |
| sentry-greptile-1 | none | 1 | scored | 0.5556 | 0.7895 | -0.2339 |
| sentry-greptile-1 | keenable | 1 | scored | 0.7143 | 0.7895 | -0.0752 |
| sentry-greptile-1 | exa | 1 | scored | 0.7895 | 0.7895 | 0.0000 |
| sentry-greptile-2 | keenable | 1 | scored | 0.8333 | 0.8696 | -0.0362 |
| sentry-greptile-2 | exa | 1 | scored | 0.7692 | 0.8696 | -0.1003 |
| sentry-greptile-2 | none | 1 | scored | 0.8696 | 0.8696 | 0.0000 |
| discourse-graphite-6 | none | 1 | scored | 0.8333 | 0.8333 | 0.0000 |
| discourse-graphite-6 | exa | 1 | scored | 1.0000 | 0.8333 | 0.1667 |
| discourse-graphite-6 | keenable | 1 | scored | 0.7143 | 0.8333 | -0.1190 |
| cal.com-22532 | none | 1 | scored | 0.6818 | 0.9091 | -0.2273 |
| cal.com-22532 | keenable | 1 | scored | 0.6818 | 0.9091 | -0.2273 |
| cal.com-22532 | exa | 1 | scored | 0.5000 | 0.9091 | -0.4091 |
| keycloak-36882 | exa | 1 | scored | 0.0000 | 0.0000 | 0.0000 |
| keycloak-36882 | none | 1 | scored | 0.0000 | 0.0000 | 0.0000 |
| keycloak-36882 | keenable | 1 | scored | 0.0000 | 0.0000 | 0.0000 |
| keycloak-33832 | none | 1 | scored | 0.8824 | 0.0000 | 0.8824 |
| keycloak-33832 | keenable | 1 | scored | 0.2778 | 0.0000 | 0.2778 |
| keycloak-33832 | exa | 1 | scored | 0.5263 | 0.0000 | 0.5263 |
| cal.com-11059 | keenable | 1 | scored | 0.8654 | 0.9375 | -0.0721 |
| cal.com-11059 | none | 1 | scored | 0.8824 | 0.9375 | -0.0551 |
| cal.com-11059 | exa | 1 | scored | 0.9574 | 0.9375 | 0.0199 |
| sentry-93824 | keenable | 1 | scored | 0.3846 | 0.6522 | -0.2676 |
| sentry-93824 | exa | 1 | scored | 0.4167 | 0.6522 | -0.2355 |
| sentry-93824 | none | 1 | scored | 0.4167 | 0.6522 | -0.2355 |
Predeclared headline policy: all scheduled tasks must have valid native grading. Any missing or failed outcome suppresses every headline value. Successful per-task scores remain diagnostic only; no post-hoc complete-case replacement is made.
Reconstructed pilot inputs use frozen source trees, titles from the gold metadata and a neutral PR body. These are identical across arms but differ from historical benchmark PR descriptions. Original scoring is preserved; historical leaderboard comparability is not claimed.

[Blind finding audit](blind-review.json): up to 20 unmatched findings, balanced across available configurations. This is a diagnostic sample, not a precision estimate. Manual verdicts start unresolved and never change native scores. Keep [unblinding metadata](audit-unblinding.json) separate until review is complete.

## Audit appendix

Run fingerprint: `e87d167ca3ae971b2781dbecb5baeda03e5ad2f15259d9764a1dbcd6273a2fdb`.
[Audit metadata](audit.json) contains exact file hashes, arm settings, source revision, requested and observed models when recorded. Captured manifests and source-access audits are under `evidence/`; source availability is a dated observation.
The bundle contains only this schedule's gateway traces. Routing credentials are not copied.

## Per-task evidence

| Task | Configuration | Repeat | Role | Relevance | Search | Fetch | Baseline attempt |
|---|---|---:|---|---|---:|---:|---|
| discourse-graphite-5 | none | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 6d8dfd08d92071734dde13b6 |
| discourse-graphite-5 | exa | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 3 | 4 | 6d8dfd08d92071734dde13b6 |
| discourse-graphite-5 | native | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 6d8dfd08d92071734dde13b6 |
| discourse-graphite-5 | keenable | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 2 | 5 | 6d8dfd08d92071734dde13b6 |
| discourse-graphite-1 | keenable | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 3 | 3 | f45547f767122a3d3823ec38 |
| discourse-graphite-1 | none | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | f45547f767122a3d3823ec38 |
| discourse-graphite-1 | native | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | f45547f767122a3d3823ec38 |
| discourse-graphite-1 | exa | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 2 | 4 | f45547f767122a3d3823ec38 |
| discourse-graphite-4 | native | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 0af5b4d23a8c8ea00f4cdc7e |
| discourse-graphite-4 | exa | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 2 | 3 | 0af5b4d23a8c8ea00f4cdc7e |
| discourse-graphite-4 | none | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 0af5b4d23a8c8ea00f4cdc7e |
| discourse-graphite-4 | keenable | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 6 | 7 | 0af5b4d23a8c8ea00f4cdc7e |
| sentry-greptile-1 | native | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 5223fc806bad755f62071f86 |
| sentry-greptile-1 | none | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 5223fc806bad755f62071f86 |
| sentry-greptile-1 | keenable | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 2 | 2 | 5223fc806bad755f62071f86 |
| sentry-greptile-1 | exa | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 2 | 4 | 5223fc806bad755f62071f86 |
| sentry-greptile-2 | keenable | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 4 | 8 | 2eae30329794f70b7b1ee375 |
| sentry-greptile-2 | native | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 2eae30329794f70b7b1ee375 |
| sentry-greptile-2 | exa | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 8 | 6 | 2eae30329794f70b7b1ee375 |
| sentry-greptile-2 | none | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 2eae30329794f70b7b1ee375 |
| discourse-graphite-6 | none | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | dbb634c6eedceeb95a5d2f76 |
| discourse-graphite-6 | exa | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 5 | 6 | dbb634c6eedceeb95a5d2f76 |
| discourse-graphite-6 | keenable | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 6 | 6 | dbb634c6eedceeb95a5d2f76 |
| discourse-graphite-6 | native | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | dbb634c6eedceeb95a5d2f76 |
| cal.com-22532 | native | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 7015866c132e1b0ec2a1b7c2 |
| cal.com-22532 | none | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 7015866c132e1b0ec2a1b7c2 |
| cal.com-22532 | keenable | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 4 | 4 | 7015866c132e1b0ec2a1b7c2 |
| cal.com-22532 | exa | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 3 | 1 | 7015866c132e1b0ec2a1b7c2 |
| keycloak-36882 | exa | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 2 | 5 | 4a316435c4646a1197375b1d |
| keycloak-36882 | none | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 4a316435c4646a1197375b1d |
| keycloak-36882 | native | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 4a316435c4646a1197375b1d |
| keycloak-36882 | keenable | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 3 | 3 | 4a316435c4646a1197375b1d |
| keycloak-33832 | native | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 7458e7ecd905aad53eb86c93 |
| keycloak-33832 | none | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 7458e7ecd905aad53eb86c93 |
| keycloak-33832 | keenable | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 5 | 4 | 7458e7ecd905aad53eb86c93 |
| keycloak-33832 | exa | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 5 | 8 | 7458e7ecd905aad53eb86c93 |
| cal.com-11059 | native | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 9b61b828f5bff426c9f9f7a5 |
| cal.com-11059 | keenable | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 5 | 3 | 9b61b828f5bff426c9f9f7a5 |
| cal.com-11059 | none | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 9b61b828f5bff426c9f9f7a5 |
| cal.com-11059 | exa | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 2 | 4 | 9b61b828f5bff426c9f9f7a5 |
| sentry-93824 | keenable | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 2 | 3 | 56829cd072dc2918809fc960 |
| sentry-93824 | exa | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | 1 | 3 | 56829cd072dc2918809fc960 |
| sentry-93824 | native | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 56829cd072dc2918809fc960 |
| sentry-93824 | none | 1 | scored | EXTERNAL_SPECIFIC_SCREENED | unknown | unknown | 56829cd072dc2918809fc960 |

## Interpretation

Descriptive pilot, not statistical superiority or an official leaderboard result.
Native CodeRabbit search calls and internal costs are not observable. Different suites are not averaged.
See grading artifacts for native matching, exclusions, suppression and denominator checks.
