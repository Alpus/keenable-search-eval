import json,sys,time,os
from pathlib import Path
from datetime import datetime
root=Path('/app'); patch=root/'validation/search11/zero-findings-fix'
sys.path.insert(0,str(patch/'src'))
from search_eval.github import terminal_review
from search_eval.core import lock,atomic_json,EvalError
run=root/'runs/martian-search11-001'
while True:
 try:
  with lock(root/'.gateway/runner.lock'):
   s=json.loads((run/'state.json').read_text()); changes=[]
   for a in s['attempts']:
    if a['task_id']!='keycloak-36882' or a['configuration'] not in ['native','keenable']: continue
    if a['status']=='completed':continue
    assert a['status']=='timed_out'
    raw=json.loads((run/a['artifact_dir']/'github.json').read_text())
    r=terminal_review(raw,a['head_sha'],a['trigger_time'],completion_contract=s['config']['suite_options']['completion_contract'],repo=a['repository'],old_statuses=a.get('old_statuses',[]))
    assert r and r['status']=='completed' and r['completion_evidence']=='zero_findings_walkthrough'
    assert datetime.fromisoformat(r['completed_at'])<=datetime.fromisoformat(a['expires_at'])
    changes.append({'attempt_id':a['id'],'before':dict(a),'completion':r})
    a.update(r);a.pop('reason',None)
   receipt=patch/'recovery-receipt.json'
   if changes:
    assert not receipt.exists()
    atomic_json(receipt,{'method':'updated walkthrough timestamp; all original creator/app/SHA/status/deadline checks preserved','changes':changes})
    atomic_json(run/'state.json',s)
   print('Reconciled zero-finding reviews from saved evidence',flush=True)
  break
 except EvalError as e:
  if str(e) != 'Another runner owns this workspace; resume after it exits':raise
  time.sleep(20)
os.execv('/app/.venv/bin/search-eval',['search-eval','run','--config','configs/martian-search11.yaml'])
